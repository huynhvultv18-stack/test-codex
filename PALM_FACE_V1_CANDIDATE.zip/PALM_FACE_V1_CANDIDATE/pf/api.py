from datetime import timedelta
import asyncio,copy,hashlib,hmac,json,os,secrets,time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI,Request
from fastapi.responses import JSONResponse,Response,FileResponse
from fastapi.staticfiles import StaticFiles
import jwt
from jsonschema import ValidationError
from .contracts import ROOT,loads,validate
from .common import *
from .auth import verify,Principal
from .storage import Store
from .service import Service

MESSAGE={'UNAUTHENTICATED':'Vui lòng đăng nhập.','FORBIDDEN':'Thao tác không được phép.','NOT_FOUND':'Không tìm thấy đối tượng.','REVISION_CONFLICT':'Dữ liệu đã đổi. Hãy tải lại và xem xét trước khi lưu.','QUALITY_BLOCKED':'Ảnh chưa đạt kiểm tra chất lượng.','CONSENT_REQUIRED':'Cần đồng ý trực tiếp trong giao diện.','SESSION_EXPIRED':'Phiên đã hết hạn hoặc bị xóa.','VALIDATION_ERROR':'Dữ liệu không hợp lệ.','SOURCE_NOT_APPROVED':'Tư liệu chưa được duyệt.','INVALID_STATE':'Trạng thái hiện tại chưa cho phép thao tác.'}

def make_app(config=None):
    config=config or loads((ROOT/'.runtime/dev.json').read_text());config.setdefault('mode','synthetic');config.setdefault('origin','http://127.0.0.1:8088')
    if config['mode']!='synthetic':raise RuntimeError('Production deployment gates are unresolved; this candidate is synthetic-only.')
    db=Store(config);service=Service(db)
    from .mcp_gateway import gateway
    mcp_server,mcp_app=gateway(config)
    rate={}
    async def maintenance():
        from .worker import cycle
        while True:
            try:await asyncio.to_thread(cycle,service,config)
            except Exception:pass # no payload or traceback logging; tests exercise failure receipts
            await asyncio.sleep(.25)
    @asynccontextmanager
    async def life(app):
        task=asyncio.create_task(maintenance())
        async with mcp_server.session_manager.run():
            yield
        task.cancel()
        try:await task
        except asyncio.CancelledError:pass
    app=FastAPI(lifespan=life,docs_url=None,redoc_url=None,openapi_url=None)
    app.state.service=service;app.state.config=config
    @app.middleware('http')
    async def guard(req,call_next):
        rid=uid('req');req.state.rid=rid
        origin=req.headers.get('origin')
        if origin and origin!=config['origin']:
            return error(Problem('FORBIDDEN',403),rid)
        if req.headers.get('host') not in {'127.0.0.1:8088','localhost:8088','testserver'} and config['mode']=='synthetic':
            return error(Problem('FORBIDDEN',403),rid)
        res=await call_next(req)
        res.headers['Cache-Control']='no-store';res.headers['X-Content-Type-Options']='nosniff';res.headers['Referrer-Policy']='no-referrer'
        res.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-src 'self' blob:; frame-ancestors 'self'; object-src 'none'; base-uri 'none'"
        return res
    def error(e,rid):
        body=dict(code=e.code,message_vi=MESSAGE.get(e.code,'Không thể hoàn thành thao tác. Xem trạng thái và thử lại khi điều kiện đã được khắc phục.'),request_id=rid,retryable=e.code in ('PURGE_FAILED','INTERNAL_ERROR','JOB_TIMEOUT'),field_paths=[])
        validate('Error',body)
        r=JSONResponse(body,status_code=e.status)
        r.headers['Cache-Control']='no-store'
        if e.status==429:r.headers['Retry-After']='1'
        if e.status==401:r.headers['WWW-Authenticate']='Bearer resource_metadata="'+config['origin']+'/.well-known/oauth-protected-resource"'
        return r
    def principal(req,scope):
        cookie=req.cookies.get('pf_ui');bearer=req.headers.get('authorization','')
        token=cookie if cookie else bearer.removeprefix('Bearer ')
        if not token:raise Problem('UNAUTHENTICATED',401)
        p=verify(token,config,ui=bool(cookie))
        if scope not in p.scopes:raise Problem('FORBIDDEN',403)
        t=time.monotonic();recent=[x for x in rate.get(p.owner,[]) if t-x<1]
        if len(recent)>=config.get('rate_limit',10):raise Problem('RATE_LIMITED',429)
        rate[p.owner]=recent+[t]
        if p.ui and req.method not in ('GET','HEAD'):
            csrf=hmac.new(config['dev_auth_key'].encode(),token.encode(),hashlib.sha256).hexdigest()
            if req.headers.get('origin')!=config['origin'] or not hmac.compare_digest(req.headers.get('x-csrf',''),csrf):raise Problem('FORBIDDEN',403)
        return p
    @app.get('/healthz')
    def health():return {'status':'ok','contract_version':'1.0.0'}
    @app.get('/.well-known/oauth-protected-resource')
    def discovery():return {'resource':config['origin']+'/mcp','authorization_servers':[config.get('oidc_issuer','urn:pf:dev-idp')],'scopes_supported':['pf:read','pf:write','pf:delete'],'bearer_methods_supported':['header']}
    @app.get('/')
    def index():return FileResponse(ROOT/'apps/reviewer_ui/index.html')
    @app.post('/dev/login')
    async def login(req:Request):
        if config['mode']!='synthetic' or req.headers.get('origin')!=config['origin']:return error(Problem('FORBIDDEN',403),req.state.rid)
        try:
            body=loads(await req.body());name=body['account']
            if name not in ('alice','bob') or set(body)!={'account'}:raise ValueError()
        except Exception:return error(Problem('VALIDATION_ERROR'),req.state.rid)
        t=int(time.time());token=jwt.encode({'iss':'urn:pf:dev-idp','aud':'pf-synthetic','sub':name,'iat':t,'exp':t+3600,'scope':'pf:read pf:write pf:delete'},config['dev_auth_key'],algorithm='HS256')
        r=JSONResponse({'synthetic_only':True});r.set_cookie('pf_ui',token,httponly=True,samesite='strict',secure=False,max_age=3600,path='/')
        return r
    @app.get('/ui/bootstrap')
    def bootstrap(req:Request):
        try:
            p=principal(req,'pf:read')
            if not p.ui:raise Problem('FORBIDDEN',403)
            token=req.cookies['pf_ui'];return {'synthetic_only':config['mode']=='synthetic','csrf':hmac.new(config['dev_auth_key'].encode(),token.encode(),hashlib.sha256).hexdigest()}
        except Problem as e:return error(e,req.state.rid)
    app.mount('/mcp',mcp_app)
    app.mount('/static',StaticFiles(directory=ROOT/'apps/reviewer_ui'),name='static')
    @app.api_route('/v1/{path:path}',methods=['GET','POST','PATCH','PUT','DELETE'])
    async def route(path:str,req:Request):
        scope='pf:delete' if req.method=='DELETE' or path.endswith('consent/revoke') or path.startswith('deletions/') else 'pf:read' if req.method=='GET' or path=='asset-grants' else 'pf:write'
        try:
            p=principal(req,scope)
            # Every browser mutation is Origin+CSRF bound. Dense/consent/upload APIs require UI identity.
            ui_only=any(x in path for x in ('uploads','annotations','review/confirm','consent/preferences','asset-grants','/content','/transform')) or (path=='sessions' and req.method=='POST') or path.endswith('/reports') or '/analyses/' in path
            if ui_only and not p.ui:raise Problem('FORBIDDEN',403)
            binary=path.startswith('uploads/') and path.endswith('/content')
            cap=20971520 if binary else 2097152
            chunks=[];total=0
            async for chunk in req.stream():
                total+=len(chunk)
                if total>cap:raise Problem('FILE_TOO_LARGE',413)
                chunks.append(chunk)
            raw=b''.join(chunks)
            body={} if not raw or binary else loads(raw)
            if binary:body=raw
            with db.tx() as c:
                key=req.headers.get('idempotency-key')
                needs_key=req.method=='POST' and (path=='sessions' or path.endswith(('/prepare','/finalize','/analyses','/reports')))
                if needs_key:
                    if not key or not 1<=len(key)<=100:raise Problem('VALIDATION_ERROR')
                    digest=hashlib.sha256(raw).hexdigest();r=c.execute('SELECT hash,response,expires FROM idempotency WHERE owner=%s AND route=%s AND key=%s',(p.owner,path,key)).fetchone()
                    if r and r[2]>now():
                        if r[0]!=digest:raise Problem('REVISION_CONFLICT',409)
                        value=loads(db.unseal(bytes(r[1])));return JSONResponse(value['body'],status_code=value['status'])
                result,status=dispatch(service,c,p,req.method,path,body,config,req.headers.get('origin'))
                if isinstance(result,Response):return result
                if needs_key:
                    c.execute('INSERT INTO idempotency VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT(owner,route,key) DO UPDATE SET hash=EXCLUDED.hash,response=EXCLUDED.response,expires=EXCLUDED.expires',(p.owner,path,key,digest,db.seal(json.dumps({'body':result,'status':status}).encode()),now()+timedelta(hours=24)))
                c.execute('INSERT INTO audit(action,outcome,request_id) VALUES(%s,%s,%s)',(req.method,'success',req.state.rid))
            return Response(status_code=status) if status==204 else JSONResponse(result,status_code=status)
        except Problem as e:return error(e,req.state.rid)
        except (ValidationError,ValueError,KeyError):return error(Problem('VALIDATION_ERROR'),req.state.rid)
        except Exception:return error(Problem('INTERNAL_ERROR',500),req.state.rid)
    return app

def dispatch(svc,c,p,method,path,b,config,origin):
    from .operations import dispatch as full
    return full(svc,c,p,method,path,b,config,origin)
