# PALM & FACE V1 — candidate synthetic / assisted

Spec PF-SPEC-1.0.0 remains byte-for-byte locked in spec/locked. This is a locally tested candidate, **not a deployed Plugin or production/person-analysis service**. All five real phase gates remain BLOCKED where target host/IdP, model access/rights, participant CV evaluation, corpus human review and production operations evidence are missing. The owner confirmed those prerequisites are unavailable.

## Local installation

Use Linux x86_64, Python3.12, Docker, Node24 and Chromium. OpenCV/MediaPipe may need the system libraries available in the tested image. A fresh Python environment was actually installed from the hash-locked wheels and imports were verified. Existing tested runtime: Python3.12.14, mediapipe1.1.0, SDK MCP1.29.0, Chromium154.0.8037.57, Playwright1.62.1.

```sh
bash scripts/install.sh
bash scripts/start.sh
```

The install script verifies Python wheel hashes, creates synthetic keys outside source at .runtime/, starts only a loopback PostgreSQL container with RAM-backed payload storage, and checks DB readiness. It preserves existing configuration and never prints keys. After a RAM-backed container is stopped its DB payload disappears; restart/reinitialize only your own synthetic instance explicitly. Do not treat this as production durability or compliance. Port conflicts with unrelated services must be resolved without killing them.

Open the local UI on port8088 in your own machine. It accepts only exact five images from fixtures/synthetic and uses dev alice/bob accounts. The browser communicates directly with the local API; no images, embeddings, mesh or grants enter an LLM. No external LLM/API, paid service or real images are used. Detailed operation: docs/USER_GUIDE.md.

The locally bundled PDF.js browser preview assets and their Apache2 license are included; no CDN call is needed. To reproduce those vendor assets from the pinned npm lock:

```sh
npm ci --ignore-scripts --no-audit --no-fund --prefix apps/reviewer_ui
```

## Checks

Keep the server running for MCP/browser checks. The install bootstrap creates an isolated pf_test database; tests use synthetic accounts/data.

```sh
.venv/bin/python -m pytest tests -q --junitxml=evidence/local-regression.xml
.venv/bin/python scripts/benchmark.py
node tests/browser.cjs
```

Browser harness requires Playwright1.62.1 and /usr/bin/chromium. If not installed, use a separate tool directory, e.g. `npm install --prefix .runtime/browser-tools playwright@1.62.1`, then set NODE_PATH to that directory's node_modules. This does not require a running ChatGPT host. PDF QA uses Poppler `pdftoppm/pdftotext` and can be reproduced from evidence/synthetic-report.pdf. Tests exercise behavior; test count is not the number of fully accepted T01–T52 gates.

## Limits and required next actions

Read docs/ACCEPTANCE_REPORT.md, docs/TEST_MATRIX.md, docs/HOST_INTEGRATION_REPORT.md, models/REGISTER.json, docs/SOURCE_REVIEW.md and evaluation/PROTOCOL.md. No reviewed traditional rule is active; disabled corpus is not delivery of a complete corpus. Model assets could not be retrieved, so real CV/semantic map/pose/QC and dataset accuracy remain unvalidated. CV MODE ASSISTED refers to local manual/synthetic mechanics only. Committed single-slot removal needs the unapproved SCR-001 clarification; slot replacement and session deletion work.

Production mode is disabled. The OIDC token verifier is a deployment adapter, not a configured IdP or completed browser login flow. Future owner-approved deployment must establish provider/region/budget, TLS/private ACL, auth/account-linking, provider no-backup/versioning retention, malware/decode/process sandbox, hard job/resource limits, model/data/source rights, human content review, and actual host acceptance. Do not change the locked schema/TTL/policy to bypass these gates. Do not publish or collect photographs based on this local package.

## Delete/cleanup

Use Xóa phiên / Rút đồng ý in the UI and inspect its receipt. Access/grants are revoked first; purge inventory controls completed status. Failed purge remains failed and is retried with bounded backoff without moving its deadline. Session24h, raw15min upper bound, grant5min, audit/receipt30days; downloaded files have their own lifecycle.

Stopping the owned dev services/container is a local operations action; it does not erase user-downloaded evidence files or claim provider erasure. Never commit .runtime/, keys or session payloads. The delivery ZIP omits runtime state, Git metadata, virtual environments, npm node_modules and credentials.
