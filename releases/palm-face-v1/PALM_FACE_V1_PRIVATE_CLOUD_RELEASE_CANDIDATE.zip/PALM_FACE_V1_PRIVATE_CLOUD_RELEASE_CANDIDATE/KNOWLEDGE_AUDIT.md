# Knowledge audit

P1 KNOWLEDGE = BLOCKED. corpus/release.json has0active_sources/0active_rules; no traditional card executes. pf.knowledge uses finite schema, approved exact template hash, reviewed source-record hash, source snapshot hash/edition/locator/tradition and source rights. Draft/unsafe/indirect templates and executable DSL fields are rejected in tests/test_phase4.py. Synthetic reviewer/source fixtures exercise guard mechanics only.

Source claims from Phase1 remain historical metadata; no new web source/edition/license/human review was completed. Cheiro is glossary candidate; Lavater catalog candidate; East Asian/Vietnamese source not selected. Do not merge traditions or activate missing-source rules. Output permitted only names/glossary/context of culture; no image-based personality/intelligence/trust/emotion/health/longevity/wealth/future/beauty/sensitive traits. Face ratios do not trigger personal traditional judgements.

No reviewer was appointed by the assistant. Rule/source release must freeze source/edition/locator/snapshot/translation/right/reviewer and exact approved template, preserve separate traditions and review contradictory glossary definitions. Host privacy and semantic human review remain mandatory independent gates.
