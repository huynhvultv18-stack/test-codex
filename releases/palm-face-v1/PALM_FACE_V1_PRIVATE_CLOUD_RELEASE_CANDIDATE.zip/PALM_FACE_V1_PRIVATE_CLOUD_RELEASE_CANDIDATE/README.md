# PALM & FACE V1 — PRIVATE CLOUD RELEASE CANDIDATE

Bản làm việc riêng từ Candidate được cung cấp. Baseline/SPEC LOCK/test-codex giữ nguyên. Chỉ local synthetic/assisted; production startup vẫn bị từ chối, không Plugin đã triển khai. Đọc FINAL_STATUS.json, RELEASE_READINESS_REPORT.md, BLOCKED_GATE_MATRIX.csv và OWNER_DEPENDENCIES.md trước quyết định phát hành. Current evidence: release-regression.xml, browser.json, mcp-local.json, performance.json và release-pdf-page-*.png. evidence/baseline-history và docs/baseline-history là lịch sử, không thay kiểm thử hiện tại.

## Reproduce local development

Linux x86_64, Python3.12, Docker, Node24, Chromium và Poppler. Sử dụng thư mục checkout hiện có trong môi trường cô lập; không tạo worktree. Từ thư mục này:

```sh
bash scripts/install.sh
bash scripts/start.sh
```

Installer đã được chạy lặp lại: hash-locked wheels, digest-pinned RAM-backed PostgreSQL loopback, local synthetic dev keys và fixtures. Không in/commit .runtime/dev.json hoặc postgres.env. DB mất payload khi container tmpfs dừng. Port/container conflicts không được giải quyết bằng dừng dịch vụ không thuộc lần setup này. scripts/start.sh phải giữ chạy cho MCP/browser checks; processes không nằm trong ZIP/snapshot.

```sh
.venv/bin/python -m pytest tests -q --junitxml=evidence/release-regression.xml
.venv/bin/python scripts/benchmark.py
mkdir -p .runtime/browser-tools
cp infra/browser-tools/package*.json .runtime/browser-tools/
npm ci --prefix .runtime/browser-tools --cache /tmp/pf-npm-cache --ignore-scripts --no-audit --no-fund
NODE_PATH="$PWD/.runtime/browser-tools/node_modules" node tests/browser.cjs
```

Chạy pytest và benchmark lần lượt: cả hai dùng pf_test. Chromium harness dùng /usr/bin/chromium và synthetic fixtures. UI local port8088 chỉ dev alice/bob, có consent trước upload; không publish/tunnel. PDF.js/font được bundle với license; ảnh/annotation/PDF/grants không vào model context. Không thu thập/upload ảnh người thật trong bản này.

## Changes

Decode/CV/PDF chạy child process với wall/CPU/AS/core/fd limits, process group cancellation; decode ngoài DB transaction và event loop để xóa không chờ decode. Parent kiểm owner/revision/expiry/tombstone/lease attempt trước commit. Decoder chặn PNG thiếu IEND, raw reject xóa ngay; scanner Unix INSTREAM optional fail closed, chỉ protocol test được kiểm, live scanner chưa nghiệm thu. API/data contract1.0.0 không thay. Chi tiết/patch ở CHANGELOG_RELEASE.md và patches/release-hardening.patch.

## Required external acceptance

Owner xác nhận chưa có provider/region/budget/IdP/quyền host. Model assets/licenses/semantic QA/real holdout và source rights/human review chưa cung cấp; giữ ASSISTED/inactive corpus. Worker process limits không thay kernel network/filesystem sandbox, cgroups hay provider no-backup/versioning/soft-delete. SCR-001 committed slot delete chưa được approve; replacement/full-session deletion vẫn là contract hiện có. Các gate này BLOCKED, không chuyển Production. Xem DEPLOYMENT_PLAN.md để triển khai/rollback sau Owner review; không restore session đã xóa từ backup.

## Integrity and handoff

CHECKSUMS.txt bao phủ package files; BASELINE_CHECKSUMS.sha256 ghi input hashes; VERSION_FREEZE.json ghi source hiện tại. Repackage bằng .venv/bin/python scripts/package.py; output PALM_FACE_V1_PRIVATE_CLOUD_RELEASE_CANDIDATE.zip, bỏ runtime/venv/node_modules/keys. Không ghi đè Candidate đầu vào. docs/baseline-history/evidence/baseline-history bảo toàn bằng chứng cũ và lỗi lịch sử.
