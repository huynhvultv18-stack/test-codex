from fastapi.testclient import TestClient
from pf.api import make_app
from test_phase2 import env,body
import pytest
@pytest.fixture
def client(env):return TestClient(make_app(env))
def login(client):
 assert client.post('/dev/login',json={'account':'alice'},headers={'Origin':'http://127.0.0.1:8088'}).status_code==200
 x=client.get('/ui/bootstrap').json();return {'Origin':'http://127.0.0.1:8088','X-CSRF':x['csrf']}
def test_T07_replay(client):
 h=login(client);h['Idempotency-Key']='foundation-replay'
 a=client.post('/v1/sessions',json=body(),headers=h);assert a.status_code==201
 b=client.post('/v1/sessions',json=body(),headers=h);assert a.json()==b.json()
 changed=body();changed['profile']['dominant_hand']='left'
 assert client.post('/v1/sessions',json=changed,headers=h).status_code==409
 assert a.headers['cache-control']=='no-store'
def test_T03_T05_origin_csrf(client):
 assert client.get('/v1/sessions/unknown').status_code==401
 login(client)
 assert client.post('/v1/sessions',json=body()).status_code==403
 assert client.post('/v1/sessions',json=body(),headers={'Origin':'https://evil.example'}).status_code==403
