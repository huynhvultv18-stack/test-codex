import json,copy,math
from datetime import timedelta
import pytest,jwt
from pf.contracts import ROOT,validate,loads
from pf.storage import Store
from pf.service import Service
from pf.auth import Principal,verify
from pf.common import Problem,dt
@pytest.fixture
def env():
 c=json.loads((ROOT/'.runtime/dev.json').read_text());c['mode']='synthetic';c['rate_limit']=1000;c['database_url']=c['database_url'].rsplit('/',1)[0]+'/pf_test';return c
@pytest.fixture
def svc(env):return Service(Store(env))
@pytest.fixture
def p():return Principal('test-owner',frozenset({'pf:read','pf:write','pf:delete'}),True)
def body():return json.loads((ROOT/'spec/locked/examples/session_create.json').read_text())['payload']
@pytest.mark.parametrize('file',list((ROOT/'spec/locked/examples').glob('*.json')))
def test_T01_fixture(file):
 x=json.loads(file.read_text());validate(x['definition'],x['payload'])
@pytest.mark.parametrize('bad',[float('nan'),float('inf'),-float('inf')])
def test_T02_nonfinite(bad):
 with pytest.raises(ValueError):validate('Point2D',{'x':bad,'y':.5})
def test_T02_strict():
 for raw in ['{"x":NaN}', '{"x":1e999}']:
  with pytest.raises(ValueError):loads(raw)
 with pytest.raises(Exception):validate('Point2D',{'x':.5,'y':.5,'trait':'trust'})
def test_T03_consent(svc,p):
 with svc.db.tx() as c:
  with pytest.raises(Problem):svc.create(c,Principal(p.owner,p.scopes),body())
  for key in ['adult_self_declared','self_images_only','processing_allowed']:
   b=body();b['consent'][key]=False
   with pytest.raises(Exception):svc.create(c,p,b)
def test_T05_tokens(env):
 from time import time
 claim={'iss':'urn:pf:dev-idp','aud':'pf-synthetic','sub':'alice','iat':int(time()),'exp':int(time())+60,'scope':'pf:read'}
 assert verify(jwt.encode(claim,env['dev_auth_key'],algorithm='HS256'),env).owner.endswith('|alice')
 for key,val in [('iss','bad'),('aud','bad'),('exp',1)]:
  x=dict(claim);x[key]=val
  with pytest.raises(Problem):verify(jwt.encode(x,env['dev_auth_key'],algorithm='HS256'),env)
def test_T06_T08_T09_ownership_revision_ttl(svc,p):
 with svc.db.tx() as c:
  v=svc.create(c,p,body());s=svc.session(c,v['session_id'],p)
  assert dt(v['expires_at'])-dt(v['created_at'])==timedelta(hours=24)
  with pytest.raises(Problem) as e:svc.session(c,v['session_id'],Principal('other',p.scopes))
  assert e.value.status==404
  with pytest.raises(Problem):svc.revision(s,100)
  r=svc.delete(c,v['session_id'],p)
  with pytest.raises(Problem) as e:svc.session(c,v['session_id'],p)
  assert e.value.status==410
  assert svc.purge(c,p,r['deletion_id'])['state']=='completed'
