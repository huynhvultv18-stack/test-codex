import copy,io,math
from PIL import Image
import pytest
from pf.images import normalize,quality,REGISTRY
from pf.geometry import adapt,face_metrics,line_metrics
from pf.common import Problem
from pf.contracts import ROOT,validate
@pytest.mark.parametrize('fmt,mime',[('JPEG','image/jpeg'),('PNG','image/png'),('WEBP','image/webp')])
def test_T10_decode(fmt,mime):
 im=Image.new('RGB',(900,800),'white');b=io.BytesIO();im.save(b,fmt);normal,canonical,size,tr=normalize(b.getvalue(),mime,False);assert size==(900,800)
 assert not Image.open(io.BytesIO(canonical)).info
@pytest.mark.parametrize('raw,mime',[(b'<svg/>','image/png'),(b'GIF89a','image/png'),(b'garbage','image/jpeg')])
def test_T10_reject(raw,mime):
 with pytest.raises(Problem):normalize(raw,mime,False)
def test_T10_animated_polyglot():
 im=Image.new('RGB',(800,800));other=Image.new('RGB',(800,800),'white');b=io.BytesIO();im.save(b,'PNG',save_all=True,append_images=[other])
 with pytest.raises(Problem):normalize(b.getvalue(),'image/png',False)
 b=io.BytesIO();im.save(b,'PNG')
 with pytest.raises(Problem):normalize(b.getvalue()+b'<script/>','image/png',False)
def test_T11_caps():
 with pytest.raises(Problem) as e:normalize(b'x'*20971521,'image/png',False)
 assert e.value.status==413
 im=Image.new('1',(6000,4001));b=io.BytesIO();im.save(b,'PNG')
 with pytest.raises(Problem) as e:normalize(b.getvalue(),'image/png',False)
 assert e.value.code=='PIXEL_LIMIT'
def test_T12_exif_mirror():
 im=Image.new('RGB',(900,800));exif=Image.Exif();exif[274]=6;b=io.BytesIO();im.save(b,'JPEG',exif=exif)
 n,k,size,tr=normalize(b.getvalue(),'image/jpeg',True);assert size==(800,900)
 # Orientation6 -> rotateCW then mirror: (x,y) maps to (y,x).
 assert tr['source_to_canonical_pixel_matrix']==[[0.,1.,0.],[1.,0.,0.],[0.,0.,1.]]
 n2,k2,size2,tr2=normalize(k,'image/png',False);assert k2==k;assert tr2['exif_orientation_applied']==1
@pytest.mark.parametrize('count,slot',[(2,'palm_left'),(1,'face_front')])
def test_T13_multiple_wrong_slot(count,slot):
 data=(ROOT/'fixtures/synthetic/palm_left.png').read_bytes();fixture=copy.deepcopy(next(v for v in REGISTRY.values() if v['slot']=='palm_left'));fixture['count']=count
 assert quality('img_test',data,slot,True,fixture)['status']=='reshoot'
def test_T14_unknown_quality():
 data=(ROOT/'fixtures/synthetic/face_front.png').read_bytes();q=quality('img_test',data,'face_front',True,None);assert q['status']=='fatal';assert q['object_count'] is None
@pytest.mark.parametrize('count', [20,477])
def test_T19_count_mismatch(count):
 with pytest.raises(Problem) as e:adapt([(0.5,0.5)]*count,21 if count==20 else 478,'img_test')
 assert e.value.code=='MODEL_MISMATCH'
def face():
 p=[(.5,.5)]*478
 for i,xy in {10:(.5,.25),152:(.5,.75),234:(.25,.5),454:(.75,.5),133:(.4,.4),362:(.6,.4),61:(.4,.6),291:(.6,.6),98:(.45,.5),327:(.55,.5)}.items():p[i]=xy
 return adapt(p,478,'img_test')
def test_T20_T21_T22_T23_T24_geometry():
 p=face();m=face_metrics('img_test',p,1001,501,enabled=True,pose_ok=True)
 assert math.isclose(m[0]['value'],.5)
 mirror=copy.deepcopy(p)
 for lm in mirror:lm['point']['x']=1-lm['point']['x']
 assert face_metrics('img_test',mirror,2001,1001,enabled=True,pose_ok=True)[0]['value']==.5
 assert face_metrics('img_test',p,1001,501,slot='face_left_oblique',enabled=True,pose_ok=True)==[]
 assert all(x['value'] is None for x in face_metrics('img_test',p,1001,501,enabled=True,pose_ok=False))
 for i in (234,454):p[i]['point']={'x':.5,'y':.5}
 assert all(x['value'] is None for x in face_metrics('img_test',p,1001,501,enabled=True,pose_ok=True))
 assert not any('hairline' in x['metric_id'] or 'third' in x['metric_id'] for x in m)
def test_T18_line_descriptors():
 line=dict(line_id='lin_manual',image_id='img_test',origin='manual',status='confirmed',conventional_label='life',polyline=[{'x':.2,'y':.5},{'x':.8,'y':.5}],raw_model_score=None,descriptors=[],uncertainty_reason='Owner tracing')
 m=line_metrics(line,[],1001,501);assert m[0]['value'] is None;assert m[1]['value']==1;assert m[2]['value'] is None
 validate('PalmLine',line);line['raw_model_score']=.9
 with pytest.raises(Exception):validate('PalmLine',line)

def test_T10_animated_webp():
 im=Image.new('RGB',(800,800));other=Image.new('RGB',(800,800),'white');buf=io.BytesIO();im.save(buf,'WEBP',save_all=True,append_images=[other])
 with pytest.raises(Problem):normalize(buf.getvalue(),'image/webp',False)
