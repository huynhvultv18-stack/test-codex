import uuid,json,copy
from fastapi.testclient import TestClient
from pf.api import make_app
from pf.contracts import ROOT,validate
from pf.worker import claim,run_job,cycle
from test_phase2 import env,body
from test_api_foundation import login
import pytest
@pytest.fixture
def client(env):return TestClient(make_app(env))
def post(client,url,b,h):
 return client.post(url,json=b,headers={**h,'Idempotency-Key':uuid.uuid4().hex})
def create_five(client,h):
 r=post(client,'/v1/sessions',body(),h);assert r.status_code==201,r.text;s=r.json();sid=s['session_id']
 for slot in ('palm_left','palm_right','face_front','face_left_oblique','face_right_oblique'):
  data=(ROOT/'fixtures/synthetic'/f'{slot}.png').read_bytes();s=client.get('/v1/sessions/'+sid).json();b=dict(slot=slot,mime_type='image/png',size_bytes=len(data),mirrored=False,mirror_confirmed=True,expected_session_revision=s['session_revision'])
  t=post(client,f'/v1/sessions/{sid}/uploads/prepare',b,h);assert t.status_code==201,t.text
  assert client.put(t.json()['upload_path'],content=data,headers=h).status_code==204
  r=post(client,f'/v1/sessions/{sid}/uploads/finalize',dict(ticket_id=t.json()['ticket_id'],expected_session_revision=s['session_revision']),h);assert r.status_code==201,r.text
 s=client.get('/v1/sessions/'+sid).json();warning=[i['image_id'] for i in s['images'] if i['quality']['status']=='review']
 if warning:
  r=post(client,f'/v1/sessions/{sid}/quality/acknowledge',dict(expected_session_revision=s['session_revision'],image_ids=warning,accept_soft_warnings=True),h);assert r.status_code==200,r.text
 s=client.get('/v1/sessions/'+sid).json();assert s['state']=='ready';return s

def reviewed(client,h):
 s=create_five(client,h);sid=s['session_id'];r=post(client,f'/v1/sessions/{sid}/analyses',{'expected_session_revision':s['session_revision']},h);assert r.status_code==202,r.text
 svc=client.app.state.service;run_job(svc,claim(svc));s=client.get('/v1/sessions/'+sid).json();assert s['state']=='review'
 return s

def test_T04_T15_T17_T18_T43_journey(client):
 h=login(client);s=reviewed(client,h);sid=s['session_id'];a=client.get(f'/v1/sessions/{sid}/analyses/{s["latest_analysis_id"]}').json();validate('AnalysisSnapshot',a)
 assert len(a['palm_results'][0]['landmarks'])==21;assert len(a['face_results'][0]['landmarks'])==478
 assert a['face_results'][1]['metrics']==[]
 image=a['palm_results'][0]['image_id'];ops=[dict(operation='add_line',image_id=image,line_id='lin_owner_'+uuid.uuid4().hex,polyline=[{'x':.25,'y':.5},{'x':.7,'y':.6}],conventional_label='life')]
 ops.append(dict(operation='confirm_line',image_id=image,line_id=ops[0]['line_id']))
 b=dict(expected_session_revision=s['session_revision'],expected_annotation_revision=0,operations=ops,reason='owner_edit')
 r=client.patch(f'/v1/sessions/{sid}/annotations',json=b,headers=h);assert r.status_code==200,r.text
 assert client.patch(f'/v1/sessions/{sid}/annotations',json=b,headers=h).status_code==409
 new=client.get('/v1/sessions/'+sid).json();d=client.get(f'/v1/sessions/{sid}/analyses/{new["latest_analysis_id"]}').json();line=next(l for l in d['palm_results'][0]['lines'] if l['line_id']==ops[0]['line_id']);assert line['origin']=='manual';assert line['raw_model_score'] is None;assert line['descriptors'][1]['value']>0
 baseline=client.get(f'/v1/sessions/{sid}/analyses/{s["latest_analysis_id"]}').json();assert not any(l['line_id']==ops[0]['line_id'] for l in baseline['palm_results'][0]['lines'])
 for operation,extra in [('assign_label',{'conventional_label':'head'}),('replace_line',{'polyline':[{'x':.2,'y':.5},{'x':.8,'y':.5}]}),('reject_line',{}),('delete_line',{})]:
  s=client.get('/v1/sessions/'+sid).json();ann=client.get(f'/v1/sessions/{sid}/annotations').json();b=dict(expected_session_revision=s['session_revision'],expected_annotation_revision=ann['annotation_revision'],operations=[dict(operation=operation,image_id=image,line_id=ops[0]['line_id'],**extra)],reason='owner_edit')
  assert client.patch(f'/v1/sessions/{sid}/annotations',json=b,headers=h).status_code==200

def test_T04_missing_slots(client):
 h=login(client);s=post(client,'/v1/sessions',body(),h).json();assert post(client,f'/v1/sessions/{s["session_id"]}/analyses',{'expected_session_revision':1},h).status_code==422

def test_T33_T34_T35_T36_T37_pdf(client):
 from pypdf import PdfReader
 import io,hashlib
 h=login(client);s=reviewed(client,h);sid=s['session_id'];r=post(client,f'/v1/sessions/{sid}/review/confirm',dict(expected_session_revision=s['session_revision'],expected_annotation_revision=0,acknowledge_limitations=True),h);assert r.status_code==200
 f=client.get(f'/v1/sessions/{sid}/fusion');assert f.status_code==200;validate('FusionResult',f.json());assert f.json()['traditional_cards']==[]
 request=dict(expected_session_revision=s['session_revision'],expected_annotation_revision=0,include_images=False,format='pdf',language='vi-VN')
 bad=dict(request,include_images=True);assert post(client,f'/v1/sessions/{sid}/reports',bad,h).status_code==422
 r=post(client,f'/v1/sessions/{sid}/reports',request,h);assert r.status_code==202,r.text
 svc=client.app.state.service;run_job(svc,claim(svc));job=client.get('/v1/jobs/'+r.json()['job_id']).json();assert job['state']=='succeeded',job
 manifest=client.get('/v1/reports/'+job['result_id']).json();validate('ReportManifest',manifest);data=client.get(manifest['download_path']).content
 assert hashlib.sha256(data).hexdigest()==manifest['pdf_sha256'];reader=PdfReader(io.BytesIO(data));assert 6<=len(reader.pages)<=10
 text='\n'.join(p.extract_text() for p in reader.pages);assert 'KHÔNG ĐỦ DỮ LIỆU' in text;assert 'TƯ LIỆU TRUYỀN THỐNG' in text;assert 'Lòng bàn tay trái' in text
 assert sum(len(p.images) for p in reader.pages)==0
 (ROOT/'evidence/synthetic-report.pdf').write_bytes(data);(ROOT/'evidence/synthetic-report-text.txt').write_text(text)
 # A report's revision is tied to input; changing preferences revokes it immediately.
 r=client.patch(f'/v1/sessions/{sid}/consent/preferences',json=dict(expected_session_revision=s['session_revision'],include_images_in_pdf=True),headers=h);assert r.status_code==200
 assert client.get(manifest['download_path']).status_code==404

def test_runtime_reference_invariants(client):
 from pf.invariants import analysis_invariants
 from pf.common import Problem
 import copy
 h=login(client);s=reviewed(client,h);a=client.get(f'/v1/sessions/{s["session_id"]}/analyses/{s["latest_analysis_id"]}').json();assert analysis_invariants(a,s)==a
 for kind in ('duplicate_image','wrong_slot','duplicate_landmark','fake_manual_score','wrong_formula','wrong_evidence'):
  x=copy.deepcopy(a)
  if kind=='duplicate_image':x['image_revisions'][1]=x['image_revisions'][0]
  elif kind=='wrong_slot':x['palm_results'][0]['image_id']=x['palm_results'][1]['image_id']
  elif kind=='duplicate_landmark':x['face_results'][0]['landmarks'][1]=x['face_results'][0]['landmarks'][0]
  elif kind=='fake_manual_score':x['face_results'][0]['landmarks'][0].update(origin='manual',raw_model_score=.9)
  elif kind=='wrong_formula':x['face_results'][0]['metrics'][0]['formula_id']='beauty_score'
  else:x['face_results'][0]['metrics'][0]['evidence_refs']=['not_current_image']
  with pytest.raises(Problem):analysis_invariants(x,s)
