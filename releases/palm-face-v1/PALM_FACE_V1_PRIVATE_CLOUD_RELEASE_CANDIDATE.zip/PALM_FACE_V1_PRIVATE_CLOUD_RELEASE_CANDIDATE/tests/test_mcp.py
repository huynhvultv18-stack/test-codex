import asyncio,json,time
import httpx,jwt
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from pf.contracts import ROOT

def test_T38_T39_T40_real_local_transport():
 async def run():
  config=json.loads((ROOT/'.runtime/dev.json').read_text());t=int(time.time())
  token=jwt.encode({'iss':'urn:pf:dev-idp','aud':'pf-synthetic','sub':'sdk-test','iat':t,'exp':t+60,'scope':'pf:read'},config['dev_auth_key'],algorithm='HS256')
  async with httpx.AsyncClient() as h:
   unauth=await h.post('http://127.0.0.1:8088/mcp/',json={})
   assert unauth.status_code==401 and 'resource_metadata' in unauth.headers['www-authenticate']
  async with httpx.AsyncClient(headers={'Authorization':'Bearer '+token}) as h:
   async with streamable_http_client('http://127.0.0.1:8088/mcp/',http_client=h) as (read,write,_):
    async with ClientSession(read,write) as client:
     await client.initialize();listed=await client.list_tools();assert [t.name for t in listed.tools]==['pf_open_workspace'];tool=listed.tools[0]
     assert tool.outputSchema and tool.annotations.readOnlyHint
     result=await client.call_tool('pf_open_workspace',{});assert not result.isError
     out=result.structuredContent;assert out['host_integration']=='BLOCKED';assert out['personal_data_enabled'] is False
     assert not any(x in json.dumps(out).lower() for x in ('token','grant','landmark','image_data','base64'))
     resources=await client.list_resources();assert str(resources.resources[0].uri)=='ui://pf/workspace'
     evidence={'status':'PASS_LOCAL_ONLY','tools':[t.model_dump(mode='json') for t in listed.tools],'resources':[r.model_dump(mode='json') for r in resources.resources],'projection':out,'host_integration':'BLOCKED','oauth_idp':'SYNTHETIC_ONLY'}
     (ROOT/'evidence/mcp-local.json').write_text(json.dumps(evidence,indent=2))
 asyncio.run(run())
