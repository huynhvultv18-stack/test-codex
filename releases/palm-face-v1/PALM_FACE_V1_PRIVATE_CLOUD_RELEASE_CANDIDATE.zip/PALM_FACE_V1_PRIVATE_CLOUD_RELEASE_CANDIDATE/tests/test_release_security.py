"""Real process/resource and PostgreSQL regressions; no real-photo accuracy claims."""
import base64, copy, io, json, os, signal, sys, time
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from pf.common import Problem
from pf.contracts import ROOT
from pf.sandbox import execute, compute
from pf.worker import claim, run_job
from test_phase2 import env, body
from test_journey import create_five, post
from test_api_foundation import login

@pytest.mark.parametrize('response',[b'stream: OK\x00',b'stream: Eicar FOUND\x00',b'stream: ERROR\x00',b''])
def test_R03_T10_scanner_protocol_fails_closed(tmp_path,response):
    # Protocol test double only; this does not establish live malware detection.
    import socket,struct,threading
    from pf.scanning import scan
    path=str(tmp_path/'clamd.sock');received=[]
    listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);listener.bind(path);listener.listen(1)
    def read_exact(client,n):
        data=b''
        while len(data)<n:
            part=client.recv(n-len(data))
            if not part:raise EOFError()
            data+=part
        return data
    def serve():
        with listener:
            client,_=listener.accept()
            with client:
                assert read_exact(client,10)==b'zINSTREAM\x00'
                while True:
                    size=struct.unpack('!I',read_exact(client,4))[0]
                    if not size:break
                    received.append(read_exact(client,size))
                client.sendall(response)
    thread=threading.Thread(target=serve);thread.start()
    raw=b'SYNTHETIC BYTE STREAM'*5000
    try:
        if response==b'stream: OK\x00':scan(raw,path)
        else:
            with pytest.raises(Problem) as error:scan(raw,path)
            assert error.value.code=='POLICY_BLOCKED'
    finally:thread.join(timeout=5)
    assert not thread.is_alive() and b''.join(received)==raw

def test_R03_T10_scanner_unavailable_fails_closed(tmp_path):
    from pf.scanning import scan
    with pytest.raises(Problem):scan(b'synthetic',str(tmp_path/'unavailable.sock'))

def test_R11_T48_wall_timeout_kills_descendants(tmp_path):
    pidfile=tmp_path/'pid'
    script = ('import subprocess,time; '
              'p=subprocess.Popen(["sleep","60"]); '
              f'open({str(pidfile)!r},"w").write(str(p.pid)); time.sleep(60)')
    started=time.monotonic()
    with pytest.raises(Problem) as error:
        execute([sys.executable,'-c',script],{},wall_seconds=.8,cpu_seconds=1)
    assert error.value.code=='JOB_TIMEOUT' and time.monotonic()-started<3
    pid=int(pidfile.read_text())
    # Killed children may briefly remain zombies until their parent/subreaper reaps them.
    statfile=ROOT.__class__(f'/proc/{pid}/stat')
    assert not statfile.exists() or statfile.read_text().split()[2]=='Z'

def test_R13_T48_cpu_limit_is_enforced():
    script='import sys,json; from pf.sandbox_child import apply_limits; apply_limits(json.load(sys.stdin)); exec("while True: pass")'
    with pytest.raises(Problem) as error:
        execute([sys.executable,'-c',script],{},wall_seconds=5,cpu_seconds=1)
    assert error.value.code=='JOB_TIMEOUT'

def test_R13_T11_memory_limit_is_enforced():
    script='''import sys,json
from pf.sandbox_child import apply_limits
apply_limits(json.load(sys.stdin))
try:
    payload=bytearray(128*1024**2)
    outcome='UNBOUNDED'
except MemoryError:
    outcome='MEMORY_REJECTED'
print(json.dumps({'result':outcome}))
'''
    assert execute([sys.executable,'-c',script],{},wall_seconds=5,cpu_seconds=2,
                   memory_bytes=64*1024**2)=='MEMORY_REJECTED'

def test_R11_T44_cancellation_terminates_process(tmp_path):
    pidfile=tmp_path/'pid'
    script=f'import os,time; open({str(pidfile)!r},"w").write(str(os.getpid())); time.sleep(60)'
    with pytest.raises(Problem) as error:
        execute([sys.executable,'-c',script],{},wall_seconds=10,cpu_seconds=2,
                cancelled=pidfile.exists)
    assert error.value.code=='SESSION_EXPIRED'
    with pytest.raises(ProcessLookupError):os.kill(int(pidfile.read_text()),0)

def test_R03_T10_sandboxed_decode_rejects_missing_png_end():
    im=Image.new('RGB',(800,800));buffer=io.BytesIO();im.save(buffer,'PNG')
    with pytest.raises(Problem) as error:
        compute('normalize',dict(raw=base64.b64encode(buffer.getvalue()[:-12]).decode(),
                                mime='image/png',mirrored=False),wall_seconds=10,cpu_seconds=8)
    assert error.value.code=='UNSUPPORTED_MEDIA'

def test_R11_T10_rejected_raw_removed_without_image_commit(env):
    client=TestClient(__import__('pf.api',fromlist=['make_app']).make_app(env));h=login(client)
    s=post(client,'/v1/sessions',body(),h).json();sid=s['session_id']
    raw=(ROOT/'fixtures/synthetic/palm_left.png').read_bytes()
    t=post(client,f'/v1/sessions/{sid}/uploads/prepare',dict(slot='palm_left',mime_type='image/jpeg',
           size_bytes=len(raw),mirrored=False,mirror_confirmed=True,expected_session_revision=1),h).json()
    assert client.put(t['upload_path'],content=raw,headers=h).status_code==204
    r=post(client,f'/v1/sessions/{sid}/uploads/finalize',dict(ticket_id=t['ticket_id'],expected_session_revision=1),h)
    assert r.status_code==415 and r.json()['code']=='UNSUPPORTED_MEDIA'
    svc=client.app.state.service
    assert not svc.db.file(sid,t['ticket_id']).exists()
    assert client.get('/v1/sessions/'+sid).json()['images']==[]

def test_R11_T44_delete_during_decode_is_not_blocked_by_transaction(env,monkeypatch):
    import threading
    from pf.api import make_app
    from pf import sandbox
    client=TestClient(make_app(env));h=login(client);s=post(client,'/v1/sessions',body(),h).json()
    sid=s['session_id'];raw=(ROOT/'fixtures/synthetic/palm_left.png').read_bytes()
    t=post(client,f'/v1/sessions/{sid}/uploads/prepare',dict(slot='palm_left',mime_type='image/png',
           size_bytes=len(raw),mirrored=False,mirror_confirmed=True,expected_session_revision=1),h).json()
    assert client.put(t['upload_path'],content=raw,headers=h).status_code==204
    entered=threading.Event();resume=threading.Event();original=sandbox.compute;responses=[]
    def paused(*args,**kwargs):
        entered.set();assert resume.wait(5)
        return original(*args,**kwargs)
    monkeypatch.setattr(sandbox,'compute',paused)
    thread=threading.Thread(target=lambda:responses.append(post(client,f'/v1/sessions/{sid}/uploads/finalize',
                            dict(ticket_id=t['ticket_id'],expected_session_revision=1),h)))
    thread.start()
    try:
        assert entered.wait(5)
        start=time.monotonic()
        deleted=client.request('DELETE','/v1/sessions/'+sid,json={'reason':'owner_request'},headers=h)
        assert deleted.status_code==202 and time.monotonic()-start<2
    finally:
        resume.set();thread.join(10)
    assert not thread.is_alive() and responses[0].status_code==410
    assert not client.app.state.service.db.file(sid,t['ticket_id']).exists()

def test_R12_T07_finalize_replay_preserved(env):
    import uuid
    from pf.api import make_app
    client=TestClient(make_app(env));h=login(client);s=post(client,'/v1/sessions',body(),h).json()
    sid=s['session_id'];raw=(ROOT/'fixtures/synthetic/palm_left.png').read_bytes()
    t=post(client,f'/v1/sessions/{sid}/uploads/prepare',dict(slot='palm_left',mime_type='image/png',
           size_bytes=len(raw),mirrored=False,mirror_confirmed=True,expected_session_revision=1),h).json()
    assert client.put(t['upload_path'],content=raw,headers=h).status_code==204
    payload=dict(ticket_id=t['ticket_id'],expected_session_revision=1);headers={**h,'Idempotency-Key':uuid.uuid4().hex}
    first=client.post(f'/v1/sessions/{sid}/uploads/finalize',json=payload,headers=headers)
    second=client.post(f'/v1/sessions/{sid}/uploads/finalize',json=payload,headers=headers)
    assert first.status_code==second.status_code==201 and first.json()==second.json()

def test_R13_T48_queue_twenty_backpressure_actual_sessions(env):
    from pf.api import make_app
    from pf.auth import Principal
    client=TestClient(make_app(env));h=login(client);svc=client.app.state.service;sids=[]
    try:
        # Twenty-one real five-slot uploads and enqueue requests, with no compute consumer.
        for index in range(21):
            s=create_five(client,h);sids.append(s['session_id'])
            response=post(client,f'/v1/sessions/{s["session_id"]}/analyses',
                          dict(expected_session_revision=s['session_revision']),h)
            assert response.status_code==(202 if index<20 else 429),response.text
            if index==20:
                assert response.json()['code']=='RATE_LIMITED'
                assert response.headers['retry-after']=='1'
        with svc.db.tx() as c:
            assert c.execute("SELECT count(*) FROM leases WHERE state='queued'").fetchone()[0]==20
    finally:
        principal=Principal('urn:pf:dev-idp|alice',frozenset())
        with svc.db.tx() as c:
            for sid in sids:
                receipt=svc.delete(c,sid,principal);svc.purge(c,principal,receipt['deletion_id'])

def test_R11_T48_stale_lease_cannot_commit_or_fail_retry(env):
    from pf.api import make_app
    client=TestClient(make_app(env));h=login(client);s=create_five(client,h);sid=s['session_id']
    post(client,f'/v1/sessions/{sid}/analyses',dict(expected_session_revision=s['session_revision']),h)
    svc=client.app.state.service;old=claim(svc)
    with svc.db.tx() as c:
        c.execute("UPDATE leases SET until_at=now()-interval '1 second' WHERE job_id=%s",(old[0],))
    retry=claim(svc);assert retry[0]==old[0]
    run_job(svc,old)
    with svc.db.tx() as c:
        assert c.execute('SELECT state,attempt FROM leases WHERE job_id=%s',(old[0],)).fetchone()==('running',1)
        assert c.execute("SELECT count(*) FROM objects WHERE sid=%s AND kind='analysis'",(sid,)).fetchone()[0]==0
    run_job(svc,retry,isolated=True)
    assert client.get('/v1/sessions/'+sid).json()['state']=='review'

def test_R13_T50_isolated_analysis_and_pdf(env):
    from pf.api import make_app
    from pypdf import PdfReader
    client=TestClient(make_app(env));h=login(client);s=create_five(client,h);sid=s['session_id']
    svc=client.app.state.service
    post(client,f'/v1/sessions/{sid}/analyses',dict(expected_session_revision=s['session_revision']),h)
    run_job(svc,claim(svc),isolated=True)
    assert client.get('/v1/sessions/'+sid).json()['state']=='review'
    assert post(client,f'/v1/sessions/{sid}/review/confirm',dict(expected_session_revision=s['session_revision'],
                expected_annotation_revision=0,acknowledge_limitations=True),h).status_code==200
    job=post(client,f'/v1/sessions/{sid}/reports',dict(expected_session_revision=s['session_revision'],
             expected_annotation_revision=0,include_images=False,format='pdf',language='vi-VN'),h).json()
    run_job(svc,claim(svc),isolated=True)
    result=client.get('/v1/jobs/'+job['job_id']).json();assert result['state']=='succeeded',result
    pdf=client.get('/v1/reports/'+result['result_id']+'/content').content
    reader=PdfReader(io.BytesIO(pdf));assert 1<=len(reader.pages)<=10
    assert 'Lòng bàn tay trái' in '\n'.join(page.extract_text() for page in reader.pages)
    assert sum(len(page.images) for page in reader.pages)==0
