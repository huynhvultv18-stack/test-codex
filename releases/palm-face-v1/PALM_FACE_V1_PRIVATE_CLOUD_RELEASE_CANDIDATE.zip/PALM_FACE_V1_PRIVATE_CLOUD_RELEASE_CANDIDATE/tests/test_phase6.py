import copy,json,uuid,time
from datetime import timedelta
from fastapi.testclient import TestClient
import pytest,jwt
from pf.api import make_app
from pf.common import *
from pf.auth import Principal
from pf.worker import enqueue,claim,run_job,cycle
from pf.contracts import ROOT
from test_phase2 import env,svc,p,body
from test_api_foundation import login
from test_journey import create_five,reviewed,post
@pytest.fixture
def client(env):return TestClient(make_app(env))

def test_T05_scope_and_bearer_not_ui(client,env):
 t=int(time.time());token=jwt.encode({'iss':'urn:pf:dev-idp','aud':'pf-synthetic','sub':'alice','iat':t,'exp':t+60,'scope':'pf:read'},env['dev_auth_key'],algorithm='HS256')
 assert client.post('/v1/sessions',json=body(),headers={'Authorization':'Bearer '+token,'Idempotency-Key':'xx'}).status_code==403

def test_T06_cross_owner_graph(client):
 h=login(client);s=reviewed(client,h);sid=s['session_id'];iid=s['images'][0]['image_id'];grant=post(client,'/v1/asset-grants',{'session_id':sid,'asset_id':iid,'scope':'preview'},h).json()
 assert client.get(grant['asset_path']).status_code==200
 r=client.delete('/v1/sessions/'+sid,json=None) if False else None
 client.post('/dev/login',json={'account':'bob'},headers={'Origin':'http://127.0.0.1:8088'})
 for route in [f'/v1/sessions/{sid}',f'/v1/sessions/{sid}/images/{iid}/quality',f'/v1/sessions/{sid}/annotations',grant['asset_path'],f'/v1/sessions/{sid}/analyses/{s["latest_analysis_id"]}']:
  assert client.get(route).status_code==404

def test_T09_grant_expiry(client):
 h=login(client);s=create_five(client,h);sid=s['session_id'];g=post(client,'/v1/asset-grants',{'session_id':sid,'asset_id':s['images'][0]['image_id'],'scope':'preview'},h).json()
 assert dt(g['expires_at'])-now()<=timedelta(minutes=5)
 svc=client.app.state.service
 with svc.db.tx() as c:
  owner='urn:pf:dev-idp|alice';record=svc.db.get(c,g['grant_id'],owner);record['expires_at']=stamp(now()-timedelta(seconds=1));svc.db.put(c,g['grant_id'],owner,'grant',sid,record)
 assert client.get(g['asset_path']).status_code==404

def test_T44_delete_during_upload(client):
 h=login(client);s=post(client,'/v1/sessions',body(),h).json();sid=s['session_id'];raw=(ROOT/'fixtures/synthetic/palm_left.png').read_bytes();t=post(client,f'/v1/sessions/{sid}/uploads/prepare',dict(slot='palm_left',mime_type='image/png',size_bytes=len(raw),mirrored=False,mirror_confirmed=True,expected_session_revision=1),h).json()
 assert client.put(t['upload_path'],content=raw,headers=h).status_code==204
 r=client.request('DELETE','/v1/sessions/'+sid,json={'reason':'owner_request'},headers=h);assert r.status_code==202
 assert post(client,f'/v1/sessions/{sid}/uploads/finalize',{'ticket_id':t['ticket_id'],'expected_session_revision':1},h).status_code==410
 svc=client.app.state.service
 with svc.db.tx() as c:
  receipt=svc.purge(c,Principal('urn:pf:dev-idp|alice',frozenset()),r.json()['deletion_id']);assert receipt['state']=='completed'
 assert not (svc.db.root/sid).exists()

def test_T44_delete_during_analysis_fence(client,monkeypatch):
 from pf import cv
 h=login(client);s=create_five(client,h);sid=s['session_id'];j=post(client,f'/v1/sessions/{sid}/analyses',{'expected_session_revision':s['session_revision']},h).json();svc=client.app.state.service;cl=claim(svc);assert cl is not None
 original=cv.analyze
 def interrupted(*args):
  result=original(*args)
  with svc.db.tx() as c:svc.delete(c,sid,Principal('urn:pf:dev-idp|alice',frozenset()))
  return result
 monkeypatch.setattr(cv,'analyze',interrupted);run_job(svc,cl)
 assert client.get('/v1/sessions/'+sid).status_code==410
 with svc.db.tx() as c:
  assert c.execute("SELECT count(*) FROM objects WHERE sid=%s AND kind='analysis'",(sid,)).fetchone()[0]==0

def test_T44_delete_during_pdf_fence(client,monkeypatch):
 from pf import reports
 h=login(client);s=reviewed(client,h);sid=s['session_id'];post(client,f'/v1/sessions/{sid}/review/confirm',dict(expected_session_revision=s['session_revision'],expected_annotation_revision=0,acknowledge_limitations=True),h)
 request=dict(expected_session_revision=s['session_revision'],expected_annotation_revision=0,include_images=False,format='pdf',language='vi-VN');j=post(client,f'/v1/sessions/{sid}/reports',request,h).json();svc=client.app.state.service;cl=claim(svc)
 original=reports.render_pdf
 def interrupted(*args):
  out=original(*args)
  with svc.db.tx() as c:svc.delete(c,sid,Principal('urn:pf:dev-idp|alice',frozenset()))
  return out
 monkeypatch.setattr(reports,'render_pdf',interrupted);run_job(svc,cl)
 with svc.db.tx() as c:assert c.execute("SELECT count(*) FROM objects WHERE sid=%s AND kind='report'",(sid,)).fetchone()[0]==0
 assert client.get('/v1/sessions/'+sid).status_code==410

def test_T44_revoke_existing_grant(client):
 h=login(client);s=create_five(client,h);sid=s['session_id'];g=post(client,'/v1/asset-grants',dict(session_id=sid,asset_id=s['images'][0]['image_id'],scope='preview'),h).json();assert client.get(g['asset_path']).status_code==200
 assert client.request('DELETE','/v1/sessions/'+sid,json={'reason':'owner_request'},headers=h).status_code==202
 assert client.get(g['asset_path']).status_code==404

def test_T45_absolute_expiry(svc,p):
 with svc.db.tx() as c:
  v=svc.create(c,p,body());s=svc.session(c,v['session_id'],p);s['view']['created_at']=stamp(now()-timedelta(hours=25));s['view']['expires_at']=stamp(now()-timedelta(hours=1));svc.save(c,s,p)
  sid=v['session_id'];svc.db.write(sid,'orphan-temp',b'synthetic orphan')
 cycle(svc,{})
 with svc.db.tx() as c:
  s=svc.db.get(c,sid,p.owner);assert s['tombstone'] and s['state']=='expired';assert svc.db.get(c,s['deletion_id'],p.owner)['state']=='completed'
 assert not (svc.db.root/sid).exists()

def test_T46_purge_failure_retry(svc,p,monkeypatch):
 with svc.db.tx() as c:
  v=svc.create(c,p,body());r=svc.delete(c,v['session_id'],p);did=r['deletion_id'];deadline=r['purge_deadline']
  original=svc.db.purge;monkeypatch.setattr(svc.db,'purge',lambda *_:(_ for _ in ()).throw(OSError()))
  r=svc.purge(c,p,did);assert r['state']=='failed';assert r['completed_at'] is None;assert r['purge_deadline']==deadline
  monkeypatch.setattr(svc.db,'purge',original);r=svc.purge(c,p,did);assert r['state']=='completed';assert svc.delete(c,v['session_id'],p)==r

def test_T47_encrypted_payload_and_audit(svc,p):
 with svc.db.tx() as c:
  v=svc.create(c,p,body());svc.db.write(v['session_id'],'raw',b'SYNTHETIC PRIVATE TEST MARKER')
  data=svc.db.file(v['session_id'],'raw').read_bytes();assert b'SYNTHETIC PRIVATE TEST MARKER' not in data
  blob=bytes(c.execute('SELECT payload FROM objects WHERE id=%s',(v['session_id'],)).fetchone()[0]);assert b'processing_allowed' not in blob
  columns=[r[0] for r in c.execute("SELECT column_name FROM information_schema.columns WHERE table_name='audit'").fetchall()]
  assert set(columns)=={'id','action','outcome','request_id','created'}

def test_T48_crash_lease_retry_once(client):
 h=login(client);s=create_five(client,h);sid=s['session_id'];j=post(client,f'/v1/sessions/{sid}/analyses',{'expected_session_revision':s['session_revision']},h).json();svc=client.app.state.service
 first=claim(svc);assert first
 with svc.db.tx() as c:c.execute("UPDATE leases SET until_at=now()-interval '1 second' WHERE job_id=%s",(first[0],))
 retry=claim(svc);assert retry
 with svc.db.tx() as c:
  assert c.execute('SELECT attempt FROM leases WHERE job_id=%s',(j['job_id'],)).fetchone()[0]==1
  c.execute("UPDATE leases SET until_at=now()-interval '1 second' WHERE job_id=%s",(j['job_id'],))
 claim(svc)
 assert client.get('/v1/jobs/'+j['job_id']).json()['state']=='failed'

def test_T48_rate_limit(env):
 env['rate_limit']=10;c=TestClient(make_app(env));h=login(c)
 responses=[c.get('/v1/sessions/not_existing') for _ in range(11)]
 assert any(r.status_code==429 and r.headers['retry-after']=='1' for r in responses)

def test_T45_orphan_inventory_scan(svc):
 import os
 from pf.common import uid
 path=svc.db.root/uid('ses');path.mkdir();(path/'orphan.tmp').write_bytes(b'SYNTHETIC')
 stale=time.time()-86500;os.utime(path,(stale,stale));cycle(svc,{})
 assert not path.exists()

def test_T48_max_two_claims_and_queue_cap(client):
 h=login(client);svc=client.app.state.service;sessions=[]
 for i in range(3):
  s=create_five(client,h);sessions.append(s['session_id']);assert post(client,f'/v1/sessions/{s["session_id"]}/analyses',{'expected_session_revision':s['session_revision']},h).status_code==202
 one,two=claim(svc),claim(svc);assert one and two and claim(svc) is None
 run_job(svc,one);run_job(svc,two);third=claim(svc);assert third;run_job(svc,third)
 for sid in sessions:assert client.get('/v1/sessions/'+sid).json()['state']=='review'

def test_get_wrong_object_type_is_404(client):
 h=login(client);s=post(client,'/v1/sessions',body(),h).json()
 assert client.get('/v1/deletions/'+s['session_id']).status_code==404
 assert client.get('/v1/reports/'+s['session_id']).status_code==404

def test_production_cannot_be_enabled_by_dev_setting(env):
 env['mode']='production'
 with pytest.raises(RuntimeError):make_app(env)
