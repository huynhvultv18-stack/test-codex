import copy,hashlib,json
import pytest
from pf.knowledge import approved,evaluate,fusion
from pf.common import Problem,stamp
from pf.contracts import ROOT,validate

def rule():return json.loads((ROOT/'spec/locked/examples/rule_draft.json').read_text())['payload']
def test_T27_draft():
 assert evaluate([rule()],{}, {},set(),[],[])==[]
 with pytest.raises(Problem):approved(rule(),{},set(),{})
@pytest.mark.parametrize('extra',[{'expression':'__import__("os")'},{'output_category':'trait'},{'trigger':{'type':'face_ratio','value':1}}])
def test_T28_DSL_reject(extra):
 r=rule();r.update(extra)
 with pytest.raises(Exception):validate('TraditionalRule',r)
def test_T29_T31_exact_template_hash():
 r=rule();r.update(status='approved',reviewer_id='SYNTHETIC-REVIEWER',reviewed_at=stamp(),template_vi='Tên gọi lịch sử, không áp dụng đánh giá cá nhân.')
 with pytest.raises(Problem) as e:approved(r,{},set(),{})
 assert e.value.code=='POLICY_BLOCKED'
@pytest.mark.parametrize('text',['Người có mũi này đáng tin.','Bạn sẽ sống lâu và giàu.','Nói bóng gió rằng người này thông minh.','<script>steal()</script>'])
def test_T31_T32_banned_indirect_template(text):
 r=rule();r.update(status='approved',reviewer_id='SYNTHETIC-REVIEWER',reviewed_at=stamp(),template_vi=text)
 with pytest.raises(Problem):approved(r,{},set(),{})

def test_T29_T30_T34_reviewed_synthetic_rule_and_source_freeze():
 r=rule();r.update(status='approved',reviewer_id='SYNTHETIC-REVIEWER',reviewed_at=stamp(),template_vi='Tên gọi trong tư liệu synthetic, không đánh giá cá nhân.')
 id=r['source_ids'][0];locator=r['source_locators'][0];r['source_ids']=[id];r['source_locators']=[locator]
 snapshot=b'SYNTHETIC SOURCE FIXTURE ONLY - NOT HISTORICAL CORPUS'
 s=dict(source_id=id,author='Synthetic fixture author',title='Synthetic reference',edition='synthetic-v1',language='eng',tradition_id=r['tradition_id'],url='https://example.invalid/synthetic',locator=locator,rights_status='approved',status='reviewed',snapshot_sha256=hashlib.sha256(snapshot).hexdigest(),reviewer_id='SYNTHETIC-REVIEWER',reviewed_at=stamp())
 def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 templates={hashlib.sha256(r['template_vi'].encode()).hexdigest()};records={digest(s)}
 lines=[dict(line_id='lin_synthetic',status='confirmed',conventional_label=r['trigger'].get('label','life'))]
 cards=evaluate([r],{id:s},{id:snapshot},templates,lines,[],records);assert len(cards)==1;assert cards[0]['observation_refs']==['lin_synthetic']
 for key,value in [('edition','changed'),('locator','changed'),('tradition_id','wrong')]:
  changed=copy.deepcopy(s);changed[key]=value
  with pytest.raises(Problem):approved(r,{id:changed},templates,{id:snapshot},records)
 with pytest.raises(Problem):approved(r,{id:s},templates,{id:snapshot+b'changed'},records)
