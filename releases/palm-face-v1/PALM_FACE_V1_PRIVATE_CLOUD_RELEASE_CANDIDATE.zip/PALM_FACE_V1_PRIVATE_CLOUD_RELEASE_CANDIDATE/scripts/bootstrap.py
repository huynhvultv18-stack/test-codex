"""Creates only local synthetic credentials; never requests/provisions paid services."""
import json,secrets,subprocess,time,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent;runtime=root/'.runtime';runtime.mkdir(exist_ok=True,mode=0o700)
file=runtime/'dev.json';envfile=runtime/'postgres.env'
if not file.exists():
 password=secrets.token_urlsafe(32)
 file.write_text(json.dumps(dict(mode='synthetic',origin='http://127.0.0.1:8088',database_url='postgresql://pf:'+password+'@127.0.0.1:55432/pf',dev_auth_key=secrets.token_urlsafe(48),data_key=secrets.token_urlsafe(32))))
 envfile.write_text('POSTGRES_USER=pf\nPOSTGRES_DB=pf\nPOSTGRES_PASSWORD='+password+'\n')
 file.chmod(0o600);envfile.chmod(0o600)
if not envfile.exists():raise SystemExit('Existing runtime configuration requires its matching local postgres.env; do not overwrite it.')
config=json.loads(file.read_text());image='postgres@sha256:3645570cccdfa447589da9f57dd740faa29b30938e861289a5574b6ca6b03826'
check=subprocess.run(['docker','inspect','pf-dev-postgres'],capture_output=True,text=True)
if check.returncode:
 result=subprocess.run(['docker','run','-d','--name','pf-dev-postgres','--label','pf.candidate=synthetic','--memory','2g','--cpus','1','-p','127.0.0.1:55432:5432','--tmpfs','/var/lib/postgresql/data:rw,size=1073741824','--env-file',str(envfile),image,'-c','shared_buffers=64MB','-c','max_wal_size=128MB','-c','min_wal_size=32MB'],capture_output=True,text=True)
 if result.returncode:raise SystemExit('Local synthetic PostgreSQL start failed; inspect local Docker, without printing runtime secrets.')
else:
 state=json.loads(check.stdout)[0]
 if state['Config']['Image']!=image:raise SystemExit('Container-name conflict; do not stop an unrelated service.')
 if state['State']['Status']!='running':raise SystemExit('Existing DB is stopped; synthetic RAM-backed payload is ephemeral. Review and restart your own container explicitly.')
import psycopg
for i in range(30):
 try:
  with psycopg.connect(config['database_url'],autocommit=True) as c:
   if not c.execute("SELECT 1 FROM pg_database WHERE datname='pf_test'").fetchone():c.execute('CREATE DATABASE pf_test')
  break
 except psycopg.OperationalError:time.sleep(.3)
else:raise SystemExit('DB readiness failed; secrets were not printed.')
sys.path.insert(0,str(root))
from pf.storage import Store
Store(config);print('Synthetic development ready; no production IdP/host configured.')
