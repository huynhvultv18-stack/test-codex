#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.hashed.lock
.venv/bin/python scripts/bootstrap.py
.venv/bin/python scripts/generate_fixtures.py
