import os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from pf.api import make_app
import uvicorn
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parent.parent/'.runtime/matplotlib'))
uvicorn.run(make_app(),host='127.0.0.1',port=8088,access_log=False,log_level='error')
