"""Reproducible candidate ZIP, no credentials/runtime or self-referential checksum."""
from pathlib import Path
import hashlib,zipfile,json,xml.etree.ElementTree as E
root=Path(__file__).resolve().parent.parent
excluded={'.git','.runtime','.venv','node_modules','__pycache__','.pytest_cache'}
def selected():
 return sorted(p for p in root.rglob('*') if p.is_file() and not any(part in excluded for part in p.relative_to(root).parts) and p.name!='CHECKSUMS.txt')
rows=[]
for p in selected():rows.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix())
(root/'CHECKSUMS.txt').write_text('\n'.join(rows)+'\n')
out=root.parent/'PALM_FACE_V1_PRIVATE_CLOUD_RELEASE_CANDIDATE.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in selected()+[root/'CHECKSUMS.txt']:
  info=zipfile.ZipInfo('PALM_FACE_V1_PRIVATE_CLOUD_RELEASE_CANDIDATE/'+p.relative_to(root).as_posix(),(2026,10,12,0,0,0));info.external_attr=(0o100444 if 'spec/locked/' in str(p.relative_to(root)) else 0o100644)<<16
  z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for row in rows:
  digest,name=row.split('  ',1);assert hashlib.sha256(z.read('PALM_FACE_V1_PRIVATE_CLOUD_RELEASE_CANDIDATE/'+name)).hexdigest()==digest
 assert not any(any(part in excluded for part in Path(n).parts) for n in z.namelist())
digest=hashlib.sha256(out.read_bytes()).hexdigest();out.with_suffix('.zip.sha256').write_text(digest+'  '+out.name+'\n')
print(json.dumps({'archive':str(out),'files':len(rows)+1,'bytes':out.stat().st_size,'sha256':digest,'crc':'PASS','all_embedded_hashes':'PASS','runtime_excluded':True}))
