"""100 real local worker jobs of each type; synthetic data, no accuracy claim."""
import sys,json,time,statistics,resource,os,uuid,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'tests'))
from pf.contracts import ROOT
from pf.api import make_app
from pf.auth import Principal
from pf.worker import claim,run_job,enqueue
from pf.common import stamp
from fastapi.testclient import TestClient
from test_api_foundation import login
from test_journey import create_five
config=json.loads((ROOT/'.runtime/dev.json').read_text());config['mode']='synthetic';config['rate_limit']=10000;config['database_url']=config['database_url'].rsplit('/',1)[0]+'/pf_test'
client=TestClient(make_app(config));h=login(client);s=create_five(client,h);svc=client.app.state.service;sid=s['session_id'];p=Principal('urn:pf:dev-idp|alice',frozenset(),True)
results={};errors=[]
for kind in ('analysis','report'):
 values=[]
 for i in range(100):
  with svc.db.tx() as c:
   state=svc.session(c,sid,p)
   if kind=='analysis':state['view']['state']='ready'
   else:state['view']['state']='completed';state['view']['review_confirmed_revision']=state['view']['session_revision']
   svc.save(c,state,p)
   b={'expected_session_revision':state['view']['session_revision']}
   if kind=='report':b.update(expected_annotation_revision=0,include_images=False,format='pdf',language='vi-VN')
   job=enqueue(svc,c,p,state,b,kind)
  selected=claim(svc);start=time.perf_counter();run_job(svc,selected,isolated=True);elapsed=time.perf_counter()-start
  with svc.db.tx() as c:
   actual=svc.db.get(c,job['job_id'],p.owner)
   if actual['view']['state']!='succeeded':errors.append({'type':kind,'index':i,'state':actual['view']['state']})
  values.append(elapsed)
 results[kind]={'jobs':len(values),'median_seconds':statistics.median(values),'p95_seconds':sorted(values)[94],'max_seconds':max(values),'queue_time_excluded':True,'seconds':values}
source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'pf').glob('*.py'))}
info={'source_hashes':source_hashes,'mode':'synthetic fixture / actual local PostgreSQL+isolated-worker','host_cpus':os.cpu_count(),'memory_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'memory_scope':'parent peak only; not aggregate concurrent RSS','child_peak_memory_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'parallel_active_jobs':1,'reference_4vCPU_8GiB':False,'CV_evaluation':'NOT_VALIDATED','deployment_performance_gate':'BLOCKED','jobs':results,'errors':errors}
(ROOT/'evidence/performance.json').write_text(json.dumps(info,indent=2));print(json.dumps({k:v for k,v in info.items() if k!='jobs'}));print({k:{a:b for a,b in v.items() if a!='seconds'} for k,v in results.items()})
with svc.db.tx() as c:receipt=svc.delete(c,sid,p);svc.purge(c,p,receipt['deletion_id'])
if errors:raise SystemExit(1)
