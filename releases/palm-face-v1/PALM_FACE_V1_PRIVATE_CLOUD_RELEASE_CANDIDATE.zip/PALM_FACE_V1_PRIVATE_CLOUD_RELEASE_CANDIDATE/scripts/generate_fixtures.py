from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,math,sys
root=Path(__file__).resolve().parent.parent
out=root/'fixtures/synthetic';out.mkdir(exist_ok=True)
registry={}
for slot in ('palm_left','palm_right','face_front','face_left_oblique','face_right_oblique'):
    w,h=1200,900;im=Image.new('RGB',(w,h),'#eeeeee');d=ImageDraw.Draw(im)
    if slot.startswith('palm'):
        points=[(.5,.8)]+[(.25+.12*((i-1)//4),.6-.1*((i-1)%4)) for i in range(1,21)]
        points[5]=(.3,.55);points[17]=(.7,.55)
        d.rectangle((330,360,870,740),outline='black',width=4)
        for i in range(5):d.rectangle((330+i*110,160+i*12,400+i*110,430),outline='black',width=4)
        d.arc((350,350,760,850),180,295,fill='black',width=5);d.line((380,440,820,500),fill='black',width=5)
    else:
        points=[(.5+.25*math.cos(i/478*math.tau),.5+.32*math.sin(i/478*math.tau)) for i in range(478)]
        for i,p in {10:(.5,.15),152:(.5,.85),234:(.25,.5),454:(.75,.5),133:(.43,.4),362:(.57,.4),61:(.4,.65),291:(.6,.65),98:(.46,.53),327:(.54,.53),2:(.5,.58)}.items():points[i]=p
        d.ellipse((300,135,900,765),outline='black',width=5);d.line((450,360,510,360),fill='black',width=5);d.line((690,360,750,360),fill='black',width=5);d.line((480,585,720,585),fill='black',width=5)
    d.text((30,30),'SYNTHETIC GEOMETRY - NOT A PERSON - '+slot,fill='black')
    p=out/(slot+'.png');im.save(p)
    registry[hashlib.sha256(p.read_bytes()).hexdigest()]={'slot':slot,'kind':'hand' if slot.startswith('palm') else 'face','count':1,'width':w,'height':h,'points':points,'synthetic_only':True}
(out/'registry.json').write_text(json.dumps(registry,indent=2))
