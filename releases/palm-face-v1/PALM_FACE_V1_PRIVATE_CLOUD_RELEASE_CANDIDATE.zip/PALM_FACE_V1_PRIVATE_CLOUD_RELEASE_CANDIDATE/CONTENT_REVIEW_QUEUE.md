# Content review queue

Reviewer assignment: UNASSIGNED. CONTENT RELEASE = BLOCKED.

1. Owner appoints rights, historical-source and Vietnamese translation/semantic reviewers (may be same qualified person, approval explicit).
2. Verify Cheiro/Lavater edition/year/impression/printed page versus digital locator; obtain allowed offline excerpt/snapshot hash and rights evidence.
3. Translate glossary names without applying traits/health/future to owner; review references and historical bias. Exclude prohibited personalized output even if a historical book contains it.
4. For each tradition verify conflicts/priority/trigger and exactly approved source-record/template hashes. Record reviewer_id/time and immutable release.
5. Exercise draft/source/translation drift, ambiguous definitions, conflicting traditions, paraphrases/injection and forbidden individual inference; archive reviewed acceptance.
6. Owner reviews corpus release; keep all absent/pending sources disabled. No autonomous reviewer appointment or activation.
