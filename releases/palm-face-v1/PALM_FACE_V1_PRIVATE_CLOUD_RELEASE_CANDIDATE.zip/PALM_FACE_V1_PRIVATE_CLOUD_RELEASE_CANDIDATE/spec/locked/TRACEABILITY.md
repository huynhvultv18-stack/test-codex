# Ma trận yêu cầu → thiết kế → kiểm thử dự kiến

| Yêu cầu | Tài liệu/section chính | Test dự kiến |
|---|---|---|
| R01 Private Plugin/backend | ARCHITECTURE1–3, API_SPEC2–3 | T05,T06,T38,T39,T52 |
| R02 5 images | SPEC3–4, APIINV02 | T04,T41,T50 |
| R03 Quality/orientation | MODULE2, ARCHITECTURE4 | T10–T15,T21,T24 |
| R04 Palm/creases | MODULE3 | T15–T18,T25,T26 |
| R05 Facegeometry | MODULE4, APIformula registry | T19–T25 |
| R06 Tradition/source | MODULE5, SOURCE_REGISTER | T27–T32 |
| R07 Fusion | MODULE6 | T31,T33,T34,T52 |
| R08 Corrections | MODULE7, APIstate/revision | T08,T17,T18,T43 |
| R09 Viet/PDF | MODULE8 | T35–T37,T50 |
| R10 Consent/privacy | SPEC6, APIINV04 | T03,T36,T40,T47 |
| R11 Retention/delete | ARCHITECTURE6, SPEC6 | T09,T44–T47 |
| R12 Contract/API | DATA_CONTRACT, API_SPEC | T01,T02,T04–T09 |
| R13 Testcoverage | TEST_PLAN | T01–T52 |
| R14 CODEX phases | CODEX_MASTER_COMMAND | Phase gates2–6 |
| R15 Traceability | MODULE1/5/6, APIINV01/10/12/14 | T29,T34,T43 |
| R16 Abstention | SPEC5, MODULE1–4 | T14,T16,T19,T21–T23,T33 |
| R17 No individual inference | SPEC1, MODULE5–6, APIINV13 | T28,T31,T32,T52 |
| R18 Host boundaries | ARCHITECTURE3, DECISIONO01/O02 | T38–T40 |

Đây là coverage của thiết kế, không phải test execution. INV01–INV22 nằm API_SPEC; contract checks chỉ là một lớp, runtime phải kiểm INV tương ứng.
