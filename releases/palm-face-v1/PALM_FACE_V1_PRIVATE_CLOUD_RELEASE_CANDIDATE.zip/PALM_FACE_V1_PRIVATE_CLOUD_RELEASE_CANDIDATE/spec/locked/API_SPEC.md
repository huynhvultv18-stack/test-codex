# API và MCP contract — PF-SPEC-1.0.0

## 1. Quy ước

REST base `/v1`, JSON UTF-8; binary upload/download riêng. REST body dùng trực tiếp `$defs/<Name>` trong DATA_CONTRACT.json; root envelope `{document_type,contract_version,payload}` chỉ cho export/import tài liệu contract và các fixture envelope. Không bọc payload hai lần. Các `$defs` là tên contract, chưa phải class Python đã viết.

Auth OAuth access token cho MCP, UI auth/grant theo ARCHITECTURE. Không nhận owner_id/tenant_id từ client. Header `X-Request-ID` do server tạo/validate, `Idempotency-Key` bắt buộc cho POST session, upload prepare/finalize, analysis, report; PATCH/PUT/DELETE dùng expected revision hoặc tombstone. Key lưu trong hạn session (tạo session chưa có ID: trong 24 h), scope principal+method+route; replay trả cùng response, cùng key khác body →409. `expected_session_revision` trong body là khóa optimistic concurrency. `session_revision` ETag chỉ hỗ trợ caching, không thêm một cơ chế If-Match cạnh tranh. Responses có `Cache-Control: no-store` cho mọi dữ liệu cá nhân, redacted errors không stack trace/token/URL.

Scopes: `pf:read`, `pf:write`, `pf:delete`. Chủ sở hữu vẫn kiểm dù token đủ scope. Anonymous chỉ health và OAuth discovery; không public tool dữ liệu. IdP dùng issuer/resource thật do Phase 2 chốt, không đặt secret trong spec.

## 2. Routes

| Method/path | Request definition | Response definition / status | Scope |
|---|---|---|---|
| GET `/healthz` | — | HealthView /200 | none; không diagnostic chi tiết |
| GET `/.well-known/oauth-protected-resource` | — | MCP metadata chuẩn, ngoài contract nghiệp vụ /200 | none |
| POST `/v1/sessions` | SessionCreateRequest | SessionView /201 | write |
| GET `/v1/sessions/{sid}` | — | SessionView /200 | read |
| PATCH `/v1/sessions/{sid}/profile` | ProfileUpdateRequest | SessionView /200 | write |
| PATCH `/v1/sessions/{sid}/consent/preferences` | ConsentPreferencesRequest | SessionView /200 | write, UI-only; chủ động chọn ảnh trong PDF |
| POST `/v1/sessions/{sid}/uploads/prepare` | UploadPrepareRequest | UploadTicket /201 | write, UI-only |
| PUT `/v1/uploads/{tid}/content` | binary + ticket auth | empty /204 | write, UI-only |
| POST `/v1/sessions/{sid}/uploads/finalize` | UploadFinalizeRequest | ImageAsset /201 | write, UI-only |
| PUT `/v1/sessions/{sid}/images/{iid}/transform` | ImageTransformRequest | ImageAsset /200 | write, UI-only |
| GET `/v1/sessions/{sid}/images/{iid}/quality` | — | QualityResult /200 | read |
| POST `/v1/sessions/{sid}/quality/acknowledge` | QualityAcknowledgeRequest | SessionView /200 | write, UI-only |
| POST `/v1/sessions/{sid}/analyses` | AnalyzeRequest | JobView /202 | write |
| GET `/v1/jobs/{jid}` | — | JobView /200 | read |
| GET `/v1/sessions/{sid}/analyses/{aid}` | — | AnalysisSnapshot /200 | read, UI-only dense data |
| GET `/v1/sessions/{sid}/annotations` | — | AnnotationRevision /200 | read, UI-only |
| PATCH `/v1/sessions/{sid}/annotations` | AnnotationPatchRequest | AnnotationRevision /200 | write, UI-only |
| POST `/v1/sessions/{sid}/review/confirm` | ConfirmReviewRequest | ReviewConfirmation /200 | write, UI-only |
| PUT `/v1/sessions/{sid}/topics` | SelectTopicsRequest | SessionView /200 | write |
| GET `/v1/sessions/{sid}/fusion` | — | FusionResult /200 | read; completed only |
| GET `/v1/knowledge/sources` | — | SourceList /200 | read |
| GET `/v1/knowledge/rules` | — | RuleList /200 | read; không chỉnh corpus bằng owner-session API |
| POST `/v1/sessions/{sid}/reports` | ReportCreateRequest | JobView /202 | write, UI-only |
| GET `/v1/reports/{rid}` | — | ReportManifest /200 | read |
| GET `/v1/reports/{rid}/content` | auth/grant | application/pdf /200 | read, UI-only |
| POST `/v1/asset-grants` | AssetGrantRequest | AssetGrant /201 | read, UI-only |
| GET `/v1/assets/{gid}/content` | bound opaque grant | image/png hoặc application/pdf /200 | scoped grant; owner/session/fence check |
| DELETE `/v1/sessions/{sid}` | DeleteRequest | DeletionReceipt /202 (completed replay /200) | delete |
| POST `/v1/sessions/{sid}/consent/revoke` | ConsentRevokeRequest | DeletionReceipt /202 | delete |
| GET `/v1/deletions/{did}` | — | DeletionReceipt /200 | delete + receipt owner |

URL trong bảng là route thiết kế, không endpoint đang hoạt động. Không endpoint nhận ảnh qua URL tùy ý; không SSRF fetch. Corpus source retrieval chỉ trong curator pipeline không expose runtime arbitrary URL tool. Sources/rules trả toàn corpus đã phát hành có giới hạn 200 record; V1 corpus tối đa200, không pagination ngầm. Publication workflow corpus thuộc repo review/CI Phase 4, ngoài CRUD session.

## 3. MCP tool mapping

| Tool dự kiến | Mapping | Visibility / annotation |
|---|---|---|
| `pf_open_workspace` | trả resource UI và trạng thái đăng nhập; không tự tạo session/consent | model+app, readOnly |
| `pf_create_session` | POST sessions, chỉ sau consent UI đã ghi nhận | app-only, write/non-destructive |
| `pf_get_session_status` | GET session, chỉ projection ID/state/revision/expiry | model+app, readOnly |
| `pf_prepare_upload` | POST uploads/prepare | app-only, write |
| `pf_finalize_upload` | POST uploads/finalize | app-only, write |
| `pf_start_analysis` | POST analyses | model+app, write; valid consent/ready required |
| `pf_get_job` | GET jobs | model+app, readOnly |
| `pf_get_review_data` | GET analysis + annotations | app-only, readOnly |
| `pf_save_annotations` | PATCH annotations | app-only, write |
| `pf_confirm_review` | POST review/confirm | app-only, write |
| `pf_select_topics` | PUT topics | model+app, write; user requested topics only |
| `pf_get_summary` | GET fusion projection: neutral summary/limitations/card sources | model+app, readOnly |
| `pf_list_sources` | GET knowledge/sources | model+app, readOnly |
| `pf_request_pdf` | POST reports | app-only, write |
| `pf_delete_session` | DELETE sessions | model+app, destructive; explicit owner delete intent |
| `pf_get_deletion_status` | GET deletions | model+app, readOnly |

`/mcp` transport và tools JSON-RPC dùng SDK chuẩn. Tool names trên là **đề xuất**, chưa được tools/list discovery. Phase 2/5 phải so registry thật với spec. Annotation readOnly/destructive/idempotent/openWorld là hint cho host; mọi quyền, consent, revision và deletion fence vẫn enforce server. Các tool app-only/secret metadata phụ thuộc support host đã chứng minh; nếu không có thì chỉ `pf_open_workspace` dẫn tới UI auth riêng, không expose private fields cho model. File bytes dùng HTTPS UI upload, không base64 tool input.

Các thao tác ảnh gồm transform/acknowledge/grants được UI gọi REST bằng quyền UI, không bắt buộc expose tất cả là MCP tool. Không hứa upload ảnh đã đính kèm chat truy cập được; Phase 2 kiểm file bridge với synthetic trước. Người dùng được báo ảnh tự đưa vào chat có vòng đời riêng.

## 4. Validation nghiệp vụ (ngoài khả năng JSON Schema đơn thuần)

| ID | Bất biến service bắt buộc |
|---|---|
| INV01 | Mọi object ID và evidence ref tồn tại đúng principal/session; không tin ID đơn lẻ |
| INV02 | Tối đa5 slot unique; start analysis đúng5 slot; palm/face output đúng slot/input image |
| INV03 | Session expires_at = created_at+24 h; grant ≤5 min và không vượt session expiry; raw xóa trong15 min sau finalize |
| INV04 | Token audience/issuer/scope + consent version; consent timestamp server receipt chuẩn, không tin client clock |
| INV05 | Expected revision khớp, edit serialized; đang analyzing phải cancel/wait trước sửa; snapshot bất biến |
| INV06 | Upload cap bytes/server magic/MIME/pixel≤24 MP; reject animated WebP/PNG và polyglot; size declaration không phải bằng chứng |
| INV07 | Hard QC reshoot/fatal không override; soft review cần ack; vùng metric lỗi vẫn unknown |
| INV08 | Mirror xác nhận trước ready; transform tạo image revision mới và invalidation toàn downstream |
| INV09 | IDs landmark unique/dataset map khớp; observation observed chỉ đúng count21/478; không fake score từng landmark |
| INV10 | Metric observed value finite; formula whitelist + correct pixel geometry; non-observed value null/reason; no mm/beauty/trait |
| INV11 | Output oblique không có metric, không face cross-view identity matching |
| INV12 | Rule approved + source reviewed/rights/snapshot/reviewer; source locators có mapping đúng; draft không execute |
| INV13 | Card output chỉ glossary/context; policy block phẩm chất/health/future dù source nói vậy; không majority-vote fortune |
| INV14 | Line confirm chỉ trên annotation current; deletion/replace giữ audit provenance; custom SVG/HTML/script bị reject |
| INV15 | Report cần completed/review confirmed/đúng revision; include_images phải đúng lựa chọn consent hiện tại |
| INV16 | Xóa/expiry revoke grants và fence trước; cancel job; purge≤24 h; no backup/versioning payload; không resurrect |
| INV17 | Cross-account download/error không lộ existence, hash/coords; log không chứa ảnh/payload/URL secret |
| INV18 | Raw detector scores không calibration tự xưng; manual raw_score=null; người dùng sửa không thành ground truth |
| INV19 | Topic IDs nằm corpus published, user_selected_topic không đọc ảnh; thay topics bump revision/reconfirm |
| INV20 | ReportManifest hash/bytes/page count computed thực; max10 pages/15 MiB; no silent truncation |
| INV21 | Không ảnh vào model context; model projection không ảnh/mesh/grant/URL; secret separation host đã verify |
| INV22 | Deletion receipt completed chỉ khi purge inventory sạch; failed có error/retry plan, deadline không âm thầm kéo dài |

JSON Schema không kiểm quyền sở hữu, tham chiếu tồn tại, phép tính thời gian, công thức hoặc ngữ nghĩa văn bản. Check cả schema và INV; pass schema một mình không đủ.

## 5. State transitions chi tiết

| Trigger | From | To / tác dụng |
|---|---|---|
| Create | — | created, revision1 |
| Prepare/content | created/uploading/quality_review/ready/review/completed | uploading; chặn khi analyzing, grant/ticket không tăng revision nếu chưa đổi canonical |
| Finalize/replace | uploading | quality_review; swap slot atomic, tăng revision, old image retired, report revoked |
| QC đủ5 + mirror confirmed | quality_review | ready nếu tất cả accept; review warning chờ ack; reshoot/fatal giữ quality_review |
| Ack warnings | quality_review | ready nếu INV07 thỏa |
| Analyze accepted | ready/failed (retry khi snapshot vẫn hợp lệ) | analyzing, job snapshot |
| Analyze success | analyzing | review; baseline annotation_revision0; session revision không tăng vì không đổi input |
| Analyze error | analyzing | failed; không report |
| Patch annotations | review/completed | review, session+annotation revision tăng; derived snapshot/metrics/cards refresh atomic, revoke report |
| Confirm review | review | completed; limitations acknowledged, confirmed revision recorded |
| Profile/topics change | created/uploading/quality_review/ready/review/completed | tăng revision; khi có analysis thì review và recompute derived snapshot; trước analysis giữ QC/ready hợp lệ |
| Image transform | quality_review/ready/review/completed | quality_review, image+session revision tăng, annotations trên ảnh cũ không áp ảnh mới |
| Report request | completed | session giữ completed; report job riêng |
| Delete/revoke | mọi active state | deleting, revoke access; khi purge done→deleted |
| TTL reached | mọi active state | expired, revoke access và enqueue purge; tombstone vẫn expired sau purge, receipt completed |

`failed` retry không áp cho consent/quality/policy lỗi. Không commit output nếu input revision đổi hoặc tombstone active. GET session sau deleted/expired trả410 cho owner trong lúc còn tombstone; cross-owner vẫn404. Deletion receipt vẫn truy cập riêng trong audit retention30 ngày. Sau tombstone TTL30 ngày cả owner trả404. Không expose listing toàn bộ session trong V1.

SessionView giữ `latest_analysis_id` và `review_confirmed_revision`, null trước analysis/review. Consent preference đổi tăng session revision, revoke report cũ và cần review xác nhận lại; không bật ảnh trong PDF chỉ bằng ReportCreateRequest. Upload ticket hết hạn khi chưa finalize phục hồi trạng thái của canonical snapshot trước đó; không xóa slot cũ vì upload mới thất bại. Content type/size/decoder lỗi không tạo canonical ImageAsset. ConsentCreate ở SessionCreateRequest là self attestation; chỉ thực hiện từ UI action của owner, không coi text do model sinh là consent. `accepted_at` client chỉ thời điểm khai báo; server thay bằng thời điểm nhận/xác thực và lưu dấu hành động consent trong audit.

## 6. Lỗi và retry

Mọi lỗi REST nghiệp vụ body theo `$defs/Error`; không root envelope. MCP auth lỗi là HTTP401 chuẩn + `WWW-Authenticate`, không chỉ tool-level error. MCP nghiệp vụ dùng `isError=true` và sanitized Error; không leaked Python traceback.

| HTTP | Error code thường gặp | Client action |
|---|---|---|
| 400/422 | VALIDATION_ERROR, CONSENT_REQUIRED, QUALITY_BLOCKED, POLICY_BLOCKED, SOURCE_NOT_APPROVED | Sửa dữ liệu/thao tác; không retry vô hạn |
| 401 | UNAUTHENTICATED | Auth host/IdP lại |
| 403 | FORBIDDEN | Scope không đủ; không bypass |
| 404 | NOT_FOUND | Không tiết lộ owner khác |
| 409 | REVISION_CONFLICT, INVALID_STATE, SLOT_CONFLICT | Refetch và review, không blind overwrite |
| 410 | SESSION_EXPIRED, UPLOAD_EXPIRED | Session/ticket mới; không tái kích hoạt session cũ |
| 413/415 | FILE_TOO_LARGE, PIXEL_LIMIT, UNSUPPORTED_MEDIA | Chọn/convert ảnh hợp lệ |
| 429 | RATE_LIMITED | Retry-After; MVP 10 request/s/principal, 1 analysis active/session, queue cap 20 |
| 500/503 | INTERNAL_ERROR, MODEL_MISMATCH, REPORT_FAILED, PURGE_FAILED | Theo retryable; chưa đủ bằng chứng thì error |

Timeout thường trả JobView failed với JOB_TIMEOUT thay vì giữ request120 s. Client poll 2s ban đầu, backoff tới10s; dừng khi terminal/expiry; refresh không tạo job mới. Cancellation do deletion →cancelled, không exception thay vì purge.

## 7. Formula registry khóa

| Metric ID | Formula ID | Evidence |
|---|---|---|
| face_height_width_ratio | face_hw_v1 | front points10,152,234,454 |
| intercanthal_face_width_ratio | face_intercanthal_v1 | front133,362,234,454 |
| mouth_face_width_ratio | face_mouth_width_v1 | front61,291,234,454 |
| nose_face_width_ratio | face_nose_width_v1 | front98,327,234,454 |
| left_right_contour_asymmetry_2d | face_asymmetry_2d_v1 | front234,454,10,152 |
| line_length_palm_width_ratio | palm_arc_width_v1 | confirmed polyline + hand5,17 |
| line_straightness_ratio | palm_chord_arc_v1 | confirmed polyline |
| line_visible_branch_count | palm_branch_count_v1 | confirmed graph/owner branches |

Formula details trong MODULE_DESIGN. Evidence ID ghép namespace image+landmark/line, không reuse cùng ID giữa hai tay mà mất nguồn. Các metric thuộc line là descriptors; branch_count không observed khi graph chưa reviewed. Code Phase 2 phải validate finite float; JSON NaN/Infinity bị reject dù parser Python mặc định có thể cho phép.
