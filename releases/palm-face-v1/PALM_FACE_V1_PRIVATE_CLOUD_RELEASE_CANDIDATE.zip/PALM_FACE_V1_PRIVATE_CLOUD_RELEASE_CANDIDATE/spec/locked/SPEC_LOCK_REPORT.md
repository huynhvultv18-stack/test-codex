# Biên bản kiểm tra và khóa đặc tả — PF-SPEC-1.0.0

Ngày 12/10/2026. Đối tượng kiểm: tài liệu thiết kế và schema hợp đồng; không phải ứng dụng hoạt động. Contract 1.0.0, policy PF-POLICY-1.0.0.

## 1. Bằng chứng kiểm tự động đã thực hiện

Validator thực dùng: Python `jsonschema 4.26.0`, Draft 2020-12, format checker. Chạy trên nội dung DATA_CONTRACT.json và fixture synthetic, không chạy Python backend/CV/Plugin.

| Hạng mục đã chạy | Kết quả |
|---|---|
| Schema kiểm theo meta-schema Draft 2020-12 | PASS |
| Local JSON references: 74 tham chiếu | PASS; không dangling reference |
| 49 definitions, 33 loại document envelope | Cấu trúc hợp lệ |
| 10 trường hợp contract hợp lệ (gồm 5 fixture trong gói) | PASS |
| 23 trường hợp lỗi phải bị từ chối | PASS; unknown key, consent sai, date lỗi, point ngoài miền, null/value sai, thiếu reason, count sai, oblique ratio, rule review/category sai, line thiếu điểm, upload lỗi, annotation eval, version sai |
| JSON NaN/Infinity parser policy | PASS cho kiểm từ chối NaN; runtime cần enforce finite tất cả trường |
| API named request/response references | PASS; tên trong bảng có definition tương ứng |
| INV01–INV22, R01–R18 và T01–T52 có mặt | PASS cho coverage văn bản, chưa test runtime |
| 7 đầu ra bắt buộc và loại file chỉ tài liệu | PASS |
| Không ảnh cá nhân, không source ứng dụng trong gói | PASS |
| Suy dẫn hình học trên fixture ảnh không vuông và mirror | PASS; ratio pixel tham chiếu 0.5, cách dùng normalized distance trực tiếp sẽ ra 1.0 |

Tổng **45 kiểm tài liệu/schema/suy dẫn synthetic: 45 PASS, 0 FAIL**. Chi tiết từng check trong VALIDATION_EVIDENCE.json. Đây không phải 45 test runtime. Danh sách 52 test trong TEST_PLAN là kế hoạch tương lai, chưa thực thi.

## 2. Kiểm tra nhất quán bằng rà soát thiết kế

| Nội dung đối chiếu | Kết luận |
|---|---|
| 5 slot giống nhau giữa spec, schema, API, modules, CODEX | PASS |
| Metric chỉ front, pixel conversion rõ, oblique không có ratios | PASS |
| Manual/machine provenance, revision, report invalidation | PASS; snapshot/derived output không ghi đè bản máy |
| Các module Quality/Palm/Face/TKE/Fusion/UI/Report có input/output, giới hạn và fallback | PASS |
| Observation tách card truyền thống; không inference cá nhân hoặc fortune score | PASS |
| TKE source/locator/review/version, draft disabled | PASS; nguồn face/Asian còn gate, không được tự kích hoạt |
| Auth/asset channel/TTL/delete/backup và log retention nhất quán | PASS: 24 h session, 15 min raw sau finalize, 5 min grant tối đa, 30 ngày audit,≤24h purge |
| Consent preference và báo cáo có ảnh thống nhất | PASS; consent chủ động, default không raster cá nhân |
| Host support và fallback xác thực | PASS về phương án thiết kế; capability account chưa kiểm |
| Trạng thái và lỗi có abstention, không bù thiếu ảnh bằng lời luận | PASS |
| R01–R18 nối với test plan, INV01–INV22 có trách nhiệm service | PASS |

Các lỗi phát hiện khi soạn đã sửa trước khóa: locator đường trí đạo trong Cheiro là Part I/Chapter II; ImageAsset cho phép ghi nhận canonical ảnh dưới ngưỡng để hiển thị QC reshoot thay vì tự mâu thuẫn schema; bổ sung transform matrix, selected topics, latest analysis/review revision, consent preferences; đo tỷ lệ theo pixel trên ảnh không vuông. Không còn mâu thuẫn thiết kế đã biết thuộc phạm vi khóa.

## 3. Kiểm tra tính khả thi

| Thành phần | Kết luận ở mức thiết kế |
|---|---|
| Landmark hand/face | Có SDK/model route được tài liệu gốc mô tả; phiên bản/semantic map/platform vẫn cần spike |
| Đường chỉ | Khả thi như candidate + manual tracing; chưa có bằng chứng tự động trên ảnh thật, không hứa tự động đạt |
| Private Plugin | Có tuyến MCP/OAuth/UI và fallback; account/hosting thật là gate Phase2/5 |
| TKE kiểm nguồn | Schema và workflow review khả thi; corpus mặt/Đông Á chưa đầy đủ, bị khóa inactive |
| Fusion/report | Deterministic template/evidence graph; không cần LLM hoặc fortune predictor |
| Privacy/delete | Thiết kế thu hồi asset gateway, tombstone/fence, purge inventory và no-backup có thể hiện thực; cần test lỗi/thời hạn thật |

Thiết kế đủ để bắt đầu Phase 2; chưa đủ để tuyên bố model accurate, Plugin connected hoặc Production Ready. Các điều kiện O01–O08 trong DECISION_LOG vẫn mở đúng phase. Việc đó là kế hoạch kiểm chứng có gate, không phải bằng chứng đã PASS.

## 4. Quy tắc khóa và bàn giao

Bảy đầu ra bắt buộc, tài liệu phụ và fixture được hash trong SHA256SUMS.txt; checksum file không tự hash chính nó. ZIP chứa một thư mục PALM_FACE_V1_PHASE1_SPEC_LOCK, không source build, secrets, ảnh hoặc dependencies kiểm tra. Quy trình đóng gói kiểm CRC, đối chiếu toàn bộ entry và SHA-256 nội dung file. SHA-256 của ZIP được tính ngoài ZIP để tránh self-reference.

Khóa tại version 1.0.0. CODEX phải kiểm hash, đọc toàn bộ gói và giữ bản khóa read-only; tạo repo làm việc khác. Thay slot/schema/TTL/policy/auth boundary/source activation contract phải change request và version mới. Không bắt đầu Phase 2 trong phiên Phase 1 này.

PHASE 1 = PASS

SPEC LOCK = YES

READY FOR CODEX = YES

PRODUCTION READY = NO — chưa lập trình hoặc kiểm runtime.
