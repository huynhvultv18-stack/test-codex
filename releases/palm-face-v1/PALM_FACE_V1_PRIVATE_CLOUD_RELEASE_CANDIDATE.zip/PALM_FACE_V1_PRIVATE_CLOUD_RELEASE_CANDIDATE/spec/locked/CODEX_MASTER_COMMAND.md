# CODEX MASTER COMMAND — PALM & FACE V1.0 — PHASE 2 ĐẾN PHASE 6

Tài liệu là lệnh chuẩn bị cho phiên CODEX tiếp theo. Phase 1 không thực thi lệnh này. Đọc README, SPEC_LOCK_REPORT và SHA256SUMS trước; dùng chính gói `PALM_FACE_V1_PHASE1_SPEC_LOCK.zip`, spec `PF-SPEC-1.0.0`, contract 1.0.0. Không tái tạo yêu cầu từ trí nhớ.

## Lệnh giao CODEX (toàn bộ phần dưới)

Bạn là kỹ sư phụ trách hiện thực PALM & FACE ANALYSIS V1.0 theo spec đã khóa. Thực hiện liên tục phần được phép Phase 2 → Phase 6, giữ nguyên mọi yêu cầu R01–R18 và INV01–INV22. Không sửa spec khóa để làm test pass; thay đổi bắt buộc tạo SPEC_CHANGE_REQUEST.md với lý do/ảnh hưởng/version và xác định việc nào bị chặn. Không tự thu thập ảnh của user hoặc scrape ảnh người khác. Chỉ synthetic hoặc dữ liệu có quyền sau gate consent/license. Không triển khai hoặc provision dịch vụ tốn phí khi chưa có scope/credentials của owner; chuẩn bị bản reviewable, tiếp tục việc độc lập và report BLOCKED phần thiếu.

Không suy phẩm chất, trí tuệ, sức khỏe, tuổi thọ, tài chính, hôn nhân, danh tính hoặc số mệnh từ ảnh. Không gọi lời luận truyền thống là accurate/validated. V1 TKE là glossary/cultural context có nguồn, không assessment cá nhân. Không dùng LLM cho CV/corpus/PDF MVP. Không huấn luyện bằng session cá nhân. Không đưa ảnh/embedding/mesh/asset grant vào model context.

### PHASE 2 — FOUNDATION & CAPABILITY SPIKE

1. Hash gói/file bắt buộc, kiểm spec ID/version và đủ 7 file; giữ `spec/locked/` read-only, tạo repo working mới riêng. Không ghi secrets/data thật vào git.
2. Kiểm account/host capabilities bằng official docs hiện hành và synthetic test: MCP Streamable HTTP/OAuth, UI resource, app-only tools, secret/bootstrap channel, picker, CSP, canvas, file bridge. Nếu thiếu widget capability, dựng UI HTTPS có login độc lập; không hứa tự đọc attachment từ chat. Ghi host/account access chưa xác minh là BLOCKED.
3. Chọn container runtime hỗ trợ Python/MediaPipe Tasks, pin phiên bản và model hashes/rights; semantic map QA plan. Chọn IdP/region/storage/budget cụ thể trước real deployment. Dev IdP/mock chỉ synthetic, không đổi thành production auth.
4. Hiện thực contract schema validator chính thức 2020-12 + format checks + finite float + service INV validators; API skeleton, principal ownership, idempotency, revisions, job lease, TTL/tombstone/purge interface. Fixtures gồm valid và negative cases.
5. Consent action chỉ UI owner, session 24 h, no backup/versioning payload, asset gateway có thể thu hồi, TTL ≤5 min; không signed public download mà không thu hồi được.

Đầu ra: repo skeleton, dependency/model/license register, host compatibility matrix, PHASE2_REPORT.md, contract test evidence. Gate:T01–T09 đạt trên synthetic, auth/consent/revision/purge foundation rõ. Chưa đạt host không làm dừng geometry local nhưng không gọi Plugin ready.

### PHASE 3 — QUALITY, PALM, FACE & MANUAL REVIEW

1. Normalize image EXIF/mirror một lần, RGB/canonical coordinate transforms; decoder/malware/pixel/file caps 20 MiB/24 MP/JPEG/PNG/WebP tĩnh. Không hỗ trợ HEIC âm thầm.
2. Quality Engine phân biệt hard fail/soft warning, roi blur/glare/occlusion/object count/pose; chủ thể/tay đúng slot do owner xác nhận. Không chỉ detector max=1 rồi chấp nhận nhiều người.
3. Hand Landmarker 21 points và Face Landmarker 478 points adapter, map semantics test trước ratios; không identity/blendshapes. Missing/low quality→null reason.
4. Palm crease pipeline classic riêng; candidate polylines và manual add/replace/delete/confirm/reject/label. Không claim MediaPipe nhận đường chỉ. Không training model riêng trong V1.
5. Face front-only ratios theo formula registry, pixel-space distances trước ratios, oblique metrics=[]; không mm/hairline/golden ratio/beauty. Annotation revision và provenance tách machine/manual, report invalidation.
6. Synthetic geometry tests trước. Dataset evaluation pilot có rights/consent/protocol riêng, không tự xin user ảnh trong phase này khi chưa có scope. Thiếu dataset→CV_ACCURACY_NOT_VALIDATED, giữ assisted mode. Không báo synthetic chứng minh accuracy trên người thật.

Đầu ra: engines+review primitives, PHASE3_CV_REPORT.md, configuration/version freeze, validation metrics hoặc pending rõ, manual mode acceptance. Gate:T10–T26, math/revision correct; auto-line phải ghi đúng mode đạt hay chưa.

### PHASE 4 — KNOWLEDGE, FUSION & VIETNAMESE REPORT

1. Curate approved source snapshot/hash/edition/locator/rights/reviewer. Cheiro chỉ base glossary đã kiểm; Lavater candidate chưa active; nguồn Đông Á/Vietnam chưa chọn không được bịa. Record từng tradition riêng và review translated term.
2. Rule DSL finite trigger confirmed_line_label/user_selected_topic; draft/unknown source disabled. Không eval, injection hay instructions trong nguồn. Chỉ output glossary/cultural context; cấm gán tính cách/sức khỏe/tương lai lên ảnh dù tác giả cổ nói vậy.
3. Fusion deterministic neutral summary, evidence graph, missing/conflict giữ riêng; không điểm vận mệnh / tăng confidence. Policy gate tại server và template allowlist.
4. Report tiếng Việt có visual overlays đúng canonical, ảnh cá nhân mặc định tắt, consent toggle explicit. PDF A4 Unicode có thể chọn được font có quyền sử dụng, sources/version/limits. Render tất cả trang để QA; no generative illustrative photo.
5. Tests T27–T37, review nội dung ngữ nghĩa không chỉ keyword; source/tradition/evidence coverage 100%.

Đầu ra: corpus version+review records, rule tests, deterministic fusion, PDF sample synthetic, SOURCE_REVIEW.md và PHASE4_REPORT.md. Thiếu face traditional corpus→section ghi chưa có nguồn đã duyệt, không tự thay bằng nguồn phương Tây gọi Đông Á. Nếu cam kết delivery toàn bộ face corpus thì gate đó BLOCKED cho đến curate xong.

### PHASE 5 — PRIVATE PLUGIN & UI INTEGRATION

1. Đăng ký MCP tools/resources/annotations theo SDK pin và capability spike; kiểm tools/list/output schema/current metadata. Giữ model projection tối thiểu, dữ liệu chi tiết chỉ cho UI và raw upload HTTPS.
2. UI 5 slots, capture guide, consent/QC, mirror/side, canvas/keyboard/zoom, save/review confirm, PDF preview/download/delete. UI fallback có đăng nhập không bỏ auth. Browser reload không mất revision/job;409 không ghi đè không kiểm tra.
3. Liên kết MCP principal và UI principal bằng server-verified auth, không lấy owner_id do widget gửi. CORS/CSP/CSRF/Origin validation; asset gateway và grant expiry/revoke.
4. Chỉ kết nối/install Plugin riêng tư khi owner cung cấp/quyền cho việc đó trong phiên triển khai; không publish directory/shared workspace. Có thể test SDK/MCP local synthetic trước.
5. Tests T38–T43 gồm host thật nếu accessible; host chưa có access→BLOCKED, không screenshot/mockup thay runtime evidence.

Đầu ra: private plugin package/manifest đã validate, UI, HOST_INTEGRATION_REPORT.md, PHASE5_REPORT.md, fallback guide. Không được PASS integration nếu chưa kết nối được host target thật.

### PHASE 6 — ACCEPTANCE, PRIVACY, PERFORMANCE & HANDOFF

1. Run full journey, 5 slots, metadata, QC, manual correction, source rules, report/export, expiry/delete và cross-owner access. Test delete giữa upload/analysis/PDF; fence before commit, orphan/temp/cache purge và receipt inventory.
2. Kiểm storage config không backup/versioning/soft delete session payload; encrypted private ACL. Audit metadata 30 ngày, logs redacted, consent retention/provider region được chốt. Không tuyên bố chứng nhận pháp lý.
3. Đo p95 analysis≤60 s/PDF≤20 s với 4 vCPU, 8 GiB,≥100 jobs, max 2 active, timeout analysis 120 s/PDF 60 s; báo dataset/queue exclusion/memory/error. Chỉ target đạt theo đo, không hardcode PASS.
4. Run CV độc lập evaluation protocol; thiếu quyền/dataset→NOT_VALIDATED, không tự dùng ảnh owner. Auto-line chưa đạt thì acceptance ghi assisted mode; face/hand geometry/missing behavior vẫn phải đạt.
5. Tests T44–T52 và regressions theo thay đổi. P0/P1=0 mới Production Ready YES. Hosting/host credentials thiếu→BLOCKED/NO, vẫn bàn giao candidate local tested.
6. Bàn giao source, install/run/review/delete guides, dependency lock/SBOM/model hashes, corpus release/source/license, evaluation/test reports, evidence index, changelog và candidate ZIP checksums. Không tự nâng Production/công khai dịch vụ.

Đầu ra: `PALM_FACE_V1_CANDIDATE.zip`, ACCEPTANCE_REPORT.md, EVIDENCE_INDEX.md, CHECKSUMS.txt, hướng dẫn owner. Kết thúc trạng thái từng phase PASS/FAIL/BLOCKED, CV MODE AUTO_VALIDATED/ASSISTED, HOST INTEGRATION PASS/BLOCKED, PRODUCTION READY YES/NO. Không biến pending thành PASS.

### QUY TẮC LÀM VIỆC LIÊN TỤC

- Hoàn thành phần độc lập khi thiếu credential/decision; chỉ dừng bước phụ thuộc, liệt kê blocker cụ thể.
- Không hỏi lại các mặc định đã LOCKED; lựa chọn triển khai thường lệ theo spec và kết quả spike.
- Không mở quyền anonymous để vượt auth, không gửi ảnh sang dịch vụ khác để tránh local model failure.
- Mỗi phase có CHANGELOG/EVIDENCE/TESTREPORT và hash. Thay model/corpus/threshold/policy version vô hiệu evidence tương ứng và retest đúng phạm vi.
- Chỉ nói kết quả đã chạy; screenshots chỉ từ runtime thực và không chứa credentials hoặc ảnh người không cho phép. Không commit người dùng image vào repo/evidence gói công khai.

## Ước lượng và dependencies (để lập kế hoạch, chưa cam kết)

| Phase | Ước lượng ngày kỹ thuật | Phụ thuộc chính |
|---|---|---|
|2|2–3| Account/capability, host/IdP/compute choice |
|3|4–7| Compatible model, semantic map, evaluation rights |
|4|2–4| Corpus review, source/translation rights, font |
|5|2–3| Private target host/OAuth/UI tested |
|6|2–4| E2E deployment, dataset/time for purge/load tests |

Tổng 12–21 ngày kỹ thuật cho MVP, không bao gồm chờ quyền, nguồn/domain review, dataset recruitment hoặc account provisioning. Không phải dự toán chi phí provider. Có thể tiến hành UI/fallback và corpus review song song về lịch, nhưng không cần multiagent và không thay gate.
