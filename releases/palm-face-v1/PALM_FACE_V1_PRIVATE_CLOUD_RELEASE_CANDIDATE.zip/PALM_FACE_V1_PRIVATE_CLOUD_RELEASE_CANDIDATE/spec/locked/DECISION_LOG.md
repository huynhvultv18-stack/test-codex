# Quyết định và điều kiện triển khai

| ID | Trạng thái | Quyết định / việc cần xác minh | Gate và cách xử lý |
|---|---|---|---|
| D01 | LOCKED | Cloud Plugin riêng tư + Python backend riêng | Không triển khai Phase 1 |
| D02 | LOCKED | 5 slot: palm L/R, face front/L-oblique/R-oblique | Đổi số/loại ảnh cần spec 1.1 |
| D03 | LOCKED | Không đánh giá phẩm chất, sức khỏe, tương lai từ ảnh | Rule/policy/filter/test phía server |
| D04 | LOCKED | Traditional là glossary/context có nguồn | Tách chương, không kết luận cá nhân |
| D05 | LOCKED | Front-only 2D ratios, không mm/3D | Mapping/pose chưa QA → metric disabled |
| D06 | LOCKED | Review thủ công và assisted crease fallback | Auto-line chưa đạt không claim tự động đạt |
| D07 | LOCKED | TTL tuyệt đối 24 h, không backup payload | Purge gate trước dữ liệu thật |
| D08 | LOCKED | 18+ ảnh chính chủ tự khai, không suy tuổi/identity | Consent trước upload |
| D09 | LOCKED | Tay thuận default right, có thể sửa | Không quy tắc giới tính/tay |
| D10 | LOCKED | Không dùng LLM/OpenAI API trong MVP engine/report | Thêm API ngoài phải change request |
| D11 | LOCKED | Không train trên session cá nhân | Evaluation corpus có consent/license riêng |
| D12 | LOCKED | JSON Schema 2020-12 + service invariants | Không nhầm schema với mọi business constraints |
| O01 | OPEN / P2 gate | Account/workspace có quyền custom Plugin/MCP App | Spike với synthetic; không có → private HTTPS UI; host integration ghi BLOCKED |
| O02 | OPEN / P2 gate | UI upload/bootstrap secret channel/CSP | Không đảm bảo kín với model → login UI độc lập; không public URL ảnh |
| O03 | OPEN / P2 gate | Hosting/region/IdP/budget của owner | Local dev mock trước; không dùng dữ liệu thật trước quyết định cụ thể |
| O04 | OPEN / P2 gate | Python/SDK/model assets versions và licenses | Compatibility matrix + lockfile/SBOM/checksum |
| O05 | OPEN / P2–P4 gate | Corpus truyền thống face/Đông Á/Vietnam | Không active rule nếu chưa có locator/review/rights; không tự trộn Cheiro/Lavater |
| O06 | OPEN / P3 gate | QC/crease calibration và tập evaluation có quyền | Synthetic trước; dataset có consent riêng sau; chưa đạt → assisted mode |
| O07 | OPEN / P6 gate | Nơi lưu và văn bản consent thực tế | Kiểm cấu hình/nhà cung cấp; không tuyên bố compliance pháp lý chưa kiểm |
| O08 | OPEN / P6 gate | Hiệu năng p95/thiết bị/browser host | Đo thực tế; không dùng target thành kết quả |

Không có câu hỏi mở làm thay đổi contract trong bản khóa. Các OPEN là bằng chứng cần thu ở phase tương ứng. Thay TTL, auth boundary, slot, field schema, policy hoặc cơ chế dùng ảnh phải làm change request, đánh giá ảnh hưởng và phiên bản mới; không edit bản 1.0.0 đã hash. Phase 1 PASS không tự đóng O01–O08.
