# PALM & FACE ANALYSIS V1.0 PROFESSIONAL — Đặc tả khóa Phase 1

- Spec ID: `PF-SPEC-1.0.0`; contract: `1.0.0`; policy: `PF-POLICY-1.0.0`.
- Ngày: 12/10/2026, múi giờ Asia/Ho_Chi_Minh.
- Trạng thái: khóa thiết kế sau kiểm tra trong `SPEC_LOCK_REPORT.md`.
- Phase 1 chỉ tạo tài liệu, hợp đồng dữ liệu và kiểm tra tài liệu. Không tạo ứng dụng, triển khai, kết nối Plugin hoặc thu thập ảnh cá nhân.
- PROFESSIONAL chỉ mức tổ chức phần mềm, truy xuất nguồn và kiểm soát chất lượng; không biểu thị khả năng dự đoán vận mệnh.

## 1. Mục tiêu và ranh giới

Ứng dụng riêng tư giúp một người trưởng thành quan sát hai lòng bàn tay và gương mặt của chính mình: điểm mốc, đường/nếp gấp nhìn thấy, tỷ lệ hình học 2D, ảnh có lớp đánh dấu và chỉnh sửa. Một thư viện riêng cung cấp tên gọi, biểu tượng và quan niệm lịch sử có nguồn. Hai lớp luôn có nhãn khác nhau.

Không đánh giá tính cách, trí tuệ, đạo đức, mức đáng tin, trạng thái cảm xúc, bệnh lý, sức khỏe, tuổi thọ, tài chính, hôn nhân hay tương lai của người trong ảnh. Không suy ra chủng tộc, giới tính, tôn giáo, xu hướng tính dục, danh tính hoặc tuổi từ khuôn mặt. Không chấm điểm sắc đẹp hoặc chuẩn tốt/xấu theo tỷ lệ. Gắn nhãn “truyền thống” không làm các kết luận đó trở thành dữ liệu quan sát.

Diễn giải truyền thống trong V1 là **nội dung văn hóa có dẫn nguồn**, tách khỏi kết luận cá nhân. Ví dụ: “Tên ‘sinh đạo’ là tên gọi theo một hệ chỉ tay; tên này không đo tuổi thọ.” Không viết “đường của bạn dài nên bạn sống lâu”. Quy tắc được phép nối một đường do người dùng xác nhận với mục từ lịch sử, không nối tỷ lệ khuôn mặt với phẩm chất của người dùng. Fusion không cộng mức đồng thuận giữa hai nguồn thành độ tin cậy của vận mệnh.

## 2. Yêu cầu có mã

| Mã | Yêu cầu khóa | Tiêu chí thiết kế |
|---|---|---|
| R01 | Plugin cloud riêng tư, backend Python riêng | OAuth, kiểm tra chủ sở hữu từng đối tượng, không endpoint dữ liệu công khai |
| R02 | Chính xác 5 vị trí ảnh | 2 palm + 3 face; thay ảnh theo vị trí, không tạo vị trí thứ sáu |
| R03 | Chất lượng và hướng ảnh | Máy chủ kiểm tra lại; mirror/left/right do người dùng xác nhận |
| R04 | Palm Engine | 21 landmark khi hợp lệ; đường chỉ là pipeline riêng; cho phép từ chối và vẽ tay |
| R05 | Face Engine | Adapter 478 landmark; chỉ tỷ lệ 2D có định nghĩa; không nhận dạng người |
| R06 | Traditional Knowledge Engine | Nguồn, vị trí trích, hệ truyền thống, người duyệt, phiên bản; rule chưa duyệt không chạy |
| R07 | Fusion Engine | Tổng hợp quan sát và thiếu dữ liệu; không dự đoán, không điểm nhân tướng |
| R08 | Hiệu chỉnh có lịch sử | Revision, lưu bản máy/bản chỉnh riêng, tính lại kết quả phụ thuộc |
| R09 | Báo cáo tiếng Việt | Chương quan sát, chương văn hóa, giới hạn, nguồn; overlay và PDF tùy chọn ảnh |
| R10 | Đồng ý trước upload | Chỉ ảnh của chính người dùng 18+ tự xác nhận; không suy tuổi từ ảnh |
| R11 | Lưu/xóa | Hạn tuyệt đối 24 h; xóa ngay quyền truy cập; purge không quá 24 h sau yêu cầu |
| R12 | Contract/API | JSON Schema 2020-12, enum chặt, lỗi và kiểm tra tham chiếu phía service |
| R13 | Thiết kế kiểm thử | Contract, hình học, chỉnh sửa, nguồn, an toàn, quyền riêng tư, UI, PDF, MCP |
| R14 | Kế hoạch Phase 2–6 | Mỗi phase có gate, bằng chứng và trạng thái; không tự nâng Production |
| R15 | Truy vết | Mỗi con số → công thức → landmark/line → image/revision; mỗi thẻ → source/rule |
| R16 | Từ chối khi thiếu bằng chứng | `null` kèm lý do; không biến không thấy thành không có |
| R17 | Giới hạn suy luận | Chính sách quyết định ở server, danh sách trường cho phép, kiểm thử đối kháng |
| R18 | Bảo vệ luồng host | Không giả định UI/đính kèm/account; capability spike Phase 2 và fallback có xác thực |

## 3. Bộ 5 ảnh

| Slot khóa | Ảnh | Hướng dẫn chụp |
|---|---|---|
| `palm_left` | Lòng bàn tay trái | Toàn bàn tay đến cổ tay; lòng hướng camera; ngón mở tự nhiên; camera gần vuông góc |
| `palm_right` | Lòng bàn tay phải | Như trái; xác nhận bên bằng tay thực của người chụp |
| `face_front` | Gương mặt chính diện | Camera ngang mắt, không selfie góc rộng sát mặt; môi thư giãn; ánh sáng đều |
| `face_left_oblique` | Góc trái của người được chụp | Xoay đầu khoảng 45° để lộ phía trái; chỉ dùng kiểm tra vùng nhìn thấy và minh họa |
| `face_right_oblique` | Góc phải của người được chụp | Như trên với phía phải; không dùng để dựng kích thước 3D |

“Trái/phải” là phía của chủ thể, không phải phía người xem. Ảnh oblique không phải ảnh nghiêng 90°. Ảnh đối diện đã mirror cần xác nhận; không tự suy bên chỉ từ model. Không yêu cầu ảnh mới trong Phase 1. Tay thuận lấy từ tự khai; mặc định profile `right` theo thông tin người dùng đã cung cấp, luôn cho sửa. Không có quy tắc nam/trái–nữ/phải.

JPEG/PNG/WebP tĩnh; mỗi file ≤ 20 MiB (20,971,520 byte), ≤ 24 megapixel, 5 ảnh tổng ≤ 100 MiB. Từ chối SVG, GIF động, video và file giả MIME. HEIC/HEIF ngoài V1: hướng dẫn chuyển sang JPEG trước tải; không hứa trình duyệt tự chuyển được. Khuyến nghị cạnh ngắn ≥ 1,200 px; cạnh ngắn < 768 px yêu cầu chụp lại. Các giới hạn upload là khóa, các ngưỡng QC thị giác là giả thuyết cần hiệu chuẩn Phase 3.

## 4. Luồng sử dụng

1. Mở Plugin hoặc UI HTTPS riêng tư → đăng nhập → đọc phạm vi và thời hạn dữ liệu.
2. Xác nhận 18+, ảnh của mình, quyền sử dụng, đồng ý xử lý; tùy chọn xuất ảnh trong PDF mặc định tắt.
3. Tạo session → tải đủ 5 slot → bỏ EXIF, kiểm MIME/size/decode trên server → QC từng ảnh.
4. Sửa mirror/slot, thay ảnh cần chụp lại; cảnh báo mềm cho phép “Tiếp tục với giới hạn”, lỗi cứng không cho bỏ qua.
5. Phân tích → xem bản máy → sửa line/landmark hoặc xác nhận không quan sát được → xác nhận bản review.
6. Tổng hợp và xem báo cáo → xuất PDF → tải về → xóa session khi muốn.

Session: `created → uploading → quality_review → ready → analyzing → review → completed`. Trạng thái phụ: `failed`, `deleting`, `deleted`, `expired`. `ready` cần đủ 5 upload đã finalized và QC hợp lệ hoặc đã chấp nhận cảnh báo mềm. `completed` cần review đã xác nhận, cả khi một số chỉ số vẫn unknown. Sửa ảnh/annotation ở review/completed làm session quay lại quality_review hoặc review và vô hiệu hóa report cũ. Xóa/expiry thắng mọi job; không resurrect. Chi tiết trong API_SPEC.

## 5. Đầu ra và cách trình bày

- Nhãn xanh chữ “QUAN SÁT TỪ ẢNH”: nội dung hình học, không dùng màu làm tín hiệu duy nhất.
- Nhãn xám chữ “KHÔNG ĐỦ DỮ LIỆU”: lý do, vùng bị che, thao tác có thể cải thiện.
- Nhãn vàng chữ “TƯ LIỆU TRUYỀN THỐNG — CHƯA ĐƯỢC KHOA HỌC XÁC NHẬN”: nguồn và hệ tham chiếu, không kết luận cá nhân.
- Nhãn “NGƯỜI DÙNG HIỆU CHỈNH”: ghi tác giả thao tác là owner, không đổi thành ground truth.
- Không hiển thị % đúng vận mệnh. Điểm detector nếu có chỉ là raw model score, không phải xác suất đúng và không được tô như chứng nhận.

PDF A4 tiếng Việt, font có quyền nhúng, chữ chọn được, chú thích ảnh, legend, nguồn và phiên bản. Bản mặc định chỉ overlay sơ đồ trên nền trống và số đo; bật include_images mới đưa raster cá nhân vào PDF. Nội dung truyền thống ở phần riêng, không đặt như nhãn tính cách trực tiếp lên mặt.

## 6. Quyền riêng tư khóa

Cloud riêng tư là quyền truy cập, không có nghĩa dữ liệu không rời máy. Ảnh upload trực tiếp từ UI tới backend riêng, không đưa ảnh/embedding/URL truy cập vào model context. Phần chat chỉ nhận tóm tắt tối thiểu do owner chủ động yêu cầu. Không tự đồng bộ PDF/ảnh vào lịch sử chat hay nơi lưu khác. Bản người dùng tải hoặc tự đính kèm thuộc vòng đời của nơi đó, ứng dụng không hứa xóa được.

Không dùng ảnh hoặc annotation cá nhân để huấn luyện; không có checkbox train trong V1. Không analytics bên thứ ba, không face embedding, không tìm kiếm người. Dữ liệu session gồm ảnh, crop, overlay, annotation, phép đo, report, queue/cache hết hạn tuyệt đối tại `created_at + 24h` (không gia hạn bởi hoạt động). Bản raw upload chỉ tồn tại để chuẩn hóa, xóa trong 15 phút sau finalize; copy đã chuẩn hóa giữ trong hạn session. Kho session không backup, không versioning, không soft-delete; temp container là ephemeral. Audit metadata tối thiểu giữ 30 ngày, không chứa ảnh, tên file, đo hình học, IP đầy đủ, token hoặc nguồn URL có chữ ký. Receipt xóa theo cùng hạn audit.

Đồng ý có phiên bản, thời gian, mục đích và lựa chọn ảnh trong PDF. Rút đồng ý bắt đầu xóa session. Sau yêu cầu xóa: chặn đọc/ghi ngay khi nhận request, thu hồi mọi grant; purge byte đang hoạt động và job tạm trong ≤ 24 h. Theo dõi trạng thái cho đến hoàn tất; purge lỗi phải hiện thất bại/quá hạn, không báo đã xóa. Không quy định pháp lý đã được chứng nhận; kiểm tra nơi lưu, nhà cung cấp và văn bản đồng ý là gate Phase 6.

## 7. NFR và mục tiêu đo ở Phase 6

| Hạng mục | Mục tiêu thiết kế, chưa đo |
|---|---|
| Máy tham chiếu | 4 vCPU, 8 GiB RAM, CPU, Linux container; 1 worker CV/process |
| Thông lượng MVP | 1 job/session; tối đa 2 session đang chạy trên máy tham chiếu, queue giới hạn |
| Độ trễ | p95 phân tích 5 ảnh ≤ 60 s; p95 PDF ≤ 20 s; loại thời gian upload/queue |
| Timeout | Analysis 120 s, PDF 60 s; retry lỗi hạ tầng tối đa 1 lần với backoff, không retry bad image |
| Nhất quán | Job snapshot bất biến; optimistic concurrency; report phải chỉ đúng revision |
| UI | Desktop và mobile; zoom, bàn phím, chữ tiếng Việt; không chỉ thao tác kéo |
| An toàn | Không rò tenant, không truy cập anonymous, không xuất kết luận bị cấm |

Không hứa độ chính xác của model hoặc nếp gấp trong Phase 1. Tiêu chí CV, calibration, tập test độc lập và mode vẽ tay nằm ở TEST_PLAN/MODULE_DESIGN. Nếu auto-line không đạt, phát hành rõ mode assisted, không dùng từ “nhận diện tự động đạt”.

## 8. Giả định và quyết định còn mở

Các mặc định đã chốt cho thiết kế: 5 slot, chỉ 18+ ảnh chính chủ tự khai, cloud riêng tư + OAuth, không gọi LLM cho phân tích/report MVP, thời hạn 24 h, corpus có kiểm duyệt, chỉnh sửa thủ công bắt buộc review. Xem DECISION_LOG để phân biệt quyết định thiết kế với điều kiện triển khai.

Các việc Phase 2 cần xác minh: account/workspace hỗ trợ Plugin và MCP Apps; upload và metadata UI thực tế; IdP/hosting/region/cost; phiên bản Python/MediaPipe hỗ trợ môi trường; giấy phép model và corpus; chọn nguồn Đông Á/Vietnam nếu muốn. Nguồn chưa có không được bịa, rule liên quan disabled. Các việc này không làm contract mơ hồ; chúng là gate triển khai có fallback cụ thể. Nếu đổi số slot, policy, TTL hoặc schema phải mở khóa spec và tăng phiên bản.

SPEC LOCK chỉ khóa thiết kế. READY FOR CODEX nghĩa là có thể bắt đầu Phase 2, không có nghĩa Plugin đã hoạt động hoặc Production Ready.
