# Kế hoạch kiểm thử — PF-SPEC-1.0.0

## 1. Hai mức PASS khác nhau

Phase 1 PASS chỉ gồm tài liệu đủ, JSON parse/reference check, đối chiếu yêu cầu/API/module/privacy và feasibility review. Không test model, Plugin, upload, PDF hoặc ảnh cá nhân ở phase này. SPEC_LOCK_REPORT chỉ ghi các kiểm đã thực hiện. Bảng bên dưới là **kế hoạch cho Phase 2–6**, không được report thành test runtime đã PASS.

Phase 1 đã kiểm chính hợp đồng dữ liệu bằng validator Draft 2020-12 và các fixture JSON. Phase 2 phải tích hợp validator vào API thật, chạy format checker và service INV checks riêng. Synthetic fixtures dùng tọa độ/hình học dựng, không phải ảnh AI mô phỏng rồi dùng chứng minh accuracy người thật. Ground truth CV phải có đánh dấu hình học trên dữ liệu có quyền; không có ground truth vận mệnh.

## 2. Dataset và protocol ở Phase 3/6

Mục tiêu pilot tối thiểu 60 người trưởng thành tự nguyện hoặc dataset tương đương có quyền rõ, 5 ảnh/người (300 ảnh), nhiều ánh sáng, thiết bị, màu da/che khuất/tay thuận khác nhau. Không tự thu thập/đăng ký người trong Phase 1. Evaluation data có consent/retention riêng được duyệt trước, không lấy session người dùng làm training corpus. Không suy chủng tộc/tuổi/giới để chia nhóm. Chỉ metadata thiết bị/chất lượng chụp và điều kiện đã ghi có quyền; danh sách participant tách khỏi ảnh, không nhận dạng bằng model.

Split theo participant: 20 tuning,40 holdout; không để ảnh cùng người vào cả hai. Tune threshold trước freeze; holdout chạy một lần chính thức, thay model/threshold phải tạo phiên bản và evaluation mới. Hai annotator độc lập cho subset ít nhất 20% test; bất đồng được adjudicate, đánh dấu unclear vùng không đủ bằng chứng; không ép nhãn line mờ. Vẽ landmark/crease quan sát, không label tính cách. Báo sample counts/coverage, median/p95, bootstrap theo participant (1,000 resamples) và cảnh báo phạm vi pilot; không dùng p95 trên 10 ảnh rồi khái quát.

| Thành phần | Metric / mục tiêu gate đề xuất (chưa đo) |
|---|---|
| Hand landmarks | NME(pixel error / bbox diagonal) median≤0.04, p95≤0.08 trên ảnh chấp nhận; coverage trên eligible images≥90% |
| Face landmarks subset dùng đo | NME(pixel error / face width) median≤0.03, p95≤0.06; coverage front eligible≥90% |
| Crease automatic | Centerline F1 tolerance 0.01 palm-width≥0.80 trên confirmed major creases; không dùng background-dominant pixel accuracy |
| QC hard-invalid | Recall reject≥0.95 trên hard-invalid có nhãn; báo false-reject≤0.15 trên eligible và coverage |
| Ratio | Lỗi tuyệt đối so annotation reference median≤0.03,p95≤0.06 cho ratio metric trên front accepted; báo từng formula |
| Manual coordinate flow | Pixel reprojection error≤1px trên synthetic; revision/provenance 100% traceable |

Các ngưỡng là acceptance proposal khóa cho pilot; nếu dataset/landmark semantic map không hỗ trợ thì mở change request hoặc disable metric, không tự hạ ngưỡng để PASS. Assisted mode có thể thay auto-crease khi gate không đạt, nhưng metadata `auto_line_status=not_validated` ghi trong acceptance report (metadata release, không thêm field contract session). Sản phẩm chỉ được nhận chế độ thực đã kiểm.

## 3. Danh sách kiểm thử thực thi dự kiến

| Test ID | P | Tình huống | Kết quả mong đợi / bằng chứng |
|---|---|---|---|
| T01 |2| Schema valid/invalid, unknown keys, envelope/API body | Validator đúng; schema unknown key reject; fixture report |
| T02 |2| Field type, enums, NaN/Infinity, points ngoài[0,1] | Reject; không clamp im lặng |
| T03 |2| Missing consent, false 18+/self, fake model consent | Không upload/session; consent UI action verified |
| T04 |2| Unique slots thiếu/duplicate/6 ảnh | start analysis blocked, replace đúng slot |
| T05 |2| Token sai audience/issuer/expiry/scope | 401/403, discovery challenge chuẩn |
| T06 |2| Cross-owner session/job/image/report/receipt | 404, không rò hash/coords |
| T07 |2| Idempotency replay/key khác body | Cùng response/409, không duplicate job/session |
| T08 |2| Revision stale concurrent edit | 409, không last-write-wins |
| T09 |2| TTL/grant/raw cleanup boundary | expires_at+24 h,grant≤5 min,raw≤15 min |
| T10 |3| JPEG/PNG/WebP static, HEIC/SVG/animated/giả MIME | Chỉ định dạng đúng pass; malware/decode errors không canonical |
| T11 |3| 20 MiB/24 MP boundaries, decompression bomb | Capped stream/decode, CPU/RAM bounded,413 |
| T12 |3| EXIF 90° + mirror, non-square image | Overlay đúng canonical, không transform hai lần |
| T13 |3| Slot palm nhưng face, mu bàn tay, nhiều đối tượng | QC hard fail, không chọn người đầu tiên âm thầm |
| T14 |3| Blur/glare/shadow/occlusion variations | ROI QC và uncertainty reason; vùng lỗi null |
| T15 |3| Hand count/21 landmarks, mirror side mismatch | Side owner verified, count đúng, mismatch warning |
| T16 |3| Crease đậm/mờ, crossing, hairline, ink/shadow | Candidate có review; false lines reject; unclear abstain |
| T17 |3| Add/replace/delete/confirm/reject polyline | Đúng op; descriptors recompute và provenance giữ |
| T18 |3| Manual origin/raw scores | Manual null; không fake model confidence |
| T19 |3| Landmark adapter model mismatch | MODEL_MISMATCH, không pad/truncate |
| T20 |3| Face 478 points, semantic map QA | Overlay index đúng asset map trước enable ratios |
| T21 |3| Front pose, oblique45°, kính/môi che | Front-invalid null; oblique metrics luôn[] |
| T22 |3| Hairline không thấy, mesh index 10 | Không báo thirds/hairline/chiều cao mặt giải phẫu |
| T23 |3| Metric pixel geometry trên ảnh không vuông | Ratio chuẩn; denominator≤1px→null |
| T24 |3| Mirror/scale/roll synthetic transforms | Mapping và ratio invariant trong tolerance; pose lỗi không đo |
| T25 |3| Landmark CV evaluation | NME/coverage với holdout, không chỉ count detection |
| T26 |3| Crease CV evaluation | Centerline F1 và manual fallback, báo coverage |
| T27 |4| Draft rule/source thiếu review/hash/rights/locator | Không execute; SOURCE_NOT_APPROVED |
| T28 |4| Rule DSL expression/eval/script/field lạ | Reject; không thực thi code/HTML |
| T29 |4| Source đổi edition/snapshot hoặc locator sai | Freeze corpus version, fail publish |
| T30 |4| Tradition mâu thuẫn/thiếu nguồn Asian | Giữ riêng, missing rõ, không tự pha trộn |
| T31 |4| “Mũi/tay cho biết thông minh/đáng tin/sống lâu...” | POLICY_BLOCKED; không áp phẩm chất/số mệnh lên owner |
| T32 |4| Prompt injection trong ảnh/tên file/source/tags | Không OCR instructions, sanitized corpus/text; không ảnh hưởng tool/auth |
| T33 |4| Fusion thiếu dữ liệu, manual edit, source disagreement | Trung tính, unknown, không fortune confidence/majority vote |
| T34 |4| Evidence graph/citation đối chiếu | 100% output metric/card truy source/image/revision |
| T35 |4| PDF Vietnamese đủ dấu, bảng dài, overlay legend | Render từng trang, text selectable, không mất nhãn/source |
| T36 |4| include_images mặc định false và consent mismatch | Không raster ảnh owner; mismatch reject; schematic còn TTL |
| T37 |4|10 page/15 MiB/font render/error | Không silent truncate, error đúng và HTML còn dùng |
| T38 |5| tools/list, HTTP transport/OAuth/capabilities | So manifest/registry thật, host smoke test synthetic |
| T39 |5| Host không MCP Apps/file picker/bootstrap secret | Private login UI fallback; Plugin gate BLOCKED nếu không hỗ trợ |
| T40 |5| Tool projection/model context | Không bytes/mesh/grants/signed URLs, explicit summary only |
| T41 |5| UI 5 slot, canvas, zoom, keyboard, mobile | Review hoàn thành trên 320px+desktop, không chỉ drag |
| T42 |5| Refresh/reconnect/double click job | Không restart/duplicate; polling terminal dừng |
| T43 |5| Session replace/edit sau completed | Report cũ revoked; mới đúng image/annotation revision |
| T44 |6| Delete trong upload/analysis/PDF và download grant | Access revoke ngay; không commit/resurrect sau fence |
| T45 |6| TTL worker down/orphans/cache/temp/raw | Purge có inventory; lifecycle backup/versioning disabled |
| T46 |6| Purge lỗi, deadline, repeated delete | Receipt failed/pending thực; idempotent; không giả completed |
| T47 |6| Logs/monitoring/DB snapshots | Không image/payload/coords/token; audit 30 day; no payload backup |
| T48 |6| Load 2 sessions,queue 20,timeout, worker crash / lease | Backpressure/timeout/retry 1; integrity giữ |
| T49 |6| CPU reference≥100 jobs p95 analysis/PDF | Đo 60 s/20 s target; ghi dataset/queue exclusion/RAM |
| T50 |6| Full 5-image journey, delete verified, export PDF | Synthetic + approved real evaluation smoke; source/correctability/privacy |
| T51 |6| Dependency/model license + environment install | Lockfile/SBOM/checksum/license và reproducible install |
| T52 |6| No banned output regression + deployment access | 0 prohibited individual conclusions; owner private ACL smoke |

T33 cụm “thiếu dữ liệu” là null/unknown, không tự điền kết quả. Không coi scan từ khóa là đủ T31/T52: ngoài allowlist schema, reviewer kiểm ngữ nghĩa và thử paraphrase/indirect request, source cổ có định kiến. Chỉ template đã duyệt xuất ra; không LLM free text.

## 4. Gate phase và evidence

| Phase | Gate tối thiểu | Artifact bằng chứng |
|---|---|---|
|2| Contract validator, stub API/auth/revision/tombstone, capability spike | PHASE2_REPORT.md + fixtures + dependency/host matrix |
|3| Engine geometry/QC và manual tracing; auto mode ghi đúng validation | PHASE3_CV_REPORT.md + dataset rights/protocol + metrics |
|4| Corpus review/policy/fusion/report QA | CORPUS_RELEASE.json + SOURCE_REVIEW.md + PDF QA images/text + tests |
|5| Private MCP/UI fallback integration synthetic | HOST_INTEGRATION_REPORT.md + privacy projection check |
|6| E2E/privacy/performance/license, runtime host thật | ACCEPTANCE_REPORT.md + EVIDENCE_INDEX.md + hashes/SBOM |

P0 blockers: auth/tenant/privacy/delete/consent/banned output/evidence fabrication. P1 blockers: bad math, stale report, QC bypass, unreadable PDF, host không dùng được mà vẫn claim Plugin ready. Production Ready YES chỉ khi P0/P1=0 và gates đạt trong mode công bố. Tests pending không được viết PASS. Nếu deployment thật/account access chưa có, Phase 6 phần đó BLOCKED và Production Ready NO; vẫn bàn giao phần local được kiểm.
