# Thiết kế module — PF-SPEC-1.0.0

## 1. Quy ước dùng chung

Ảnh canonical là tham chiếu duy nhất. Point `x,y` là [0,1] theo width/height; pixel conversion `px=x*(width-1)`, `py=y*(height-1)`. **Mọi khoảng cách phải quy đổi về pixel trước**: ảnh không vuông, khoảng cách trong không gian x/y normalized trực tiếp sẽ sai. Metric cuối là ratio vô thứ nguyên hoặc normalized arc length, không mm/cm. Không dùng world landmark để hứa đo kích thước thực từ một ảnh. `z` của model nếu giữ chỉ là relative depth nội bộ, không metric đo lường trong báo cáo.

Không coi confidence detection là confidence của crease/ratio. Điểm số thô có `calibration=uncalibrated`; manual không có score. `observed/not_observable/not_applicable` tách nhau; `value=null` khi không observed. “Không thấy” không tương đương “không tồn tại”. User-confirmed là xác nhận annotation, không xác nhận khoa học hoặc xác nhận rule dự đoán.

## 2. Quality Engine

Input: canonical image + slot + mirror confirmation. Output: `QualityResult` có status, check codes, object count, resolution và config version. Tải file kiểm MIME từ magic bytes, kích thước stream, decode timeout, pixel cap, EXIF strip; không gọi OCR. Object detector cho phép thấy >1 object để từ chối; không configure max1 rồi giả định không có người thứ hai.

QC theo ROI: blur Laplacian normalized trên scale cố định, luminance/clipping/glare, occlusion, object size, pose, ROI completeness; detector thất bại được phân biệt object absent. Các ngưỡng blur/glare/pose là config hiệu chuẩn, không “chuẩn y khoa”. Cạnh ngắn <768, >24 MP, >20 MiB, wrong slot, multiple subjects và corrupted là lỗi cứng. Moderate blur/lighting là cảnh báo mềm với acknowledgement explicit; metric vùng lỗi vẫn abstain.

Face front: target yaw/pitch trong ±10°, roll trong ±5°; chỉ là ngưỡng khởi đầu cần kiểm với model pose. Nếu không ước lượng pose ổn định thì không cung cấp ratios automatic, yêu cầu sửa/rephoto. Oblique mục tiêu 35–55° đúng phía do owner khai; không dùng giá trị face matrix như phép đo yaw được chứng nhận. Palm homography chỉ ước lượng phẳng gần camera, không loại bỏ hoàn toàn phối cảnh bàn tay 3D.

## 3. Palm Engine

[MediaPipe Hand Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/python) cho 21 điểm mốc và handedness; không cung cấp đường chỉ tay. V1 adapter chỉ xuất 21 điểm hợp lệ khi một hand được nhận diện; handedness model là gợi ý, owner declaration + mirror confirmation là nguồn bên tay cuối cùng.

Pipeline tách biệt:

1. Hand detector → 21 landmarks → ROI lòng bàn tay từ wrist/MCP và mask ước lượng. Kiểm đủ wrist/ngón, không gán mặt mu bàn tay là lòng bàn tay nếu không xác định được.
2. ROI canonical RGB/grayscale → local contrast có giới hạn → multi-scale dark-ridge/line filters → nonmaximum suppression → skeleton/prune ngắn → graph endpoints/junctions.
3. Tạo **candidate nếp gấp nhìn thấy**. Chỉ đề xuất nhãn đường truyền thống theo vị trí/topology như giả thuyết, không phân loại định mệnh. Noise/vết mực/bóng có thể sai; review luôn hiện ảnh gốc cạnh overlay.
4. Nếu line score chưa calibration, `raw_model_score=null` đối với pipeline cổ điển; status `candidate`, owner vẽ/sửa/confirm. Không bịa xác suất cho bộ lọc.
5. Owner có thể tạo/replace/delete polyline và assign conventional label. Label allowed `unlabeled`, `life`, `head`, `heart`, `fate`, `other`; label chỉ tên trong tradition selected, không claim sinh học. Không tự thêm đường nhỏ không rõ.

Mỗi line có ID, image/annotation revision, polyline, candidate/confirmed/rejected, origin automatic/manual, label, descriptors và uncertainty. Desc: arc length/palm width, chord/arc straightness [0,1], branching visible count; không đo độ sâu thật từ bóng ảnh. Continuity chỉ là độ liên tục của nét trong ảnh; phần mờ phải `not_observable`, không “đứt gãy cuộc đời”. Palm-width reference: pixel distance MCP index(5)↔pinky(17), đo theo snapshot; đây là reference hình học xấp xỉ, không width giải phẫu.

Không gán topology tự động khi người dùng sửa line: invalidation rồi tính lại descriptors. Image replacement làm annotation cũ read-only và không áp lên ảnh mới. Không tái chiếu line giữa hai tay bằng reflection rồi suy giống nhau.

`PalmResult.observation_status` mô tả kết quả landmark của Hand Engine. Nếu landmarks không đọc được nhưng owner vẽ được một nếp gấp nhìn thấy, giữ line manual cùng limitations; không biến trạng thái landmark thành tuyên bố toàn bàn tay không có đường. Ratio cần reference MCP phải null khi không có reference. Branch count dựa trên các polyline/graph giao nhau đã review; đoạn chồng mờ hoặc không xác nhận được không được đếm như nhánh giải phẫu chắc chắn.

MVP không huấn luyện model deep crease từ đầu. Đường chỉ nhỏ, vân tay/dermatoglyphics, phát hiện bệnh, 3D palm mounts và “đường hôn nhân” ở cạnh tay ngoài scope. Nếu thuật toán cổ điển không đạt gate, assisted manual tracing vẫn đáp ứng quan sát và truy vết; báo cáo rõ chưa xác nhận auto-line.

## 4. Face Engine

[MediaPipe Face Landmarker](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/python) có adapter 478 landmark cho model được chọn; không yêu cầu blendshapes. V1 tắt blendshapes và identity embedding. Với model khác số điểm, từ chối adapter mismatch; không padding hoặc truncate im lặng.

Front là nguồn đo duy nhất. Oblique dùng hiển thị, QC và ghi vùng thấy/che; không average tỷ lệ với front, không reconstruction 3D, không xác nhận ba ảnh cùng người bằng nhận dạng. Owner tự xác nhận 5 ảnh cùng mình; camera/distance/pose khác nhau được ghi như giới hạn.

Semantic map V1 (phải test lại với asset đã pin Phase 2):

| Vai trò | MediaPipe index | Dùng |
|---|---|---|
| Trán giữa mesh | 10 | Mesh boundary, không chân tóc |
| Cằm giữa | 152 | Face height reference |
| Hai biên mặt mesh | 234, 454 | Face width reference, không tuyên bố điểm gò má giải phẫu |
| Hai khóe mắt trong | 133, 362 | Intercanthal distance |
| Hai khóe miệng | 61, 291 | Mouth width |
| Hai biên cánh mũi mesh | 98, 327 | Approximate nose width |
| Đáy mũi mesh | 2 | Division reference, cần QA |

Chỉ số index là mapping đề xuất, không nguồn landmark mới đã kiểm nghiệm. Phase 2 phải kiểm overlay synthetic/model-doc và fixture có quyền; nếu semantics chưa chắc thì disable metric. Không dùng index 10 như hairline. Three facial thirds không nằm V1 vì cần hairline và anthropometry không có; có thể thêm sau qua spec change với manual points và tên đo chính xác.

Metric IDs khóa:

| ID | Công thức pixel trên front | Khi từ chối |
|---|---|---|
| `face_height_width_ratio` | d(10,152)/d(234,454) | pose không hợp lệ, boundary occluded, denominator gần0 |
| `intercanthal_face_width_ratio` | d(133,362)/d(234,454) | khóe mắt không thấy/kính che |
| `mouth_face_width_ratio` | d(61,291)/d(234,454) | cười/môi che hoặc pose lỗi |
| `nose_face_width_ratio` | d(98,327)/d(234,454) | mũi occluded, mapping chưa QA |
| `left_right_contour_asymmetry_2d` | abs(d(234,mid)-d(454,mid))/d(234,454); mid midpoint(10,152) | pose/roll/boundary lỗi |

Chỉ số bất đối xứng là ảnh chiếu 2D, có thể do pose/ánh sáng; không chẩn đoán hoặc điểm đẹp. `denominator ≤ 1px` → null. Float finite, làm tròn hiển thị 3 chữ số thập phân; tính nội bộ không làm tròn. Metric không có actual error bar trước evaluation; giữ `uncertainty_reason`, không ghi ± sai số giả.

## 5. Traditional Knowledge Engine (TKE)

Hai dataset tách nhau: Sources và ApprovedRules. Source có author/title/edition/language/tradition/URL/locator/review/rights/snapshot_sha256. Nguồn sưu tầm không đồng nghĩa chứng minh khoa học. Rule bắt buộc source locator kiểm được, paraphrase tiếng Việt được duyệt, review người chịu trách nhiệm, allowed category và applicability. Không dùng search snippet hoặc LLM memory làm corpus.

Nguồn ban đầu: `SRC-PALM-CHEIRO-20480` với các tên chương và tên line đã đối chiếu; chỉ dùng glossary/cultural context. `SRC-FACE-LAVATER-24019748` là ứng viên catalog, chưa đọc/duyệt nội dung chi tiết, không có active face rule. Không gọi Lavater là nhân tướng học Việt/Đông Á. Nguồn Đông Á/Vietnam chưa được chọn: Phase 2 phải register hoặc thông báo chương truyền thống face chưa có tư liệu duyệt; không ghép hệ khác nhau dưới một nhãn “chuẩn”. Xem SOURCE_REGISTER.

Rule DSL hữu hạn, không `eval`, Python/JS expression hay arbitrary query:

- `trigger.type=confirmed_line_label` + label → thẻ glossary có nguồn.
- `trigger.type=user_selected_topic` + topic → thẻ bối cảnh lịch sử độc lập ảnh.
- `output_category ∈ glossary, cultural_context`; không có trait/health/fate field.
- Predicate không đọc face metric để suy tính cách; không cross-feature horoscope scoring.
- Rule `approved` cần review và locator; không đủ → disabled. Rule order stable theo priority/id. Nhiều tradition mâu thuẫn → để cạnh nhau như khác biệt tư liệu, không majority vote.

Ba rule mẫu thiết kế: `TK-PALM-LIFE-GLOSSARY`, `TK-PALM-HEAD-GLOSSARY`, `TK-PALM-HEART-GLOSSARY` lần lượt hiển thị tên gọi và nguồn chương tương ứng. Tình trạng mẫu `draft`; không được coi là corpus production. Ví dụ câu cho life: “Sinh đạo là tên gọi quy ước trong chỉ tay; đường nhìn thấy trong ảnh không cho biết tuổi thọ.” Face chỉ có card user-selected lịch sử khi được curate, không tự “mũi này nói rằng...”.

## 6. Fusion Engine

Input: observation snapshot đã review + approved cards + policy version. Output `FusionResult`: observation IDs, card IDs, limitations, review coverage. Deterministic dependency graph, không score vận mệnh, không suy “hai nguồn xác nhận”. Quy tắc hợp nhất:

1. Giữ trái/phải riêng và front/oblique riêng; tay thuận chỉ là metadata owner tự khai.
2. Dedup cùng observation+revision, không dedup hai ảnh thành đo lặp độc lập.
3. Tóm tắt what observed, what corrected, what unknown; card traditional ở phần riêng.
4. Conflict giữ cả hai và ghi lý do; không chọn kết quả hợp với kỳ vọng.
5. Bằng chứng không đủ → unknown, không gọi tradition để bù đo thiếu.

Ví dụ tổng hợp được phép: “Hai ảnh lòng bàn tay đã có đường do người dùng xác nhận. Tỷ lệ mặt lấy từ ảnh chính diện; ảnh góc trái bị che một phần. Phần tư liệu giải thích tên gọi, không dự đoán tương lai.” Không có endpoint prediction.

## 7. Review UI

5 ô tải ảnh cố định với tên slot, preview và QC; consent nằm trước file picker. UI có chọn mirror, side, replace/delete slot. Không upload ngay lúc chọn file trước consent. Màn review: ảnh gốc/overlay toggle; pan/zoom; line list; drag landmark; add/replace/delete line; dropdown label; undo/redo local; “Lưu chỉnh sửa” submit transaction rồi “Xác nhận review”. Bàn phím và nhập tọa độ thay drag; nút/reset không xóa dữ liệu gốc.

Optimistic revision theo API. Nếu 409: refetch và hỏi merge/giữ local trong UI, không overwrite tự động. Server không nhận HTML/SVG từ client, chỉ point arrays hữu hạn; render overlay an toàn. Mỗi ảnh ghi mirror status, quality warnings, algorithm/manual origin. Progress nói stage thực, timeout có retry hướng dẫn; refresh khôi phục từ server, không restart job.

## 8. Report Engine

Template deterministic: (1) phạm vi/thời gian/consent; (2) chất lượng và mapping 5 ảnh; (3) quan sát hai tay; (4) face ratios front + giới hạn oblique; (5) sửa của owner và missing; (6) tư liệu truyền thống/source; (7) giới hạn/phiên bản/retention. Không dùng LLM để bịa đoạn luận.

Ảnh minh họa là raster của owner khi explicit include_images=true; mặc định sơ đồ landmark/line trên nền trắng. V1 không tạo ảnh bằng generative AI vì cần đúng điểm/đường. SVG server-generated thuộc dữ liệu cá nhân vẫn cùng TTL; không embedded script/external reference. PDF có selectable Vietnamese text, font embedding, page numbers, line labels, alt descriptions ở HTML; A4 portrait, ratio tables không tràn, paragraph truyền thống không cắt mất nhãn. Preview render từng trang và test dấu tiếng Việt. PDF job giới hạn 10 trang và kích thước 15 MiB; vượt giới hạn thì báo error hoặc giảm kích thước raster có thông báo, không silent truncate nội dung.
