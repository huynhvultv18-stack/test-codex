# Nguồn và trạng thái kiểm chứng — 12/10/2026

Nguồn kỹ thuật là tài liệu gốc. Nguồn truyền thống chứng minh tác giả/quan niệm có tồn tại, không chứng minh lời luận đúng. Không dùng snippet làm tư liệu production. Không sao chép dài; bản dịch/paraphrase có review và rights riêng.

| Source ID | Nguồn và URL | Nội dung đã kiểm | Trạng thái |
|---|---|---|---|
| TECH-OPENAI-AUTH | [OpenAI Plugin authentication](https://developers.openai.com/plugins/build/auth) | OAuth resource server, discovery và kiểm token | Trang đã mở; account riêng chưa thử |
| TECH-OPENAI-CONNECT | [Custom MCP server](https://developers.openai.com/api/docs/guides/custom-mcp-server) | Kết nối MCP và quyền workspace; streaming HTTP | Trang đã mở; kết nối của owner chưa thử |
| TECH-MCP-UI | [MCP Apps overview](https://apps.extensions.modelcontextprotocol.io/api/documents/overview.html) | UI resource/iframe, capability và fallback | Trang đã mở; phải map SDK thật |
| TECH-MCP-AUTH | [MCP Python SDK authorization](https://py.sdk.modelcontextprotocol.io/run/authorization/) | Resource-server boundary, auth discovery | Trang đã mở |
| TECH-HAND | [Hand Landmarker Python](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/python) | 21 điểm; hệ tọa độ và handedness | Trang đã mở; model asset chưa pin |
| TECH-FACE | [Face Landmarker Python](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/python) | 478 điểm ở output mẫu, optional blendshapes | Trang đã mở; semantic index map vẫn gate P2 |
| SRC-PALM-CHEIRO-20480 | Cheiro, *Palmistry for All*, bản số [Gutenberg metadata](https://www.gutenberg.org/ebooks/20480), [full text](https://www.gutenberg.org/files/20480/20480-h/20480-h.htm) | Mục/chương line Head/Life/Heart và tên gọi | Full text đã mở; chỉ dùng glossary; eBook release 2007 không phải năm in gốc |
| SRC-FACE-LAVATER-24019748 | J. C. Lavater, *Physiognomy*, London W. Tegg [1869], [LOC catalog](https://www.loc.gov/item/24019748/) | Catalog search xác nhận tên/mốc 1869, 302 image sequence | CANDIDATE: mở trang trực tiếp lỗi; chưa đọc sách, không active rule |
| SRC-ASIAN-PENDING | Nguồn nhân tướng Đông Á/Việt Nam | Chưa có edition/locator/rights | NOT_SELECTED: không sử dụng |

## Locator mẫu có thể đối chiếu

| Rule mẫu | Locator trong Cheiro | Nội dung được phép |
|---|---|---|
| TK-PALM-HEAD-GLOSSARY | Part I, Chapter II, trang in8; đối chiếu TOC/chapter heading | Tên gọi đường trí đạo, alias tiếng Việt cần reviewer xác nhận |
| TK-PALM-LIFE-GLOSSARY | Part I, Chapter III, trang in36 | Tên gọi đường sinh đạo; luôn ghi không đo tuổi thọ |
| TK-PALM-HEART-GLOSSARY | Part I, Chapter VII, trang in67; Plate XVI trang68 mô tả đường dưới ngón | Tên gọi đường tâm đạo; không suy tình cảm người trong ảnh |

Trang đầu full text ghi bản G.P. Putnam's Sons, copyright/publication1916, Twenty-second Impression. Trước active: xác minh chính xác locator/edition, snapshot nội dung được phép và SHA-256; kiểm title/translation bằng người duyệt; bổ sung `reviewer_id`, `reviewed_at`, `rights_status`, `snapshot_sha256`. Phase 1 không tạo hash giả cho website/ảnh chưa tải. Không mark approved chỉ vì có URL. Các rule fixture trong examples là DRAFT dùng kiểm contract, không corpus chạy.

Chọn được nhiều hệ thì mỗi thẻ ghi `tradition_id` riêng. Truyền thống phương Tây không tự đại diện nhân tướng Đông Á. Nếu owner yêu cầu các đoạn cổ điển luận phẩm chất, chỉ trình bày như nội dung lịch sử chung đã kiểm duyệt và không áp nó lên người trong ảnh; phần gán phẩm chất/cảnh báo bệnh/dự báo số mệnh bị loại khỏi rule executable.
