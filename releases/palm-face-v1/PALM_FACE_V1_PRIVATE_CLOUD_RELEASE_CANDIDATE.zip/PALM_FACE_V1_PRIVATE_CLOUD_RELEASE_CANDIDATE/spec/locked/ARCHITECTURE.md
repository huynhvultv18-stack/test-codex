# Kiến trúc — PF-SPEC-1.0.0

## 1. Quyết định triển khai

Chọn Plugin cloud riêng tư, MCP Streamable HTTP có OAuth 2.1, UI MCP App khi host hỗ trợ; Python CV/report worker chạy trong container riêng. Một UI HTTPS cùng backend, xác thực riêng, là fallback khi host không hỗ trợ file picker/canvas. Không dùng backend Sites để giả định có sẵn Python CV worker dài hạn. Sites có thể làm vỏ UI/MCP nếu spike Phase 2 chứng minh được; Python worker và kho ảnh vẫn là dịch vụ riêng. Chưa provision bất kỳ dịch vụ nào trong Phase 1.

Thiết kế bám [OpenAI Plugin authentication](https://developers.openai.com/plugins/build/auth), [custom MCP server](https://developers.openai.com/api/docs/guides/custom-mcp-server), [MCP Apps](https://apps.extensions.modelcontextprotocol.io/api/documents/overview.html) và [MCP Python authorization](https://py.sdk.modelcontextprotocol.io/run/authorization/). Tài liệu kiểm tra ngày 12/10/2026; quyền của account và SDK thực tế chưa kiểm tra. Metadata/UI phải map theo phiên bản cài thật, không sao chép một manifest suy đoán.

```mermaid
flowchart TB
  H["ChatGPT host"] --> M["MCP gateway: OAuth"]
  H --> U["UI tải ảnh và hiệu chỉnh"]
  U --> A["API riêng: quyền chủ sở hữu"]
  M --> A
  A --> Q["Job queue: snapshot/revision"]
  Q --> W["Python CV và report worker"]
  A --> S["Kho tạm có TTL"]
  W --> S
  W --> K["Corpus và rule đã duyệt"]
  A --> D["Deletion coordinator"]
  D --> Q
  D --> S
```

## 2. Thành phần và ranh giới tin cậy

| Thành phần | Trách nhiệm | Dữ liệu cho phép |
|---|---|---|
| ChatGPT/model context | Mở workspace, đọc tóm tắt owner chủ động yêu cầu | ID mờ, trạng thái, tóm tắt trung tính; không tọa độ dày/ảnh/URL có chữ ký |
| UI | 5 slot, canvas, consent, review, PDF/download/delete | Preview của owner qua asset gateway; không lưu localStorage ảnh |
| MCP gateway | Tool schema, adapter host, OAuth/token/scope | Payload hữu hạn; tool annotations không thay thế kiểm tra quyền |
| API | Ownership, schema, business invariant, idempotency | Session DB và grants; không nhận arbitrary external URL |
| Upload quarantine | Kiểm size/MIME/decode/virus, EXIF normalization | Raw file riêng tư, TTL 15 phút sau finalize |
| CV worker | Hand/face landmark, crease, metrics, abstain | Canonical image, snapshot; không Internet egress |
| Knowledge/Fusion | Rule đã duyệt, truy vết, tổng hợp | Observation và nguồn; không raw face image |
| Report worker | Template Việt, overlay, PDF | Snapshot đã review và policy-filtered; không tải URL tùy ý |
| Session storage | Ảnh/annotation/report transient | Chặn public ACL, mã hóa và policy TTL |
| Audit | Hành động, outcome, request ID | Metadata tối thiểu; retention 30 ngày |

## 3. Auth và asset access

- Dùng IdP chuẩn thay vì tự viết OAuth. Access token kiểm chữ ký/issuer/audience/expiry/scope; resource metadata và PKCE theo MCP. Tenant/owner lấy từ principal đã verify, không lấy user_id do client truyền.
- Backend gán một principal nội bộ cho cả OAuth MCP và login UI. Account-link phải xác minh phía server; không tin owner/tenant do widget hoặc model gửi.
- Mọi get/update/delete đối tượng kiểm owner, bao gồm job, upload, crop, annotation, PDF và deletion receipt. Đối tượng khác owner trả 404 để tránh dò tồn tại.
- `/mcp` là cổng có thể Internet-reachable nhưng bắt buộc auth. “Plugin riêng tư” là distribution + ACL; không thay thế OAuth. TLS và private object storage bắt buộc. Nếu dùng tunnel chính thức, vẫn cần OAuth và gate reachability, không giả định localhost được ChatGPT cloud truy cập.
- Ảnh không nằm trong JSON tool result. UI dùng asset gateway auth. Browser không nhận MCP bearer token; dùng grant opaque ngắn hạn gắn subject/session/asset/scope, tra server mỗi request. Asset grant và upload ticket ≤ 5 phút, ràng buộc origin, không logs; xóa/expiry thu hồi ngay. API không dùng presigned public download độc lập mà không thể thu hồi.
- Bootstrap UI được làm bằng cơ chế host đã xác minh (UI-only metadata/tool hoặc login độc lập). Không coi `structuredContent` tự động bí mật. Nếu host không bảo đảm tách dữ liệu khỏi model, chỉ trả route UI không chứa secret và yêu cầu login UI bình thường.
- CSP chỉ khai báo domain API/UI/asset cần thiết; không CDN tracking. CORS allowlist, CSRF khi cookie auth, cookie Secure/HttpOnly/SameSite phù hợp flow; Origin validation Streamable HTTP.

## 4. Dataflow và consistency

Upload thành công không đồng nghĩa ảnh đã được chấp nhận. Ticket → raw quarantined → decode/normalize → canonical image → QC → finalized slot. SHA-256 computed server cho snapshot/provenance, không dùng để fingerprint người và không hash vào global logs. Không persist tên file người dùng.

Canonical ảnh: EXIF orientation được áp một lần, convert RGB/sRGB có ghi phương thức; mirror là transform tách do owner xác nhận. Giữ bản normalized chưa mirror + bản canonical; cả hai thuộc TTL. Matrix nguồn→canonical và phiên bản preprocessing lưu cho overlay. Worker đọc canonical của đúng image revision; điểm 2D chuẩn hóa trên ảnh canonical. Crop dùng coordinate transform riêng, không nhập nhầm crop point vào full image.

`session_revision` tăng khi thay ảnh/annotation/profile. Analysis snapshot ghi `image_revisions`, `annotation_revision`, model/algorithm/policy/corpus versions. Job đang chạy không sửa snapshot; mutation bị chặn lúc analyzing, hoặc hủy job trước sửa. Cuối job kiểm lại revision/deletion fence trong cùng transaction; không publish kết quả cũ. Report có ID riêng và snapshot hash; edit sau completed hủy khả năng tải report cũ, tạo bản mới khi review xong.

Jobs trong DB là nguồn sự thật, queue chỉ ID. MVP dùng PostgreSQL job table + worker polling với lease/heartbeat, chưa cần Redis. Lease expiry có retry một lần, trạng thái stuck có timeout. Server lưu Idempotency-Key theo principal+route trong hạn session, không payload ảnh; key trùng payload khác trả 409. PDF riêng job, không chạy trong request đồng bộ.

API JSON body tối đa 2 MiB; binary upload theo cap 20 MiB riêng. Worker xử lý từng full frame tuần tự thay vì giữ 5 ảnh decoded cùng lúc; ảnh working cho landmark/crease có scale/config version và transform về canonical. Budget ban đầu ≤2 GiB RAM/worker, đặt giới hạn container và báo error khi vượt, không silent skip. Đây là giới hạn triển khai cần kiểm ở Phase 6, không kết quả benchmark.

## 5. Backend gợi ý, chưa cài

Python 3.11/3.12 chọn sau compatibility spike; FastAPI/Pydantic cho REST; SDK MCP chính thức cho gateway. MediaPipe Tasks image mode; OpenCV/scikit-image cho nếp gấp; Pillow/libvips cho decode được sandbox. PostgreSQL cho session/job/revision; object store private hoặc filesystem private ở MVP, không backup nội dung session. ReportLab cho PDF và SVG overlay generated server. Không khóa version số chưa kiểm; Phase 2 tạo lockfile, SBOM, model checksum, license register. CPU trước, GPU/tuning/training ngoài phạm vi V1.

Không gọi OpenAI API/LLM cho CV, nguồn hoặc PDF trong MVP; không cần suy đoán API key/model giá. ChatGPT chỉ điều phối tools. Nếu thêm LLM về sau phải spec change, privacy assessment, schema allowlist và dùng dữ liệu tối thiểu.

## 6. Xóa và sự cố

Deletion transaction ghi tombstone và fence trước, revoke grants, cancel queued jobs, signal running workers, enqueue purge manifest. Worker kiểm fence trước đọc và trước commit, kiểm lại giữa các stage. Purge xóa raw/canonical/crop/overlay/annotation/report/queue payload/cache/temp; không xóa audit tối thiểu. Mất mạng không được coi đã xóa xong: receipt `pending/running/failed/completed`, deadline theo receipt. Dịch vụ scan orphan và TTL mỗi 5 phút; kiểm tra lifecycle kho không chỉ dựa scan ứng dụng. Purge hoàn tất chỉ khi storage inventory kiểm không còn payload liên quan. RAM hết hạn cùng process/task; không hứa erase forensic trên máy ngoài kiểm soát.

Raw upload bị reject xóa ngay sau lỗi; raw chưa finalize xóa không quá 15 phút sau ticket expiry. Không để một upload bỏ dở giữ raw vô hạn. Grant không bị gia hạn bởi polling, job không được gia hạn session TTL.

Khi worker lỗi, session failed với error code; không tạo nội dung thay thế bằng kiến thức truyền thống. Khi nguồn không khả dụng, corpus đã duyệt có snapshot offline; nguồn mới chưa snapshot không được hoạt động. Khi font/PDF render lỗi, trả error và giữ báo cáo HTML, không trả file hỏng như thành công.

## 7. Cấu trúc repo dự kiến cho Phase 2

| Đường dẫn | Nội dung dự kiến |
|---|---|
| `spec/` | Bản sao khóa, hashes, quyết định/change request |
| `contracts/` | Schema và mẫu synthetic; validator service invariants |
| `apps/mcp_gateway/` | Auth, MCP tool adapters, resource registry |
| `apps/api/` | Sessions, uploads, jobs, annotations, reports, delete |
| `apps/reviewer_ui/` | MCP App + private standalone UI, capture wizard/canvas |
| `engines/palm/` | Hand adapter, ROI, crease candidates, manual fallback |
| `engines/face/` | Face adapter, landmark semantic map, geometry |
| `engines/quality/` | Decode, masks, resolution/blur/glare/pose checks |
| `engines/knowledge/` | DSL evaluator, source validation, approved corpus |
| `engines/fusion/` | Dependency graph, deterministic neutral summary |
| `engines/report/` | Vietnamese templates, fonts, overlay/PDF |
| `workers/` | Job leases, analysis/report/purge task orchestration |
| `infra/` | Containers, private storage, IdP config reference, migrations |
| `tests/` | Unit/contract/integration/e2e/privacy/content/source/PDF |
| `fixtures/synthetic/` | Generated geometric fixtures, no personal images |
| `evaluation/` | Protocol, consent/license metadata, metrics, no committed photos |
| `docs/` | Capture guide, operations, retention, deletion, user guide |

Đây là danh sách thiết kế, không phải thư mục mã ứng dụng đã tạo. Source repo không chứa ảnh thật, credentials hoặc corpus không rõ giấy phép.
