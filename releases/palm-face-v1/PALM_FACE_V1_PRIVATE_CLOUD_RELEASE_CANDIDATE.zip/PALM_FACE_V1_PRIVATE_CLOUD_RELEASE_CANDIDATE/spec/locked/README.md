# PALM_FACE_V1_PHASE1_SPEC_LOCK

Gói bàn giao Phase 1: đặc tả phần mềm 1.0.0, chưa có ứng dụng hoặc Plugin đã triển khai. Đọc SPEC_LOCK_REPORT để biết bằng chứng kiểm tra và giới hạn PASS.

## Bảy đầu ra bắt buộc

1. SPEC_V1.md — phạm vi,5 ảnh,policy,consent,retention và yêu cầuR01–R18.
2. ARCHITECTURE.md — private cloud/MCP/Pythonworker,auth/dataflow/storage/delete,repo layout.
3. MODULE_DESIGN.md — Quality/Palm/Face/Knowledge/Fusion/UI/Report và formulas.
4. DATA_CONTRACT.json — Draft2020-12 schema,$defs và document envelopes.
5. API_SPEC.md — REST/MCP mapping,error,state/revision,INV01–INV22.
6. TEST_PLAN.md — 52 test tương lai,CV protocol và gates; chưa runtime PASS.
7. CODEX_MASTER_COMMAND.md — lệnh hiện thựcPhase 2–6 để dùng trong phiên sau.

## Tài liệu bổ sung

- DECISION_LOG.md: LOCKED và OPEN/gates cụ thể.
- SOURCE_REGISTER.md: nguồn đã mở,candidate chưa duyệt; không hash source giả.
- TRACEABILITY.md: yêu cầu/module/test mapping.
- SPEC_LOCK_REPORT.md: checklist đã chạy và thiết kế đã review.
- VALIDATION_EVIDENCE.json: kết quả 45 kiểm tra tài liệu/schema, không phải test ứng dụng.
- SHA256SUMS.txt: hash từngfile trong gói,ngoại trừ chính checksum file.
- examples/: 5 payload JSON synthetic,không bytes ảnh. Wrapper `{definition,synthetic_only,payload}` là fixture manifest; validate `payload` theo `$defs/definition`, không dùng wrapper làm REST body.

## Cách bàn giao CODEX

Giải nén một lần,đối chiếu SHA256SUMS,đọc cácfile theo thứ tự trên, rồi giao toàn bộ CODEX_MASTER_COMMAND. Giữ bản khóa read-only,tạo working repo khác; không tự bắt đầu Phase 2 trong phiên Phase 1.

Spec không hứa đo 3D/tuổi thọ/tính cách/độ đúng vận mệnh. Phần truyền thống là glossary/context dẫnnguồn tách khỏi quan sát cá nhân. Facecorpus chưa duyệt và host support/account thực tế vẫn là gate tương lai; không được coi đã kiểm chứng.
