# Kiến trúc cloud riêng tư — thiết kế, chưa triển khai

P0 CLOUD DEPLOYMENT = BLOCKED. Owner trả lời CHƯA CÓ provider/region/budget/IdP/quyền host trong phiên hiện tại. Không có binding cloud/IdP trong cấu hình môi trường; tên biến nền tảng hiện diện không được coi là quyền triển khai dịch vụ.

| Phương án | Khả năng | Điều kiện phải kiểm trên provider thật |
|---|---|---|
| Container VM riêng với filesystem/tmpfs riêng | Gần topology local nhất; tách API/gateway và worker CPU | TLS/ACL, VM snapshot không chứa payload, tmpfs/swap/core-dump, vận hành DB và xóa |
| Managed container service (Cloud Run/ECS/App Service) | MCP HTTP + private UI, worker riêng | Streaming/reachability, timeout, IdP, region, autoscaling, no-backup/versioning/soft-delete và storage lifecycle |
| Kubernetes riêng | Cgroup/NetworkPolicy/queue/secret separation rõ | Quyền cluster, chi phí/vận hành, enforce policy thật và kiểm namespace isolation |

Ưu tiên đề xuất container service hoặc VM private theo khả năng đáp ứng retention; chưa chọn nhà cung cấp hay tạo tài khoản. Topology: ChatGPT → TLS/authenticated MCP gateway → safe tools; owner UI → HTTPS cookie session/CSRF → API → PostgreSQL job IDs → compute worker → encrypted ephemeral payload storage. Không raw images/mesh/grants/URL vào model context. Fallback hiện chỉ pf_open_workspace và login guide; không expose dense tools.

OAuth: dùng IdP chuẩn, Authorization Code + PKCE S256, state/nonce, exact callback allowlist, issuer/audience/exp/nbf/signature/scope validation, discovery/protected-resource metadata và registration theo khả năng host thật. UI login là session HttpOnly/Secure với CSRF; MCP bearer không vào browser. Account link chỉ theo principal issuer|subject đã verify phía server; không dùng email/user ID do widget/model khai. Owner allowlist server-side và private distribution là hai kiểm riêng. Chưa có browser login/account-link flow production trong source; production vẫn từ chối khởi động.

Worker child mới có process group, wall/CPU/AS/core/fd limits và cancellation. Đây chưa phải sandbox filesystem/network hay container cgroup: production phải read-only root, non-root UID, no-new-privileges, seccomp, private temporary directory, 2 GiB memory/no swap, CPU/pid/fd caps; chỉ API/DB/store routes cần thiết, không Internet cho CV/report. Scanner dùng Unix socket local, không đưa ảnh ra dịch vụ bên ngoài.

Storage policy: payload session TTL tuyệt đối 24h; raw finalize/reject xóa ngay, abandoned raw ≤ticket expiry+15min; grant ≤5min và session expiry; revoke trước purge, purge≤24h từ yêu cầu; audit/receipt metadata 30days. Phải kiểm backup/versioning/soft-delete/snapshots/provider logs/region thực tế cho cả DB, filesystem, object store, temp/cache. Mã hóa AES-GCM local không tự chứng minh provider compliance. Nếu không tắt được lưu payload lịch sử, provider đó không đáp ứng contract.

Các URL tài liệu cần đọc lại được ghi trong docs/NETWORK_REQUIREMENTS.md. Hai yêu cầu HTTPS tới OpenAI/MCP trong phiên này bị proxy CONNECT403; không nhận nội dung trang và không khẳng định tính tương thích/cost hiện hành.
