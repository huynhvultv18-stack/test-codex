# Rule validation

Local DSL/template/source-freeze controls pass regression T27–T34. Tests include drafts, expression/script/unknown fields, direct and indirect prohibited personal claims, exact template hash mismatch, edition/locator/tradition drift and altered source snapshot. Evidence/release-regression.xml contains current case results; test source synthetic status is explicit.

Real reviewed rules count=0. Real contradictory-source reconciliation NOT RUN because no released sources/reviewer exist. No personalized inference rules are added. Rule conflict review requires tradition-separated definitions/citations, deterministic priority, duplicate-ID/ambiguous-trigger checks and review of every candidate template plus translation in the same release. Schema/hash agreement is necessary but cannot establish scholarly/semantic correctness; CONTENT RELEASE remains BLOCKED.
