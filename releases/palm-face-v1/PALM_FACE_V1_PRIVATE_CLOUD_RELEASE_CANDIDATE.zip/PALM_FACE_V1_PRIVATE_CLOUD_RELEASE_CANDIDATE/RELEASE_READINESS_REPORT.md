# PALM & FACE V1 — current release readiness

```text
BASELINE INTEGRITY = PASS
P0 CLOUD DEPLOYMENT = BLOCKED
P1 CV = BLOCKED
P1 KNOWLEDGE = BLOCKED
P1 HOST RUNTIME = BLOCKED
P1 CONTRACT = BLOCKED
FINAL REGRESSION = PASS
HOST INTEGRATION = BLOCKED
CV MODE = ASSISTED
PRODUCTION READY = NO
```

Ngày 12/10/2026 19:50 +07. Đây là trạng thái nguồn/bằng chứng đã bàn giao, không phải deployment hoặc Plugin đang hoạt động.

Baseline checksum122files và SPEC checksum18files PASS; cả hai ZIP đầu vào bất biến, locked spec parity và8test files gốc không đổi; repository test-codex không đổi. Đã chạy baseline62tests, sau hardening78tests PASS/0failed/0errors/0skipped (2SDK deprecation/forward-reference warnings). Process kill/CPU/RAM/cancel/decode/raw rejection/stale lease/replay/queue20 tests là execution thật; scanner adapter chỉ có protocol doubles. Chromium154desktop/mobile320px không page error, MCP SDK initialize/list/call/resources local PASS, PDF7pages tiếng Việt được rasterize/kiểm bố cục, Unicode selectable/embedded font, default không raster owner images. Fresh62hash-locked dependencies và repeat install/pip check đạt. Benchmark200actual local isolated jobs, no errors; scope và giới hạn trong PERFORMANCE_ACCEPTANCE.md.

Bản vá: decode/CV/PDFchild giới hạn process/CPU/AS/wall/fd/core; decode ngoài transaction/event loop với2slots; cancellation/revision/tombstone/raw hash checks; stale lease fence; reject PNG thiếu IEND; raw reject xóa ngay; optional local scanner fail-closed; không thay API/data contract/policy/TTL. Source/patch/changelog trong pf/, patches/release-hardening.patch và CHANGELOG_RELEASE.md. Không bỏ test hoặc bằng chứng lỗi; docs/evidence baseline và intermediate runs được giữ.

| BLOCKED | Lý do | Đã hoàn thành / bằng chứng | Bên cung cấp / hành động tiếp |
|---|---|---|---|
| P0 CLOUD DEPLOYMENT | Owner xác nhận CHƯA CÓ target/provider/region/budget/IdP/quyền host | Cloud topology/OAuth/TLS/ACL/storage plan: CLOUD_ARCHITECTURE.md, DEPLOYMENT_PLAN.md, SECURITY_ACCEPTANCE.md | Owner+IdP/admin/provider chọn target/region/budget, grant quyền bảo mật, sau đó chạy cloud acceptance |
| P1 CV | Model asset/hash/license/real semantic QA và holdout hợp lệ chưa cung cấp | Canonical/decode/geometry/manual guard tests; CV_VALIDATION_REPORT.md, MODEL_REGISTER.md, DATASET_REQUIREMENTS.md | Model rights/evaluation reviewer+dataset owner duyệt model/consent/holdout, freeze và đo NME/coverage/F1; giữ ASSISTED |
| P1 KNOWLEDGE |0reviewed active source/rule, chưa có rights/translation/appointed reviewer | DSL/source/template guard regressions; KNOWLEDGE_AUDIT.md, SOURCE_REGISTER.md, RULE_VALIDATION_REPORT.md, CONTENT_REVIEW_QUEUE.md | Owner appoint reviewer, verify edition/locator/snapshot/rights/translation; chỉ glossary/context, không personal inference |
| P1 HOST RUNTIME | Chưa có cloud/IdP/live scanner/cgroup/network/filesystem/provider retention/outage acceptance | Isolated process/decode/lease/queue/consent/delete/UI/PDF tests; RUNTIME_SECURITY_REPORT.md, PRIVACY_DELETION_REPORT.md, PERFORMANCE_ACCEPTANCE.md | Security/operator+provider deploy authorized staging, prove live signatures/limits/no-backup/versioning/soft-delete and outage/delete deadlines |
| P1 CONTRACT | Committed slot-delete chưa có locked route, SCR-001 chưa approved | Replacement/full-session delete tested; locked schema/API unchanged; SCR_001_DECISION.md, CONTRACT_COMPATIBILITY_REPORT.md | Owner/API authority decide semantics; approve new version if true slot removal required before implementation |
| HOST INTEGRATION | Chưa có authorized HTTPS endpoint, real OAuth/ChatGPT account/capabilities | Real local MCP transport only safe pf_open_workspace/login resource: MCP_INTEGRATION_REPORT.md, evidence/mcp-local.json | Owner/workspace admin connect approved staging MCP, verify OAuth/ACL/tools/UI/secret separation; private installation only after approval |

BLOCKED_GATE_MATRIX.csv có58rows, bao phủ T01–T52 và6release gates: requirement ID/test ID/evidence/actual result/status/dependency/scope.11local mechanics gates PASS;47rows BLOCKED. Passing test count không thay acceptance trên cloud/người thật. Không thu thập ảnh cá nhân, gọi externalAI, tự mua/deploy/publish/installPlugin, active model/corpus hay nâng production. Secret entry qua settings, không chat.

ZIP bàn giao PALM_FACE_V1_PRIVATE_CLOUD_RELEASE_CANDIDATE.zip gồm source, patches, immutable spec, tests/evidence/history, all stage reports, gate matrix, SBOM_RELEASE.json, LICENSE_REGISTER.md, CHECKSUMS.txt, input hashes và deployment/rollback plan. Runtime/venv/node_modules/credentials không thuộc package. ZIP có sidecar SHA256; root CHECKSUMS xác minh từng file. Tái tạo từ README.md; live services cần khởi động lại, không giả định nằm trong ZIP. Production chỉ được duyệt sau mandatory P0/P1=0 với evidence thật.
