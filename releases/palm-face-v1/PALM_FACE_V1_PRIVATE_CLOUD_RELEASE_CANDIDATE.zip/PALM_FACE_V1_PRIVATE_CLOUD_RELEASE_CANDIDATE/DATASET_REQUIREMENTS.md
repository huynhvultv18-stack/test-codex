# Real-image evaluation prerequisites

No dataset is bundled or recruited. Owner must authorize acquisition/evaluation separately with adult self-image consent, rights/license proof, retention/deletion plan and designated evaluation reviewer. Do not use chat/session images for training; no inferred race/age/gender/identity labels.

Locked pilot:60 consenting adults or equivalent rights-cleared data,5slots each; participant-disjoint20tuning/40holdout. Freeze model asset hashes, preprocessing, thresholds and semantic map before holdout; dual annotate/adjudicate≥20% of test participants; mark unclear/occluded rather than forcing labels. Ground truth is geometry/visible creases, never personality/fate.

Record eligible and rejected denominators, NME hand normalized by bbox diagonal and face by face width, coverage, QC reject recall and false reject, formula-wise absolute error, crease centerline F1 tolerance0.01palm-width; bootstrap participants1000times, confidence intervals and pilot limitations. Targets from spec/locked/TEST_PLAN.md: hand median≤0.04/p95≤0.08, face≤0.03/0.06, coverage≥90%, creaseF1≥0.80, QC recall≥0.95/false-reject≤0.15, ratio median≤0.03/p95≤0.06. These are acceptance targets, not observed results.

Retain only authorized evaluation evidence outside source ZIP with pseudonymous participants, restricted reviewers and approved lifecycle. Publish aggregate geometric performance, missingness and permitted acquisition conditions. AUTO_VALIDATED requires actual frozen holdout pass plus model/data/semantic rights; local synthetic tests cannot grant it.
