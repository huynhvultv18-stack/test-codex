"""Phase 2 retention foundation; analysis and report workers added in next phases."""
from .common import *
from .auth import Principal

def cycle(svc,config):
    with svc.db.tx() as c:
        for id,owner in c.execute("SELECT id,owner FROM objects WHERE kind='session'").fetchall():
            s=svc.db.get(c,id,owner)
            if dt(s['view']['expires_at'])<=now():svc.delete(c,id,Principal(owner,frozenset()),expired=True)
        for id,owner in c.execute("SELECT id,owner FROM objects WHERE kind='receipt'").fetchall():
            receipt=svc.db.get(c,id,owner);retry_id='retry_'+id;plan=svc.db.get(c,retry_id,owner)
            if receipt['state']=='failed' and plan and dt(plan['next_attempt'])>now():continue
            outcome=svc.purge(c,Principal(owner,frozenset()),id)
            if outcome['state']=='failed':
                attempt=(plan or {}).get('attempt',0)+1
                svc.db.put(c,retry_id,owner,'purge_retry',receipt['session_id'],dict(attempt=attempt,next_attempt=stamp(now()+timedelta(seconds=min(3600,30*2**min(attempt,6))))))
        # Unknown session directories older than the absolute payload TTL are orphans.
        import shutil,time
        known={r[0] for r in c.execute("SELECT DISTINCT sid FROM objects WHERE kind IN ('session','tombstone','receipt')").fetchall()}
        for directory in svc.db.root.iterdir():
            if directory.is_dir() and directory.name not in known and time.time()-directory.stat().st_mtime>=86400:shutil.rmtree(directory)
        c.execute('DELETE FROM idempotency WHERE expires<now()')
        c.execute("DELETE FROM audit WHERE created<now()-interval '30 days'")

from datetime import timedelta
import copy,json,time
from .contracts import validate

def enqueue(svc,c,p,s,b,kind):
    validate('AnalyzeRequest' if kind=='analysis' else 'ReportCreateRequest',b);v=s['view'];svc.revision(s,b['expected_session_revision'])
    if kind=='analysis':
        if v['state'] not in ('ready','failed') or len(v['images'])!=5:raise Problem('QUALITY_BLOCKED')
        from .images import ready
        clone=copy.deepcopy(s);ready(clone)
        if clone['view']['state']!='ready':raise Problem('QUALITY_BLOCKED')
    else:
        if v['state']!='completed' or v['review_confirmed_revision']!=v['session_revision']:raise Problem('INVALID_STATE',409)
        if s['annotation']['annotation_revision']!=b['expected_annotation_revision']:raise Problem('REVISION_CONFLICT',409)
        if b['include_images']!=v['consent']['include_images_in_pdf']:raise Problem('CONSENT_REQUIRED')
    jobs=c.execute("SELECT id FROM objects WHERE sid=%s AND kind='job'",(v['session_id'],)).fetchall()
    if any(svc.db.get(c,id,p.owner)['view']['state'] in ('queued','running') for (id,) in jobs):raise Problem('INVALID_STATE',409)
    if c.execute("SELECT count(*) FROM leases WHERE state='queued'").fetchone()[0]>=20:raise Problem('RATE_LIMITED',429)
    id=uid('job');t=stamp();view=dict(job_id=id,session_id=v['session_id'],job_type=kind,state='queued',stage='queued',snapshot_session_revision=v['session_revision'],result_id=None,error_code=None,created_at=t,updated_at=t)
    validate('JobView',view);record=dict(view=view,snapshot=copy.deepcopy(s),request=b)
    svc.db.put(c,id,p.owner,'job',v['session_id'],record)
    c.execute('INSERT INTO leases(job_id,owner,sid,state) VALUES(%s,%s,%s,%s)',(id,p.owner,v['session_id'],'queued'))
    if kind=='analysis':v['state']='analyzing';svc.save(c,s,p)
    return view

def claim(svc):
    with svc.db.tx() as c:
        for id,owner,attempt in c.execute("SELECT job_id,owner,attempt FROM leases WHERE state='running' AND until_at<now()").fetchall():
            j=svc.db.get(c,id,owner)
            if not j:continue
            if attempt>=1:
                j['view'].update(state='failed',stage='failed',error_code='JOB_TIMEOUT');svc.db.put(c,id,owner,'job',j['view']['session_id'],j);c.execute("UPDATE leases SET state='failed' WHERE job_id=%s",(id,))
                s=svc.db.get(c,j['view']['session_id'],owner)
                if s and not s.get('tombstone') and j['view']['job_type']=='analysis':s['view']['state']='failed';svc.save(c,s,Principal(owner,frozenset()))
            else:c.execute("UPDATE leases SET state='queued',attempt=attempt+1 WHERE job_id=%s",(id,))
        if c.execute("SELECT count(*) FROM leases WHERE state='running'").fetchone()[0]>=2:return None
        row=c.execute("SELECT job_id,owner,attempt FROM leases WHERE state='queued' ORDER BY job_id LIMIT 1 FOR UPDATE SKIP LOCKED").fetchone()
        if not row:return None
        id,owner,attempt=row;j=svc.db.get(c,id,owner);p=Principal(owner,frozenset())
        try:svc.session(c,j['view']['session_id'],p)
        except Problem:
            c.execute("UPDATE leases SET state='cancelled' WHERE job_id=%s",(id,));return None
        j['view'].update(state='running',stage='preprocess' if j['view']['job_type']=='analysis' else 'pdf',updated_at=stamp())
        svc.db.put(c,id,owner,'job',j['view']['session_id'],j);c.execute("UPDATE leases SET state='running',until_at=now()+interval '130 seconds' WHERE job_id=%s",(id,))
        j['_lease_attempt']=attempt
        return id,owner,j

def current_lease(c,id,j):
    row=c.execute('SELECT state,attempt,until_at FROM leases WHERE job_id=%s',(id,)).fetchone()
    return bool(row and row[0]=='running' and row[1]==j.get('_lease_attempt',0) and row[2]>now())

def run_job(svc,claimed,*,isolated=False):
    if not claimed:return
    id,owner,j=claimed;sid=j['view']['session_id'];p=Principal(owner,frozenset());started=time.monotonic();pdf=None
    try:
        if isolated:
            import base64
            from .sandbox import compute
            def cancelled():
                with svc.db.tx() as c:
                    s=svc.db.get(c,sid,owner)
                    return (not current_lease(c,id,j) or not s or s.get('tombstone') or
                            dt(s['view']['expires_at'])<=now() or
                            s['view']['session_revision']!=j['view']['snapshot_session_revision'])
            kind=j['view']['job_type'];timeout=120 if kind=='analysis' else 60
            out=compute(kind,dict(config=svc.db.compute_config,owner=owner,snapshot=j['snapshot'],request=j['request']),
                        wall_seconds=timeout,cpu_seconds=timeout,cancelled=cancelled)
            if kind=='analysis':result=out['analysis']
            else:result=out['manifest'];pdf=base64.b64decode(out['pdf'],validate=True)
        elif j['view']['job_type']=='analysis':
            from .cv import analyze
            result=analyze(svc,None,p,j['snapshot'])
        else:
            from .reports import render_pdf
            result,pdf=render_pdf(svc,j['snapshot'],j['request'])
        timeout=120 if j['view']['job_type']=='analysis' else 60
        if time.monotonic()-started>timeout:raise Problem('JOB_TIMEOUT',503)
        with svc.db.tx() as c:
            if not current_lease(c,id,j):return
            s=svc.db.get(c,sid,owner)
            if not s or s.get('tombstone') or dt(s['view']['expires_at'])<=now() or s['view']['session_revision']!=j['view']['snapshot_session_revision']:return
            if pdf is None:
                from .invariants import analysis_invariants
                analysis_invariants(result,s['view'])
                aid=result['analysis_id'];s['machine']=copy.deepcopy(result);s['derived']=result;s['view']['latest_analysis_id']=aid;s['view']['state']='review'
                s['annotation']=dict(session_id=sid,annotation_revision=0,base_analysis_id=aid,session_revision=s['view']['session_revision'],operations=[],updated_at=stamp())
                svc.db.put(c,aid,owner,'analysis',sid,result);result_id=aid
            else:
                result_id=result['report_id'];svc.db.write(sid,result_id,pdf);svc.db.put(c,result_id,owner,'report',sid,result)
            svc.save(c,s,p);j['view'].update(state='succeeded',stage='done',result_id=result_id,updated_at=stamp());svc.db.put(c,id,owner,'job',sid,j);c.execute("UPDATE leases SET state='succeeded' WHERE job_id=%s",(id,))
    except Exception as e:
        with svc.db.tx() as c:
            if not current_lease(c,id,j):return
            s=svc.db.get(c,sid,owner)
            if not s or s.get('tombstone'):return
            j['view'].update(state='failed',stage='failed',error_code=e.code if isinstance(e,Problem) else 'INTERNAL_ERROR',updated_at=stamp());svc.db.put(c,id,owner,'job',sid,j);c.execute("UPDATE leases SET state='failed' WHERE job_id=%s",(id,))
            if j['view']['job_type']=='analysis':s['view']['state']='failed';svc.save(c,s,p)

# Retention always runs before compute; mutable payload never outlives the absolute session TTL.
_maintenance=cycle
def cycle(svc,config):
    _maintenance(svc,config)
    with svc.db.tx() as c:
        for id,owner in c.execute("SELECT id,owner FROM objects WHERE kind='upload'").fetchall():
            t=svc.db.get(c,id,owner)
            if t['finalized'] or dt(t['ticket']['expires_at'])+timedelta(minutes=15)<=now():svc.db.erase(t['ticket']['session_id'],id)
            if not t['finalized'] and dt(t['ticket']['expires_at'])<=now():
                try:
                    s=svc.session(c,t['ticket']['session_id'],Principal(owner,frozenset()))
                    if s['view']['state']=='uploading':s['view']['state']=t['previous_state'];svc.save(c,s,Principal(owner,frozenset()))
                except Problem:pass
        for id,owner in c.execute("SELECT id,owner FROM objects WHERE kind='tombstone'").fetchall():
            t=svc.db.get(c,id,owner)
            if dt(t['retained_until'])<=now():c.execute('DELETE FROM objects WHERE sid=%s',(id,))
    # Local direct unit tests retain a deterministic compute seam; shipped runtime is isolated.
    run_job(svc,claim(svc),isolated=True)
