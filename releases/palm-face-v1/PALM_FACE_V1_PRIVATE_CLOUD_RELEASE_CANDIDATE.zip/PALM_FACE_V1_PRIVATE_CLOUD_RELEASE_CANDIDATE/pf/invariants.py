"""Runtime reference/score/formula invariants complement the unchanged schema."""
import math
from .common import Problem,SLOTS
from .geometry import FACE
from .contracts import validate
FORMULAS={k:v[0] for k,v in FACE.items()}|{'line_length_palm_width_ratio':'palm_arc_width_v1','line_straightness_ratio':'palm_chord_arc_v1','line_visible_branch_count':'palm_branch_count_v1'}
def analysis_invariants(a,view):
    validate('AnalysisSnapshot',a)
    images={x['image_id']:x for x in view['images']}
    if len(images)!=5 or len({x['slot'] for x in images.values()})!=5:raise Problem('VALIDATION_ERROR')
    refs=a['image_revisions']
    if len({x['image_id'] for x in refs})!=5 or {x['image_id'] for x in refs}!=set(images):raise Problem('VALIDATION_ERROR')
    for ref in refs:
        if any(ref[k]!=images[ref['image_id']][k] for k in ('image_revision','canonical_sha256')):raise Problem('REVISION_CONFLICT',409)
    for r in a['palm_results']+a['face_results']:
        if r['image_id'] not in images or r['slot']!=images[r['image_id']]['slot']:raise Problem('VALIDATION_ERROR')
        lms=r['landmarks'];ids={l['id'] for l in lms}
        if len(ids)!=len(lms) or any(not l['id'].startswith(r['image_id']+'_lm_') for l in lms):raise Problem('MODEL_MISMATCH',503)
        for l in lms:
            if l['origin']=='manual' and l['raw_model_score'] is not None:raise Problem('VALIDATION_ERROR')
        lines=r.get('lines',[]);lineids={l['line_id'] for l in lines}
        if len(lineids)!=len(lines) or any(l['image_id']!=r['image_id'] for l in lines):raise Problem('VALIDATION_ERROR')
        evidence=ids|lineids
        metrics=r.get('metrics',[])+[m for l in lines for m in l['descriptors']]
        for m in metrics:
            if m['image_id']!=r['image_id'] or FORMULAS.get(m['metric_id'])!=m['formula_id'] or not set(m['evidence_refs'])<=evidence:raise Problem('VALIDATION_ERROR')
            if m['value'] is not None and not math.isfinite(m['value']):raise Problem('VALIDATION_ERROR')
            if m['metric_id']=='line_visible_branch_count' and m['status']=='observed':raise Problem('VALIDATION_ERROR') # no reviewed graph in current candidate
    return a
