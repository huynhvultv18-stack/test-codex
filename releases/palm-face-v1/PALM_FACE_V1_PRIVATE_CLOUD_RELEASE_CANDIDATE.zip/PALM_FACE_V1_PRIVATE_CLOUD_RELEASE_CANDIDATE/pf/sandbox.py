"""Linux process limits and cancellation. This is not a network/filesystem sandbox."""
import json, os, signal, subprocess, sys, time
from .common import Problem

MEMORY_BYTES = 2 * 1024**3

def execute(command, payload, *, wall_seconds, cpu_seconds, memory_bytes=MEMORY_BYTES,
            cancelled=None):
    if sys.platform != 'linux':
        raise Problem('INTERNAL_ERROR', 503)
    # Neither command line, environment nor diagnostic logs contain job/credential values.
    env = {k: v for k, v in os.environ.items() if k in ('PATH', 'LANG', 'LC_ALL')}
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
               MPLCONFIGDIR='/tmp/pf-matplotlib', PYTHONDONTWRITEBYTECODE='1')
    request = json.dumps(dict(payload=payload, cpu_seconds=cpu_seconds,
                              memory_bytes=memory_bytes), allow_nan=False).encode()
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL, start_new_session=True, env=env)
    started = time.monotonic()
    try:
        first = True
        while True:
            if cancelled and cancelled():
                raise Problem('SESSION_EXPIRED', 410)
            remaining = wall_seconds - (time.monotonic() - started)
            if remaining <= 0:
                raise Problem('JOB_TIMEOUT', 503)
            try:
                output, _ = process.communicate(request if first else None,
                                                timeout=min(.25, remaining))
                break
            except subprocess.TimeoutExpired:
                first = False
        if process.returncode:
            # SIGXCPU and other resource failures never publish partial results.
            raise Problem('JOB_TIMEOUT' if process.returncode == -signal.SIGXCPU
                          else 'INTERNAL_ERROR', 503)
        envelope = json.loads(output)
        if envelope.get('error'):
            code = envelope['error']
            if code not in {'UNSUPPORTED_MEDIA','PIXEL_LIMIT','FILE_TOO_LARGE',
                            'MODEL_MISMATCH','REPORT_FAILED','CONSENT_REQUIRED',
                            'INVALID_STATE','NOT_FOUND','SESSION_EXPIRED'}:
                code = 'INTERNAL_ERROR'
            raise Problem(code, envelope.get('status', 503))
        return envelope['result']
    except (ValueError, KeyError):
        raise Problem('INTERNAL_ERROR', 503)
    finally:
        # Kill the entire owned process group, including any descendants on success.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()
        for stream in (process.stdin, process.stdout):
            if stream:
                stream.close()

def compute(operation, payload, *, wall_seconds, cpu_seconds, cancelled=None):
    return execute([sys.executable, '-m', 'pf.sandbox_child', operation], payload,
                   wall_seconds=wall_seconds, cpu_seconds=cpu_seconds,
                   cancelled=cancelled)
