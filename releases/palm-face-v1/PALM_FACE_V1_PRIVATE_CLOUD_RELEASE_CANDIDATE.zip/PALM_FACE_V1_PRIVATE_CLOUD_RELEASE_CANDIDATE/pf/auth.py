"""Standard OIDC verification in deployment; HS dev IdP exclusively synthetic."""
import jwt,os
from dataclasses import dataclass
from .common import Problem
@dataclass(frozen=True)
class Principal:
    owner:str
    scopes:frozenset
    ui:bool=False

def verify(token,config,ui=False):
    try:
        if config.get('mode')=='synthetic':
            data=jwt.decode(token,config['dev_auth_key'],algorithms=['HS256'],audience='pf-synthetic',issuer='urn:pf:dev-idp',options={'require':['exp','sub','iat','iss','aud']})
        else:
            # Only pinned HTTPS JWKS endpoint; no token-controlled URL.
            issuer=config['oidc_issuer'];jwks=config['oidc_jwks_uri']
            if not issuer.startswith('https://') or not jwks.startswith('https://'):raise ValueError()
            key=jwt.PyJWKClient(jwks).get_signing_key_from_jwt(token).key
            data=jwt.decode(token,key,algorithms=['RS256'],audience=config['oidc_audience'],issuer=issuer,options={'require':['exp','sub','iat','iss','aud']})
        scopes=frozenset(data.get('scope','').split())
        return Principal(data['iss']+'|'+data['sub'],scopes,ui)
    except Exception:raise Problem('UNAUTHENTICATED',401)
