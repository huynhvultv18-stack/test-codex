import io,hashlib,json,copy,warnings,struct,zlib
from datetime import timedelta
from PIL import Image,ImageOps,ImageCms
import numpy as np,cv2
from .contracts import ROOT,validate
from .common import *
from .geometry import adapt
MAX_BYTES=20971520;MAX_PIXELS=24000000
Image.MAX_IMAGE_PIXELS=MAX_PIXELS
REGISTRY=json.loads((ROOT/'fixtures/synthetic/registry.json').read_text())

def normalize(raw,mime,mirrored):
    if len(raw)>MAX_BYTES:raise Problem('FILE_TOO_LARGE',413)
    if raw.startswith(b'\x89PNG\r\n\x1a\n'):
        pos=8;ended=False
        while pos<len(raw):
            if pos+12>len(raw):raise Problem('UNSUPPORTED_MEDIA',415)
            n=int.from_bytes(raw[pos:pos+4],'big');kind=raw[pos+4:pos+8];end=pos+12+n
            if end>len(raw) or zlib.crc32(raw[pos+4:pos+8+n])&0xffffffff!=int.from_bytes(raw[pos+8+n:end],'big'):raise Problem('UNSUPPORTED_MEDIA',415)
            pos=end
            if kind==b'IEND':
                if n!=0:raise Problem('UNSUPPORTED_MEDIA',415)
                ended=True;break
        if not ended or pos!=len(raw):raise Problem('UNSUPPORTED_MEDIA',415)
    elif raw.startswith(b'\xff\xd8'):
        if not raw.endswith(b'\xff\xd9'):raise Problem('UNSUPPORTED_MEDIA',415)
    elif raw[:4]==b'RIFF' and raw[8:12]==b'WEBP':
        if int.from_bytes(raw[4:8],'little')+8!=len(raw):raise Problem('UNSUPPORTED_MEDIA',415)
    else:raise Problem('UNSUPPORTED_MEDIA',415)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            im=Image.open(io.BytesIO(raw));fmt=im.format
            if {'PNG':'image/png','JPEG':'image/jpeg','WEBP':'image/webp'}.get(fmt)!=mime or getattr(im,'n_frames',1)!=1:raise Problem('UNSUPPORTED_MEDIA',415)
            if im.width*im.height>MAX_PIXELS:raise Problem('PIXEL_LIMIT',413)
            sw,sh=im.size;orientation=int(im.getexif().get(274,1));im.load()
            profile=im.info.get('icc_profile');im=ImageOps.exif_transpose(im)
            if profile:
                im=ImageCms.profileToProfile(im,ImageCms.ImageCmsProfile(io.BytesIO(profile)),ImageCms.createProfile('sRGB'),outputMode='RGB')
            else:im=im.convert('RGB')
            # EXIF maps original source pixels into orientation-normalized pixels.
            matrices={1:[[1,0,0],[0,1,0],[0,0,1]],2:[[-1,0,sw-1],[0,1,0],[0,0,1]],3:[[-1,0,sw-1],[0,-1,sh-1],[0,0,1]],4:[[1,0,0],[0,-1,sh-1],[0,0,1]],5:[[0,1,0],[1,0,0],[0,0,1]],6:[[0,-1,sh-1],[1,0,0],[0,0,1]],7:[[0,-1,sh-1],[-1,0,sw-1],[0,0,1]],8:[[0,1,0],[-1,0,sw-1],[0,0,1]]}
            if orientation not in matrices:raise Problem('UNSUPPORTED_MEDIA',415)
            matrix=np.array(matrices[orientation],dtype=float)
            normalized=io.BytesIO();im.save(normalized,format='PNG')
            if mirrored:
                matrix=np.array([[-1,0,im.width-1],[0,1,0],[0,0,1]])@matrix;im=ImageOps.mirror(im)
            canonical=io.BytesIO();im.save(canonical,format='PNG')
            transform=dict(source_width=sw,source_height=sh,exif_orientation_applied=orientation,source_to_canonical_pixel_matrix=matrix.tolist(),preprocessing_version='PF-PREPROCESS-1')
            return normalized.getvalue(),canonical.getvalue(),im.size,transform
    except Problem:raise
    except (Image.DecompressionBombError,Image.DecompressionBombWarning):raise Problem('PIXEL_LIMIT',413)
    except Exception:raise Problem('UNSUPPORTED_MEDIA',415)

def quality(id,data,slot,confirmed,fixture=None):
    im=Image.open(io.BytesIO(data));a=np.array(im);grey=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY);small=cv2.resize(grey,(512,384));blur=float(cv2.Laplacian(small,cv2.CV_64F).var())
    # Measured pixel checks are calibration hypotheses. Semantic/pose checks abstain without verified detector.
    short=min(im.size);hard=short<768
    checks=[dict(code='resolution',status='fail' if hard else 'pass',message_vi='Cạnh ngắn cần ít nhất 768 pixel.'),dict(code='blur',status='warning' if blur<30 else 'pass',message_vi='Ngưỡng độ nét thử nghiệm, chưa hiệu chuẩn trên ảnh thật.'),dict(code='mirror_confirmation',status='pass' if confirmed else 'warning',message_vi='Owner phải xác nhận trạng thái mirror.'),dict(code='file_integrity',status='pass',message_vi='File đã decode và bỏ metadata.')]
    count=fixture['count'] if fixture else None
    wrong=fixture and fixture['slot']!=slot;multiple=count is not None and count!=1
    checks.extend([dict(code='object_count',status='fail' if multiple else 'pass' if fixture else 'unknown',message_vi='Số chủ thể từ fixture synthetic; detector thật chưa xác minh.'),dict(code='slot_content',status='fail' if wrong else 'pass' if fixture else 'unknown',message_vi='Đúng vị trí synthetic; lòng/mu bàn tay thật cần xác minh.'),dict(code='pose',status='pass' if fixture else 'unknown',message_vi='Pose synthetic; tỷ lệ thật tắt khi pose chưa chắc chắn.')])
    if hard or wrong or multiple:status='reshoot'
    elif not fixture:status='fatal'
    elif any(x['status']=='warning' for x in checks):status='review'
    else:status='accept'
    return validate('QualityResult',dict(image_id=id,status=status,checks=checks,object_count=count,config_version='PF-QC-SYNTHETIC-1',warnings_acknowledged=False))

def ready(s):
    images=s['view']['images'];s['view']['state']='quality_review'
    if len(images)==5 and {i['slot'] for i in images}==set(SLOTS) and all(i['mirror_confirmed'] and (i['quality']['status']=='accept' or i['quality']['status']=='review' and i['quality']['warnings_acknowledged']) for i in images):s['view']['state']='ready'

def content(svc,c,p,tid,raw,origin):
    t=svc.db.get(c,tid,p.owner)
    if not t:raise Problem('NOT_FOUND',404)
    svc.session(c,t['ticket']['session_id'],p)
    if dt(t['ticket']['expires_at'])<=now() or t['finalized']:raise Problem('UPLOAD_EXPIRED',410)
    if t['origin']!=origin:raise Problem('FORBIDDEN',403)
    if len(raw)>MAX_BYTES:raise Problem('FILE_TOO_LARGE',413)
    if len(raw)!=t['request']['size_bytes']:raise Problem('VALIDATION_ERROR')
    # Development mode permits only the generated, rights-safe synthetic fixture bytes.
    if hashlib.sha256(raw).hexdigest() not in REGISTRY:raise Problem('POLICY_BLOCKED',403)
    if svc.db.scanner_socket:
        from .scanning import scan
        scan(raw,svc.db.scanner_socket)
    svc.db.write(t['ticket']['session_id'],tid,raw)

def preprocess_upload(svc,p,sid,b):
    """Read an authorized snapshot, then release the transaction for bounded decoding."""
    validate('UploadFinalizeRequest',b);tid=b['ticket_id']
    with svc.db.tx() as c:
        s=svc.session(c,sid,p);svc.revision(s,b['expected_session_revision'])
        t=svc.db.get(c,tid,p.owner)
        if not t or t['ticket']['session_id']!=sid:raise Problem('NOT_FOUND',404)
        if dt(t['ticket']['expires_at'])<=now() or t['finalized']:raise Problem('UPLOAD_EXPIRED',410)
        try:raw=svc.db.read(sid,tid)
        except FileNotFoundError:raise Problem('INVALID_STATE',409)
        request=copy.deepcopy(t['request'])
    from .sandbox import compute
    import base64
    def cancelled():
        with svc.db.tx() as c:
            current=svc.db.get(c,sid,p.owner)
            return (not current or current.get('tombstone') or
                    dt(current['view']['expires_at'])<=now() or
                    current['view']['session_revision']!=b['expected_session_revision'])
    try:
        result=compute('normalize',dict(raw=base64.b64encode(raw).decode(),mime=request['mime_type'],
                       mirrored=request['mirrored']),wall_seconds=30,cpu_seconds=25,cancelled=cancelled)
        result['raw_sha256']=hashlib.sha256(raw).hexdigest()
        return result
    except Exception:
        svc.db.erase(sid,tid)
        raise

def finalize(svc,c,p,s,b,config):
    validate('UploadFinalizeRequest',b);svc.revision(s,b['expected_session_revision']);tid=b['ticket_id'];t=svc.db.get(c,tid,p.owner);sid=s['view']['session_id']
    if not t or t['ticket']['session_id']!=sid:raise Problem('NOT_FOUND',404)
    if dt(t['ticket']['expires_at'])<=now() or t['finalized']:raise Problem('UPLOAD_EXPIRED',410)
    try:raw=svc.db.read(sid,tid)
    except FileNotFoundError:raise Problem('INVALID_STATE',409)
    r=t['request']
    try:
        from .sandbox import compute
        import base64
        normalized=config.get('_normalized_upload',{}).get(tid)
        if normalized is None:
            normalized=compute('normalize',dict(raw=base64.b64encode(raw).decode(),mime=r['mime_type'],mirrored=r['mirrored']),wall_seconds=30,cpu_seconds=25)
        elif normalized['raw_sha256']!=hashlib.sha256(raw).hexdigest():raise Problem('REVISION_CONFLICT',409)
        normal=base64.b64decode(normalized['normal'],validate=True);canonical=base64.b64decode(normalized['canonical'],validate=True)
        size=tuple(normalized['size']);tr=normalized['transform']
    except Exception:
        svc.db.erase(sid,tid) # rejected raw bytes must be removed even if the DB transaction rolls back
        raise
    id=uid('img');fixture=REGISTRY.get(hashlib.sha256(raw).hexdigest());q=quality(id,canonical,r['slot'],r['mirror_confirmed'],fixture)
    old=next((x for x in s['view']['images'] if x['slot']==r['slot']),None)
    asset=dict(image_id=id,slot=r['slot'],image_revision=(old['image_revision']+1 if old else 1),canonical_sha256=hashlib.sha256(canonical).hexdigest(),width=size[0],height=size[1],mirrored=r['mirrored'],mirror_confirmed=r['mirror_confirmed'],quality=q,expires_at=s['view']['expires_at'],transform=tr)
    validate('ImageAsset',asset)
    svc.db.write(sid,id,canonical);svc.db.write(sid,id+'_normalized',normal)
    svc.db.put(c,id,p.owner,'image',sid,{'session_id':sid,'fixture':fixture})
    if old:
        svc.db.erase(sid,old['image_id']);svc.db.erase(sid,old['image_id']+'_normalized');c.execute('DELETE FROM objects WHERE id=%s',(old['image_id'],))
    s['view']['images']=[x for x in s['view']['images'] if x['slot']!=r['slot']]+[asset]
    svc.invalidate(c,s,p,inputs=True);ready(s);svc.save(c,s,p)
    t['finalized']=True;t['cleanup_at']=stamp(now()+timedelta(minutes=15));svc.db.put(c,tid,p.owner,'upload',sid,t)
    svc.db.erase(sid,tid) # immediate removal is within the raw retention upper bound
    return asset

def transform(svc,c,p,s,asset,b,config):
    validate('ImageTransformRequest',b);svc.revision(s,b['expected_session_revision'])
    if b['expected_image_revision']!=asset['image_revision']:raise Problem('REVISION_CONFLICT',409)
    raw=svc.db.read(s['view']['session_id'],asset['image_id']+'_normalized');_,canonical,_,extra=normalize(raw,'image/png',b['mirrored'])
    # Compose the mirror with the original EXIF transform, rather than applying EXIF twice.
    original=np.array(asset['transform']['source_to_canonical_pixel_matrix']);w=asset['width'];mirror=np.array([[-1,0,w-1],[0,1,0],[0,0,1]])
    normalized_matrix=mirror@original if asset['mirrored'] else original
    asset['transform']['source_to_canonical_pixel_matrix']=(mirror@normalized_matrix if b['mirrored'] else normalized_matrix).tolist()
    asset['mirrored']=b['mirrored'];asset['mirror_confirmed']=True;asset['image_revision']+=1;asset['canonical_sha256']=hashlib.sha256(canonical).hexdigest()
    metadata=svc.db.get(c,asset['image_id'],p.owner);asset['quality']=quality(asset['image_id'],canonical,asset['slot'],True,metadata['fixture'])
    svc.db.write(s['view']['session_id'],asset['image_id'],canonical);svc.invalidate(c,s,p,inputs=True);ready(s);svc.save(c,s,p);return asset
