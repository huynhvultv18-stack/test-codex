import io,hashlib,html
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader
from .common import *
from .contracts import ROOT,validate
from .knowledge import fusion
FONT=ROOT/'fonts/DejaVuSans.ttf'
pdfmetrics.registerFont(TTFont('PF-Vietnamese',str(FONT)))
SLOT_NAMES={'palm_left':'Lòng bàn tay trái','palm_right':'Lòng bàn tay phải','face_front':'Mặt chính diện','face_left_oblique':'Góc trái','face_right_oblique':'Góc phải'}

def render_pdf(svc,s,request):
    v=s['view'];a=s['derived']
    if v['state']!='completed' or v['review_confirmed_revision']!=v['session_revision']:raise Problem('INVALID_STATE',409)
    if request['include_images']!=v['consent']['include_images_in_pdf']:raise Problem('CONSENT_REQUIRED')
    f=fusion(a);buffer=io.BytesIO();pdf=canvas.Canvas(buffer,pagesize=A4,pageCompression=1);pdf.setTitle('PALM & FACE — Báo cáo quan sát synthetic');W,H=A4;page=1;y=H-50
    def text(value,size=10):
        nonlocal y,page
        pdf.setFont('PF-Vietnamese',size)
        # Wrap with font metrics; untrusted arbitrary text is never executed as markup.
        for paragraph in str(value).split('\n'):
            words=paragraph.split();line=''
            for word in words:
                candidate=(line+' '+word).strip()
                if pdfmetrics.stringWidth(candidate,'PF-Vietnamese',size)>W-80:
                    if y<55: footer();pdf.showPage();page+=1;y=H-50;pdf.setFont('PF-Vietnamese',size)
                    pdf.drawString(40,y,line);y-=size+5;line=word
                else:line=candidate
            if y<55: footer();pdf.showPage();page+=1;y=H-50;pdf.setFont('PF-Vietnamese',size)
            pdf.drawString(40,y,line);y-=size+5
    def footer():
        pdf.setFont('PF-Vietnamese',8);pdf.drawString(40,25,f'PF-SPEC-1.0.0 • PF-POLICY-1.0.0 • Trang {page} • SYNTHETIC / ASSISTED')
    text('PALM & FACE ANALYSIS V1.0',17);text('QUAN SÁT TỪ ẢNH — SYNTHETIC / ASSISTED',12)
    text('Bản kiểm thử hình học. Chưa được đánh giá trên người thật.');text('Không dùng thuật xem tay hoặc nhân tướng học để dự đoán vận mệnh.');text(f'Session revision: {v["session_revision"]}; annotation: {a["annotation_revision"]}')
    text(f'Tạo phiên: {v["created_at"]}');text(f'Hết hạn tuyệt đối: {v["expires_at"]}');text(f'Consent: {v["consent"]["version"]}; ảnh trong PDF: {request["include_images"]}')
    text(f['neutral_summary_vi']);text('KHÔNG ĐỦ DỮ LIỆU / GIỚI HẠN',12)
    for l in f['limitations']:text(l)
    text('TƯ LIỆU TRUYỀN THỐNG — CHƯA ĐƯỢC KHOA HỌC XÁC NHẬN',11)
    text('Chưa có corpus được người duyệt nghiệm thu. Cheiro chỉ là nguồn ứng viên cho tên gọi; Lavater chưa active. Nguồn Đông Á/Việt Nam chưa chọn. Không có thẻ truyền thống executable trong candidate này.')
    text('Nguồn thiết kế: SPEC_V1, API_SPEC, MODULE_DESIGN, SOURCE_REGISTER trong spec/locked. Formula registry v1; semantic map chỉ được kiểm synthetic.');text('Xuất PDF không gia hạn TTL; bản tải về có vòng đời riêng.');footer();pdf.showPage()
    for image in sorted(v['images'],key=lambda x:SLOTS.index(x['slot'])):
        page+=1;y=H-50;slot=image['slot'];r=next(x for x in a['palm_results']+a['face_results'] if x['image_id']==image['image_id'])
        text(SLOT_NAMES[slot],16);text('QUAN SÁT TỪ ẢNH');text(f'Ảnh {image["image_id"]}, revision {image["image_revision"]}, mirror {image["mirrored"]}')
        text(f'QC: {image["quality"]["status"]}; warnings acknowledged: {image["quality"]["warnings_acknowledged"]}')
        x0=50;y0=300;scale=min((W-100)/(image['width']-1),310/(image['height']-1));bw=(image['width']-1)*scale;bh=(image['height']-1)*scale
        pdf.setStrokeColorRGB(.7,.7,.7);pdf.rect(x0,y0,bw,bh)
        if request['include_images']:pdf.drawImage(ImageReader(io.BytesIO(svc.db.read(v['session_id'],image['image_id']))),x0,y0,width=bw,height=bh,preserveAspectRatio=False)
        pdf.setFillColorRGB(.1,.4,.65)
        for lm in r['landmarks']:
            p=lm['point'];pdf.circle(x0+p['x']*bw,y0+(1-p['y'])*bh,1.2,fill=1,stroke=0)
        pdf.setStrokeColorRGB(.7,.35,.05)
        for line in r.get('lines',[]):
            if line['status']=='rejected':continue
            path=pdf.beginPath();first=line['polyline'][0];path.moveTo(x0+first['x']*bw,y0+(1-first['y'])*bh)
            for p in line['polyline'][1:]:path.lineTo(x0+p['x']*bw,y0+(1-p['y'])*bh)
            pdf.drawPath(path);pdf.setFont('PF-Vietnamese',8);pdf.drawString(x0+first['x']*bw,y0+(1-first['y'])*bh,line['conventional_label']+' ('+line['status']+')')
        pdf.setFillColorRGB(0,0,0);y=280;text('Sơ đồ canonical; xanh: landmark, nâu: nếp gấp candidate/confirmed.');text('NGƯỜI DÙNG HIỆU CHỈNH được ghi theo origin; không coi là ground truth.')
        for m in r.get('metrics',[]):
            val=f'{m["value"]:.3f}' if m['value'] is not None else 'KHÔNG ĐỦ DỮ LIỆU'
            text(m['metric_id']+': '+val);text('Công thức: '+m['formula_id']+'; evidence: '+', '.join(m['evidence_refs']),8)
        text('Ảnh góc trái/phải không có metrics.' if 'oblique' in slot else 'Không có đơn vị mm, điểm đẹp hoặc lời dự báo.')
        footer();pdf.showPage()
    pdf.save();data=buffer.getvalue();pages=len(PdfReader(io.BytesIO(data)).pages)
    if pages>10 or len(data)>15728640:raise Problem('REPORT_FAILED',503)
    id=uid('rep');manifest=dict(report_id=id,session_id=v['session_id'],session_revision=v['session_revision'],annotation_revision=a['annotation_revision'],analysis_id=a['analysis_id'],language='vi-VN',include_images=request['include_images'],pdf_sha256=hashlib.sha256(data).hexdigest(),size_bytes=len(data),pages=pages,expires_at=v['expires_at'],download_path=f'/v1/reports/{id}/content')
    return validate('ReportManifest',manifest),data
