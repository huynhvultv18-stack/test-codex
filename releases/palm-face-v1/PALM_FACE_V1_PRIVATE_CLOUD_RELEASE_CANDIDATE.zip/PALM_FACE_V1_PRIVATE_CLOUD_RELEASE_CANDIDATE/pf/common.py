from datetime import datetime,timezone
import uuid
SLOTS=('palm_left','palm_right','face_front','face_left_oblique','face_right_oblique')
def now(): return datetime.now(timezone.utc)
def stamp(t=None): return (t or now()).isoformat().replace('+00:00','Z')
def dt(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def uid(prefix): return prefix+'_'+uuid.uuid4().hex
class Problem(Exception):
    def __init__(self,code,status=422): self.code,self.status=code,status
