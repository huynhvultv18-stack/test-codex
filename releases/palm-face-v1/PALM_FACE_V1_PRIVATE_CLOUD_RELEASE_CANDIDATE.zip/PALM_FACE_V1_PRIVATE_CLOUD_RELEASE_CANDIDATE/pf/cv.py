"""MediaPipe Tasks adapters do not implement palm crease or identity inference."""
import hashlib,json,io
from pathlib import Path
import numpy as np,cv2
from skimage.filters import meijering
from skimage.morphology import skeletonize
from PIL import Image
from .contracts import ROOT,validate
from .common import *
from .geometry import adapt,face_metrics,line_metrics

class MediaPipeAdapter:
    def __init__(self,kind,model_path,expected_sha):
        if kind not in ('hand','face') or not isinstance(expected_sha,str) or len(expected_sha)!=64:raise Problem('MODEL_MISMATCH',503)
        import mediapipe as mp
        from mediapipe.tasks.python import vision,BaseOptions
        p=Path(model_path)
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected_sha:raise Problem('MODEL_MISMATCH',503)
        self.kind=kind;self.mp=mp
        if kind=='hand':
            self.task=vision.HandLandmarker.create_from_options(vision.HandLandmarkerOptions(base_options=BaseOptions(model_asset_path=str(p)),running_mode=vision.RunningMode.IMAGE,num_hands=3))
        else:
            self.task=vision.FaceLandmarker.create_from_options(vision.FaceLandmarkerOptions(base_options=BaseOptions(model_asset_path=str(p)),running_mode=vision.RunningMode.IMAGE,num_faces=3,output_face_blendshapes=False,output_facial_transformation_matrixes=False))
    def detect(self,im,image_id):
        result=self.task.detect(self.mp.Image(image_format=self.mp.ImageFormat.SRGB,data=np.array(im.convert('RGB'))))
        groups=result.hand_landmarks if self.kind=='hand' else result.face_landmarks
        if len(groups)!=1:return {'count':len(groups),'landmarks':[]}
        points=[(x.x,x.y) for x in groups[0]]
        return {'count':1,'landmarks':adapt(points,21 if self.kind=='hand' else 478,image_id)}
    def close(self):self.task.close()

def creases(data,image,points):
    if not points:return []
    im=Image.open(io.BytesIO(data));w,h=im.size
    # ROI from wrist/MCP bounds; a planar approximation requiring review.
    p=[points[i]['point'] for i in (0,5,9,13,17)];xs=[x['x'] for x in p];ys=[x['y'] for x in p]
    x0,x1=int(min(xs)*(w-1)),int(max(xs)*(w-1));y0,y1=int(min(ys)*(h-1)),int(max(ys)*(h-1))
    if x1-x0<10 or y1-y0<10:return []
    grey=np.array(im.convert('L'))[y0:y1+1,x0:x1+1]/255.
    scale=min(1,384/max(grey.shape));g=cv2.resize(grey,None,fx=scale,fy=scale)
    response=meijering(g,sigmas=(1,2),black_ridges=True);mask=skeletonize(response>.25)
    n,labels,stats,_=cv2.connectedComponentsWithStats(mask.astype(np.uint8),8)
    out=[]
    for k in range(1,n):
        if stats[k,cv2.CC_STAT_AREA]<20:continue
        ys1,xs1=np.nonzero(labels==k);order=np.argsort(xs1);xs1,ys1=xs1[order],ys1[order]
        # Ordered candidate centerline may be ambiguous; never auto-confirm topology.
        step=max(1,len(xs1)//100);poly=[{'x':float((x0+x/scale)/(w-1)),'y':float((y0+y/scale)/(h-1))} for x,y in zip(xs1[::step],ys1[::step])]
        if len(poly)<2:continue
        out.append(validate('PalmLine',dict(line_id=uid('lin'),image_id=image,origin='automatic',status='candidate',conventional_label='unlabeled',polyline=poly,raw_model_score=None,descriptors=[],uncertainty_reason='Bộ lọc cổ điển chưa được hiệu chuẩn; cần xác nhận đường và topology.')))
        if len(out)==20:break
    return out

def analyze(svc,c,p,s):
    v=s['view'];palms=[];faces=[];refs=[]
    for slot in SLOTS:
        image=next(x for x in v['images'] if x['slot']==slot);id=image['image_id'];
        if c is None:
            with svc.db.tx() as read_tx:
                svc.session(read_tx,v['session_id'],p);meta=svc.db.get(read_tx,id,p.owner);raw=svc.db.read(v['session_id'],id)
        else:meta=svc.db.get(c,id,p.owner);raw=svc.db.read(v['session_id'],id)
        fixture=meta.get('fixture');points=[]
        if fixture:
            xy=fixture['points'];xy=[(1-x,y) for x,y in xy] if image['mirrored'] else xy
            points=adapt(xy,21 if slot.startswith('palm') else 478,id)
        limits=['Synthetic fixture adapter; chưa kiểm độ chính xác trên người thật.'] if fixture else ['Model/semantic QA chưa sẵn sàng; không đủ dữ liệu.']
        refs.append({k:image[k] for k in ('image_id','image_revision','canonical_sha256')})
        if slot.startswith('palm'):
            lines=creases(raw,id,points)
            palms.append(validate('PalmResult',dict(image_id=id,slot=slot,observation_status='observed' if points else 'not_observable',detected_handedness='unknown',declared_side=slot.removeprefix('palm_'),landmarks=points,lines=lines,limitations=limits)))
        else:
            metrics=face_metrics(id,points,image['width'],image['height'],slot,enabled=bool(fixture),pose_ok=bool(fixture))
            faces.append(validate('FaceResult',dict(image_id=id,slot=slot,observation_status='observed' if points else 'not_observable',landmarks=points,metrics=metrics,limitations=limits)))
    versions=dict(hand_model='SYNTHETIC-FIXTURE-NOT-MODEL',face_model='SYNTHETIC-FIXTURE-NOT-MODEL',crease_algorithm='PF-CREASE-CANDIDATE-1',preprocessing='PF-PREPROCESS-1',semantic_map='SYNTHETIC-MAP-1',quality_config='PF-QC-SYNTHETIC-1',corpus='PF-CORPUS-INACTIVE-1',policy='PF-POLICY-1.0.0')
    return validate('AnalysisSnapshot',dict(analysis_id=uid('ana'),session_id=v['session_id'],session_revision=v['session_revision'],annotation_revision=0,contract_version='1.0.0',image_revisions=refs,versions=versions,palm_results=palms,face_results=faces,created_at=stamp(),selected_topic_ids=v['selected_topic_ids']))
