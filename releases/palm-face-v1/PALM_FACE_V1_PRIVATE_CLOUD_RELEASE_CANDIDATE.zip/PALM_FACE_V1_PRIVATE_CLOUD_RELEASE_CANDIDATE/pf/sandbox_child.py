"""Private pipe protocol. Not an API endpoint; errors are metadata only."""
import base64, json, os, resource, sys

def apply_limits(request):
    memory = int(request['memory_bytes']); cpu = int(request['cpu_seconds'])
    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu + 1))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))

def main():
    request = json.loads(sys.stdin.buffer.read())
    apply_limits(request)
    # Suppress library output; preserve only our dedicated result channel.
    result_fd = os.dup(sys.stdout.fileno())
    with open(os.devnull, 'wb') as sink:
        os.dup2(sink.fileno(), sys.stdout.fileno())
    from .common import Problem
    try:
        data = request['payload']; operation = sys.argv[1]
        if operation == 'normalize':
            from .images import normalize
            normal, canonical, size, transform = normalize(
                base64.b64decode(data['raw'], validate=True), data['mime'], data['mirrored'])
            result = dict(normal=base64.b64encode(normal).decode(),
                          canonical=base64.b64encode(canonical).decode(),
                          size=size, transform=transform)
        elif operation in ('analysis', 'report'):
            from .service import Service
            from .storage import Store
            from .auth import Principal
            svc = Service(Store(data['config']))
            if operation == 'analysis':
                from .cv import analyze
                result = dict(analysis=analyze(svc, None,
                              Principal(data['owner'], frozenset()), data['snapshot']))
            else:
                from .reports import render_pdf
                manifest, pdf = render_pdf(svc, data['snapshot'], data['request'])
                result = dict(manifest=manifest, pdf=base64.b64encode(pdf).decode())
        else:
            raise Problem('INTERNAL_ERROR', 503)
        envelope = {'result': result}
    except Problem as error:
        envelope = dict(error=error.code, status=error.status)
    except Exception:
        envelope = dict(error='INTERNAL_ERROR', status=503)
    with os.fdopen(result_fd, 'wb') as channel:
        channel.write(json.dumps(envelope, allow_nan=False).encode())

if __name__ == '__main__':
    main()
