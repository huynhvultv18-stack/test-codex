import copy,hashlib,json,secrets
from datetime import timedelta
from .common import *
from .contracts import validate
class Service:
    def __init__(self,store,clock=now):self.db,self.clock=store,clock
    def session(self,c,sid,p,active=True):
        s=self.db.get(c,sid,p.owner)
        if not s or self.db.kind(c,sid,p.owner) not in ('session','tombstone'):raise Problem('NOT_FOUND',404)
        if s.get('tombstone'):
            if active:raise Problem('SESSION_EXPIRED',410)
            return s
        if dt(s['view']['expires_at'])<=self.clock():
            self.delete(c,sid,p,expired=True)
            if active:raise Problem('SESSION_EXPIRED',410)
        return s
    def revision(self,s,r):
        if s['view']['session_revision']!=r:raise Problem('REVISION_CONFLICT',409)
        if s['view']['state']=='analyzing':raise Problem('INVALID_STATE',409)
    def save(self,c,s,p):
        validate('SessionView',s['view']);self.db.put(c,s['view']['session_id'],p.owner,'session',s['view']['session_id'],s)
    def invalidate(self,c,s,p,inputs=False):
        sid=s['view']['session_id']
        s['view']['session_revision']+=1;s['view']['review_confirmed_revision']=None
        for row in c.execute("SELECT id FROM objects WHERE sid=%s AND kind IN ('report','grant')",(sid,)).fetchall():
            self.db.erase(sid,row[0]);c.execute('DELETE FROM objects WHERE id=%s',(row[0],))
        if inputs:s['view']['latest_analysis_id']=None;s['annotation']=None;s['derived']=None
        elif s.get('derived'):
            s['view']['state']='review';s['derived']['session_revision']=s['view']['session_revision']
            s['derived']['selected_topic_ids']=s['view']['selected_topic_ids']
    def create(self,c,p,body):
        if not p.ui:raise Problem('CONSENT_REQUIRED',403)
        validate('SessionCreateRequest',body)
        t=self.clock();sid=uid('ses');consent=copy.deepcopy(body['consent']);consent['accepted_at']=stamp(t)
        view=dict(session_id=sid,contract_version='1.0.0',session_revision=1,state='created',profile=body['profile'],consent=consent,images=[],created_at=stamp(t),expires_at=stamp(t+timedelta(hours=24)),selected_topic_ids=[],latest_analysis_id=None,review_confirmed_revision=None)
        s={'view':view,'annotation':None,'derived':None,'machine':None};self.save(c,s,p)
        return view
    def prepare(self,c,p,sid,body,origin):
        validate('UploadPrepareRequest',body);s=self.session(c,sid,p);self.revision(s,body['expected_session_revision'])
        if s['view']['state'] not in ('created','uploading','quality_review','ready','review','completed'):raise Problem('INVALID_STATE',409)
        tid=uid('upl');t=self.clock();exp=min(t+timedelta(minutes=5),dt(s['view']['expires_at']))
        ticket=dict(ticket_id=tid,session_id=sid,slot=body['slot'],upload_path=f'/v1/uploads/{tid}/content',expires_at=stamp(exp),max_bytes=20971520)
        self.db.put(c,tid,p.owner,'upload',sid,{'ticket':ticket,'request':body,'origin':origin,'previous_state':s['view']['state'],'finalized':False})
        s['view']['state']='uploading';self.save(c,s,p);return ticket
    def delete(self,c,sid,p,expired=False):
        s=self.db.get(c,sid,p.owner)
        if not s:raise Problem('NOT_FOUND',404)
        if s.get('tombstone'):return self.db.get(c,s['deletion_id'],p.owner)
        t=self.clock();did=uid('del')
        receipt=dict(deletion_id=did,session_id=sid,state='pending',access_revoked=True,requested_at=stamp(t),purge_deadline=stamp(t+timedelta(hours=24)),completed_at=None,error_code=None)
        c.execute("DELETE FROM objects WHERE sid=%s AND kind='grant'",(sid,))
        for (jid,) in c.execute("SELECT id FROM objects WHERE sid=%s AND kind='job'",(sid,)).fetchall():
            j=self.db.get(c,jid,p.owner);j['view']['state']='cancelled';j['view']['stage']='cancelled';self.db.put(c,jid,p.owner,'job',sid,j)
        c.execute("UPDATE leases SET state='cancelled' WHERE sid=%s",(sid,))
        self.db.put(c,sid,p.owner,'tombstone',sid,dict(tombstone=True,state='expired' if expired else 'deleted',deletion_id=did,retained_until=stamp(t+timedelta(days=30))))
        c.execute("UPDATE objects SET kind='tombstone' WHERE id=%s",(sid,))
        self.db.put(c,did,p.owner,'receipt',sid,receipt)
        # Erase create-session replay containing consent as well as session-specific replays.
        c.execute('DELETE FROM idempotency WHERE owner=%s',(p.owner,))
        return receipt
    def purge(self,c,p,did):
        r=self.db.get(c,did,p.owner)
        if not r:raise Problem('NOT_FOUND',404)
        if r['state']=='completed':return r
        r['state']='running';self.db.put(c,did,p.owner,'receipt',r['session_id'],r)
        try:
            if not self.db.purge(c,r['session_id']):raise OSError()
            r.update(state='completed',completed_at=stamp(self.clock()),error_code=None)
        except OSError:r.update(state='failed',error_code='PURGE_FAILED')
        self.db.put(c,did,p.owner,'receipt',r['session_id'],r);validate('DeletionReceipt',r);return r
