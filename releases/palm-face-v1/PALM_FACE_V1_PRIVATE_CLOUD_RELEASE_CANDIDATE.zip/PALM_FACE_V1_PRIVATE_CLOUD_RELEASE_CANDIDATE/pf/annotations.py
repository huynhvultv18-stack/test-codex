import copy
from .common import *
from .contracts import validate
from .geometry import line_metrics,face_metrics

def patch(svc,c,p,s,b):
    validate('AnnotationPatchRequest',b);svc.revision(s,b['expected_session_revision']);v=s['view'];old=s['annotation']
    if v['state'] not in ('review','completed') or old['annotation_revision']!=b['expected_annotation_revision']:raise Problem('REVISION_CONFLICT',409)
    a=copy.deepcopy(s['derived']);results={x['image_id']:x for x in a['palm_results']+a['face_results']}
    for op in b['operations']:
        r=results.get(op['image_id'])
        if not r:raise Problem('NOT_FOUND',404)
        kind=op['operation']
        if kind=='move_landmark':
            lm=next((x for x in r['landmarks'] if x['id']==op['landmark_id']),None)
            if not lm:raise Problem('NOT_FOUND',404)
            lm.update(point=op['point'],origin='manual',raw_model_score=None);continue
        if 'lines' not in r:raise Problem('VALIDATION_ERROR')
        line=next((x for x in r['lines'] if x['line_id']==op['line_id']),None)
        if kind=='add_line':
            if line or len(r['lines'])>=100:raise Problem('SLOT_CONFLICT',409)
            if any(op['line_id']==x['line_id'] for rr in a['palm_results'] for x in rr['lines']):raise Problem('SLOT_CONFLICT',409)
            r['lines'].append(dict(line_id=op['line_id'],image_id=op['image_id'],origin='manual',status='candidate',conventional_label=op['conventional_label'],polyline=op['polyline'],raw_model_score=None,descriptors=[],uncertainty_reason='Người dùng hiệu chỉnh; không phải ground truth.'))
        elif not line:raise Problem('NOT_FOUND',404)
        elif kind=='delete_line':r['lines'].remove(line)
        elif kind=='replace_line':line.update(polyline=op['polyline'],origin='manual',raw_model_score=None,status='candidate')
        elif kind=='assign_label':line.update(conventional_label=op['conventional_label'],status='candidate')
        elif kind=='confirm_line':line['status']='confirmed'
        elif kind=='reject_line':line['status']='rejected'
    for r in results.values():
        image=next(x for x in v['images'] if x['image_id']==r['image_id'])
        if 'lines' in r:
            for line in r['lines']:line['descriptors']=line_metrics(line,r['landmarks'],image['width'],image['height'])
        else:r['metrics']=face_metrics(r['image_id'],r['landmarks'],image['width'],image['height'],r['slot'],enabled=a['versions']['semantic_map']=='SYNTHETIC-MAP-1',pose_ok=True)
    svc.invalidate(c,s,p);a['session_revision']=v['session_revision'];a['annotation_revision']+=1;a['analysis_id']=uid('ana')
    from .invariants import analysis_invariants
    analysis_invariants(a,v);s['derived']=a;v['latest_analysis_id']=a['analysis_id']
    ann=dict(session_id=v['session_id'],annotation_revision=a['annotation_revision'],base_analysis_id=old['base_analysis_id'],session_revision=v['session_revision'],operations=b['operations'],updated_at=stamp());validate('AnnotationRevision',ann);s['annotation']=ann
    svc.db.put(c,uid('his'),p.owner,'annotation_history',v['session_id'],old)
    svc.db.put(c,a['analysis_id'],p.owner,'analysis',v['session_id'],a);svc.save(c,s,p)
    return ann
