"""PostgreSQL serializable application transactions; encrypted ephemeral payloads."""
import os,json,hashlib,shutil,zlib
from pathlib import Path
from contextlib import contextmanager
import psycopg
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .contracts import ROOT
class Store:
    def __init__(self,config):
        self.compute_config={key:config[key] for key in ('database_url','data_key')}
        self.scanner_socket=config.get('malware_scanner_socket')
        self.url=config['database_url'];self.root=ROOT/'.runtime/data'/hashlib.sha256(self.url.rsplit('/',1)[-1].encode()).hexdigest()[:12];self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.aes=AESGCM(hashlib.sha256(config['data_key'].encode()).digest())
        with psycopg.connect(self.url) as c:
            c.execute('CREATE TABLE IF NOT EXISTS objects(id text primary key, owner text not null, kind text not null, sid text not null, payload bytea not null)')
            c.execute('CREATE TABLE IF NOT EXISTS idempotency(owner text,route text,key text,hash text,response bytea,expires timestamptz,PRIMARY KEY(owner,route,key))')
            c.execute('CREATE TABLE IF NOT EXISTS audit(id bigserial primary key, action text, outcome text, request_id text, created timestamptz DEFAULT now())')
            c.execute('CREATE TABLE IF NOT EXISTS leases(job_id text primary key, owner text,sid text,state text,until_at timestamptz,attempt integer DEFAULT 0)')
    def seal(self,data):
        n=os.urandom(12);return n+self.aes.encrypt(n,zlib.compress(data),None)
    def unseal(self,data):return zlib.decompress(self.aes.decrypt(data[:12],data[12:],None))
    @contextmanager
    def tx(self):
        with psycopg.connect(self.url) as c:
            # Single transaction mutex is intentional for the small MVP; worker compute is outside it.
            c.execute('SELECT pg_advisory_xact_lock(780991)')
            yield c
    def kind(self,c,id,owner):
        row=c.execute('SELECT kind FROM objects WHERE id=%s AND owner=%s',(id,owner)).fetchone()
        return row[0] if row else None
    def get(self,c,id,owner):
        row=c.execute('SELECT payload FROM objects WHERE id=%s AND owner=%s',(id,owner)).fetchone()
        if row is None:return None
        return json.loads(self.unseal(bytes(row[0])))
    def put(self,c,id,owner,kind,sid,data):
        raw=self.seal(json.dumps(data,allow_nan=False).encode())
        c.execute('INSERT INTO objects VALUES(%s,%s,%s,%s,%s) ON CONFLICT(id) DO UPDATE SET payload=EXCLUDED.payload',(id,owner,kind,sid,raw))
    def file(self,sid,asset):
        return self.root/sid/asset
    def write(self,sid,asset,data):
        p=self.file(sid,asset);p.parent.mkdir(mode=0o700,exist_ok=True)
        tmp=p.with_suffix('.tmp');tmp.write_bytes(self.seal(data));tmp.chmod(0o600);tmp.replace(p)
    def read(self,sid,asset): return self.unseal(self.file(sid,asset).read_bytes())
    def erase(self,sid,asset):self.file(sid,asset).unlink(missing_ok=True)
    def purge(self,c,sid):
        shutil.rmtree(self.root/sid,ignore_errors=False) if (self.root/sid).exists() else None
        c.execute("DELETE FROM objects WHERE sid=%s AND kind NOT IN ('tombstone','receipt')",(sid,))
        c.execute('DELETE FROM leases WHERE sid=%s',(sid,))
        # Idempotency encrypted responses contain session payload; remove associated rows.
        c.execute('DELETE FROM idempotency WHERE route LIKE %s',('%'+sid+'%',))
        return not (self.root/sid).exists() and c.execute("SELECT count(*) FROM objects WHERE sid=%s AND kind NOT IN ('tombstone','receipt')",(sid,)).fetchone()[0]==0
