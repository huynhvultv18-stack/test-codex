"""Finite DSL, reviewed immutable templates. No executable source expressions."""
import json,hashlib
from .contracts import ROOT,validate
from .common import Problem

def corpus():
    # No source has completed the owner/reviewer rights and translation gate.
    rule=json.loads((ROOT/'spec/locked/examples/rule_draft.json').read_text())['payload']
    return {'sources':{'sources':[]},'rules':{'rules':[rule]}}

def published_topics():return set()

def approved(rule,sources,template_hashes,snapshots,reviewed_record_hashes=None):
    validate('TraditionalRule',rule)
    if rule['status']!='approved':raise Problem('SOURCE_NOT_APPROVED')
    if hashlib.sha256(rule['template_vi'].encode()).hexdigest() not in template_hashes:raise Problem('POLICY_BLOCKED')
    if len(rule['source_ids'])!=len(rule['source_locators']):raise Problem('SOURCE_NOT_APPROVED')
    for id,locator in zip(rule['source_ids'],rule['source_locators']):
        source=sources.get(id)
        if not source:raise Problem('SOURCE_NOT_APPROVED')
        validate('SourceRecord',source)
        record_digest=hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
        if not reviewed_record_hashes or record_digest not in reviewed_record_hashes:raise Problem('SOURCE_NOT_APPROVED')
        if source['status']!='reviewed' or source['tradition_id']!=rule['tradition_id'] or locator!=source['locator']:raise Problem('SOURCE_NOT_APPROVED')
        data=snapshots.get(id)
        if data is None or hashlib.sha256(data).hexdigest()!=source['snapshot_sha256']:raise Problem('SOURCE_NOT_APPROVED')
    # Only a release reviewer may authorize an EXACT template hash. Keyword scans are insufficient.
    return rule

def evaluate(rules,sources,snapshots,template_hashes,lines,topics,reviewed_record_hashes=None):
    cards=[]
    for rule in sorted(rules,key=lambda r:(r.get('priority',0),r.get('rule_id',''))):
        if rule.get('status')!='approved':continue
        approved(rule,sources,template_hashes,snapshots,reviewed_record_hashes);t=rule['trigger'];refs=[]
        if t['type']=='confirmed_line_label':
            refs=[x['line_id'] for x in lines if x['status']=='confirmed' and x['conventional_label']==t['label']]
            if not refs:continue
        elif t['topic_id'] not in topics:continue
        cards.append(validate('TraditionalCard',dict(card_id='card_'+rule['rule_id'],rule_id=rule['rule_id'],source_ids=rule['source_ids'],source_locators=rule['source_locators'],tradition_id=rule['tradition_id'],category=rule['output_category'],text_vi=rule['template_vi'],scientific_status='not_validated_for_individual_inference',observation_refs=refs)))
    return cards

def fusion(a):
    refs=[];confirmed=0;unknown=0
    for result in a['palm_results']:
        for line in result['lines']:
            if line['status']=='confirmed':refs.append(line['line_id']);confirmed+=1
    for result in a['face_results']:
        for m in result['metrics']:
            if m['status']=='observed':refs.extend(m['evidence_refs'])
            else:unknown+=1
    refs=list(dict.fromkeys(refs))
    summary=f'Có {confirmed} đường nhìn thấy do người dùng xác nhận. Tỷ lệ 2D chỉ lấy từ ảnh chính diện; ảnh góc trái/phải không dùng để đo. Có {unknown} chỉ số chưa quan sát được. Không suy phẩm chất, sức khỏe hoặc vận mệnh.'
    limits=['CV chưa được kiểm chứng trên ảnh người thật; fixture chỉ kiểm hình học.', 'Đường/nếp gấp tự động chưa được đánh giá; dùng hiệu chỉnh assisted.', 'Tư liệu truyền thống chưa có nguồn/rights/bản dịch được người duyệt nghiệm thu.', 'Face truyền thống/Đông Á/Việt Nam: chưa có tư liệu đã duyệt.', 'Tỷ lệ ảnh chiếu 2D phụ thuộc pose, camera, ánh sáng; không đo mm hoặc sắc đẹp.']
    return validate('FusionResult',dict(analysis_id=a['analysis_id'],observation_refs=refs,traditional_cards=[],neutral_summary_vi=summary,limitations=limits,review_confirmed=True,policy_version='PF-POLICY-1.0.0'))
