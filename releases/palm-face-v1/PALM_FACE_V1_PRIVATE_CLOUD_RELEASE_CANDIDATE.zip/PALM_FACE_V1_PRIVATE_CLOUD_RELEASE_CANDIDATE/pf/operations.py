from datetime import timedelta
import copy,json,hashlib
from .common import *
from .contracts import validate

def dispatch(svc,c,p,method,path,b,config,origin):
    db=svc.db;parts=path.split('/')
    def obj(id,kind):
        o=db.get(c,id,p.owner)
        if o is None or db.kind(c,id,p.owner)!=kind:raise Problem('NOT_FOUND',404)
        svc.session(c,o.get('session_id') or o.get('view',{}).get('session_id') or o.get('ticket',{}).get('session_id'),p)
        return o
    if path=='sessions' and method=='POST':return svc.create(c,p,b),201
    if parts[0]=='sessions' and len(parts)>=2:
        sid=parts[1]
        if method=='DELETE' or path.endswith('consent/revoke'):
            validate('DeleteRequest' if method=='DELETE' else 'ConsentRevokeRequest',b);return svc.delete(c,sid,p),202
        s=svc.session(c,sid,p);v=s['view'];tail='/'.join(parts[2:])
        if not tail and method=='GET':return v,200
        if tail in ('profile','topics','consent/preferences') and method in ('PATCH','PUT'):
            name={'profile':'ProfileUpdateRequest','topics':'SelectTopicsRequest','consent/preferences':'ConsentPreferencesRequest'}[tail]
            validate(name,b);svc.revision(s,b['expected_session_revision'])
            if tail=='topics':
                from .knowledge import published_topics
                if set(b['topic_ids'])-published_topics():raise Problem('SOURCE_NOT_APPROVED')
                v['selected_topic_ids']=b['topic_ids']
            elif tail=='profile':v['profile']=b['profile']
            else:v['consent']['include_images_in_pdf']=b['include_images_in_pdf']
            svc.invalidate(c,s,p);svc.save(c,s,p);return v,200
        if tail=='uploads/prepare' and method=='POST':return svc.prepare(c,p,sid,b,origin),201
        if tail=='uploads/finalize' and method=='POST':
            from .images import finalize
            return finalize(svc,c,p,s,b,config),201
        if tail.startswith('images/'):
            iid=parts[3];asset=next((x for x in v['images'] if x['image_id']==iid),None)
            if not asset:raise Problem('NOT_FOUND',404)
            if parts[-1]=='quality' and method=='GET':return asset['quality'],200
            if parts[-1]=='transform' and method=='PUT':
                from .images import transform
                return transform(svc,c,p,s,asset,b,config),200
        if tail=='quality/acknowledge' and method=='POST':
            validate('QualityAcknowledgeRequest',b);svc.revision(s,b['expected_session_revision'])
            lookup={x['image_id']:x for x in v['images']}
            for id in b['image_ids']:
                if id not in lookup:raise Problem('NOT_FOUND',404)
                if lookup[id]['quality']['status'] not in ('review','accept'):raise Problem('QUALITY_BLOCKED')
                lookup[id]['quality']['warnings_acknowledged']=True
            from .images import ready
            ready(s);svc.save(c,s,p);return v,200
        if tail in ('analyses','reports') and method=='POST':
            from .worker import enqueue
            return enqueue(svc,c,p,s,b,'analysis' if tail=='analyses' else 'report'),202
        if tail.startswith('analyses/') and method=='GET':
            a=db.get(c,parts[3],p.owner)
            if not a or a.get('session_id')!=sid or db.kind(c,parts[3],p.owner)!='analysis':raise Problem('NOT_FOUND',404)
            return a,200
        if tail=='annotations':
            if not s['annotation']:raise Problem('INVALID_STATE',409)
            if method=='GET':return s['annotation'],200
            if method=='PATCH':
                from .annotations import patch
                return patch(svc,c,p,s,b),200
        if tail=='review/confirm' and method=='POST':
            validate('ConfirmReviewRequest',b);svc.revision(s,b['expected_session_revision'])
            if v['state']!='review' or s['annotation']['annotation_revision']!=b['expected_annotation_revision']:raise Problem('REVISION_CONFLICT',409)
            v['state']='completed';v['review_confirmed_revision']=v['session_revision'];svc.save(c,s,p)
            return validate('ReviewConfirmation',dict(session_id=sid,session_revision=v['session_revision'],annotation_revision=s['annotation']['annotation_revision'],confirmed_at=stamp())),200
        if tail=='fusion' and method=='GET':
            if v['state']!='completed':raise Problem('INVALID_STATE',409)
            from .knowledge import fusion
            return fusion(s['derived']),200
    if parts[0]=='uploads' and method=='PUT':
        from .images import content
        content(svc,c,p,parts[1],b,origin);return {},204
    if parts[0]=='jobs' and method=='GET':return obj(parts[1],'job')['view'],200
    if parts[0]=='deletions' and method=='GET':
        r=db.get(c,parts[1],p.owner)
        if not r or db.kind(c,parts[1],p.owner)!='receipt':raise Problem('NOT_FOUND',404)
        return r,200
    if parts[0]=='reports' and method=='GET':
        report=obj(parts[1],'report')
        if len(parts)==2:return report,200
        from fastapi.responses import Response
        return Response(db.read(report['session_id'],report['report_id']),media_type='application/pdf'),200
    if path.startswith('knowledge/'):
        from .knowledge import corpus
        return corpus()['sources' if parts[1]=='sources' else 'rules'],200
    if path=='asset-grants' and method=='POST':
        validate('AssetGrantRequest',b);s=svc.session(c,b['session_id'],p)
        report=db.get(c,b['asset_id'],p.owner) if b['scope']=='download_pdf' else None
        valid=b['asset_id'] in [x['image_id'] for x in s['view']['images']] if b['scope']=='preview' else bool(report and report.get('session_id')==b['session_id'] and db.kind(c,b['asset_id'],p.owner)=='report')
        if not valid:raise Problem('NOT_FOUND',404)
        gid=uid('gra');expires=stamp(min(now()+timedelta(minutes=5),dt(s['view']['expires_at'])))
        grant=dict(grant_id=gid,expires_at=expires,asset_path=f'/v1/assets/{gid}/content')
        db.put(c,gid,p.owner,'grant',b['session_id'],dict(**grant,**b,origin=origin));return grant,201
    if parts[0]=='assets' and method=='GET':
        g=db.get(c,parts[1],p.owner)
        if not g or dt(g['expires_at'])<=now() or origin and origin!=g['origin']:raise Problem('NOT_FOUND',404)
        s=svc.session(c,g['session_id'],p)
        from fastapi.responses import Response
        return Response(db.read(g['session_id'],g['asset_id']),media_type='image/png' if g['scope']=='preview' else 'application/pdf'),200
    raise Problem('NOT_FOUND',404)
