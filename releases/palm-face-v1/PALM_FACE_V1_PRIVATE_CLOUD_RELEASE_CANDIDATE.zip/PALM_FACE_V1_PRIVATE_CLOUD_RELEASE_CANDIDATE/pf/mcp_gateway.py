"""Safe fallback registry until app-only/secret channels are verified on the real host."""
from typing import TypedDict
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from starlette.responses import JSONResponse
from .auth import verify
from .common import Problem
class Workspace(TypedDict):
    resource_uri:str
    login_required:bool
    host_integration:str
    personal_data_enabled:bool

def gateway(config):
    m=FastMCP('Palm & Face V1 candidate',streamable_http_path='/',stateless_http=True,json_response=True,log_level='ERROR',max_request_body_size=2097152)
    @m.tool(annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,idempotentHint=True,openWorldHint=False),structured_output=True)
    def pf_open_workspace()->Workspace:
        """Open login instructions. Does not create a session or provide consent."""
        return {'resource_uri':'ui://pf/workspace','login_required':True,'host_integration':'BLOCKED','personal_data_enabled':False}
    @m.resource('ui://pf/workspace',name='Private standalone UI login guide',mime_type='text/plain')
    def workspace()->str:
        return 'Private standalone reviewer UI requires separate login. Target hosting/IdP and host MCP Apps capabilities have not been configured. Local candidate accepts synthetic fixtures only. No chat attachment bridge or secret bootstrap channel is enabled.'
    app=m.streamable_http_app()
    class Authenticated:
        async def __call__(self,scope,receive,send):
            if scope['type']!='http':return await app(scope,receive,send)
            headers=dict(scope.get('headers',[]));token=headers.get(b'authorization',b'').decode().removeprefix('Bearer ')
            try:
                p=verify(token,config)
                if 'pf:read' not in p.scopes:raise Problem('FORBIDDEN',403)
            except Problem as e:
                r=JSONResponse({'error':'invalid_token' if e.status==401 else 'insufficient_scope'},status_code=e.status,headers={'WWW-Authenticate':'Bearer resource_metadata="'+config['origin']+'/.well-known/oauth-protected-resource"','Cache-Control':'no-store'})
                return await r(scope,receive,send)
            return await app(scope,receive,send)
    return m,Authenticated()
