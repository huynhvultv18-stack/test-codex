"""The frozen schema is authoritative. Additional service checks never rewrite it."""
import json, math
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
ROOT=Path(__file__).resolve().parent.parent
SCHEMA=json.loads((ROOT/'spec/locked/DATA_CONTRACT.json').read_text())
Draft202012Validator.check_schema(SCHEMA)

def finite(value):
    if isinstance(value,float) and not math.isfinite(value): raise ValueError('Non-finite number')
    if isinstance(value,dict):
        for x in value.values(): finite(x)
    if isinstance(value,list):
        for x in value: finite(x)

def validate(name,value):
    finite(value)
    schema={'$schema':SCHEMA['$schema'],'$defs':SCHEMA['$defs'],'$ref':'#/$defs/'+name}
    Draft202012Validator(schema,format_checker=FormatChecker()).validate(value)
    return value

def loads(raw):
    result=json.loads(raw,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Non-finite JSON')))
    finite(result)
    return result
