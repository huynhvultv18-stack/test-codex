"""Pixel-space formulas; no anatomy, identity, beauty or predictive assessments."""
import math
from .contracts import validate
from .common import Problem
FACE={'face_height_width_ratio':('face_hw_v1',(10,152)), 'intercanthal_face_width_ratio':('face_intercanthal_v1',(133,362)), 'mouth_face_width_ratio':('face_mouth_width_v1',(61,291)), 'nose_face_width_ratio':('face_nose_width_v1',(98,327)), 'left_right_contour_asymmetry_2d':('face_asymmetry_2d_v1',(234,454,10,152))}
def pixel(point,w,h):return (point['x']*(w-1),point['y']*(h-1))
def distance(a,b,w,h):return math.dist(pixel(a,w,h),pixel(b,w,h))
def metric(id,image,formula,value,refs,origin='automatic',reason=None,unit='ratio'):
    return validate('Metric',dict(metric_id=id,image_id=image,status='observed' if value is not None else 'not_observable',value=value,unit=unit,formula_id=formula,evidence_refs=refs,origin=origin,uncertainty_reason=reason))
def face_metrics(image,points,w,h,slot='face_front',enabled=False,pose_ok=False):
    if slot!='face_front':return []
    out=[];lookup={int(p['id'].rsplit('_',1)[-1]):p for p in points}
    for name,(formula,indices) in FACE.items():
        value=None;refs=[];reason='Semantic mapping/pose chưa được xác minh; không đủ dữ liệu.'
        used=tuple(dict.fromkeys((*indices,234,454)))
        if enabled and pose_ok and all(i in lookup for i in used):
            p=lambda i:lookup[i]['point'];den=distance(p(234),p(454),w,h)
            refs=[lookup[i]['id'] for i in used]
            if den<=1:reason='Mẫu số không vượt 1 pixel.'
            else:
                if name=='left_right_contour_asymmetry_2d':
                    mid={k:(p(10)[k]+p(152)[k])/2 for k in ('x','y')}
                    value=abs(distance(p(234),mid,w,h)-distance(p(454),mid,w,h))/den
                else:value=distance(p(indices[0]),p(indices[1]),w,h)/den
                reason='Tỷ lệ ảnh chiếu 2D, chưa có sai số đo thực nghiệm.'
        origin='mixed' if any(lookup[i]['origin']=='manual' for i in used if i in lookup) else 'automatic'
        out.append(metric(name,image,formula,value,refs,origin,reason))
    return out

def line_metrics(line,landmarks,w,h):
    pts=line['polyline'];arc=sum(distance(a,b,w,h) for a,b in zip(pts,pts[1:]));chord=distance(pts[0],pts[-1],w,h)
    lookup={int(p['id'].rsplit('_',1)[-1]):p for p in landmarks};den=distance(lookup[5]['point'],lookup[17]['point'],w,h) if 5 in lookup and 17 in lookup else None
    confirmed=line['status']=='confirmed';id=line['image_id'];origin=line['origin'];refs=[line['line_id']]
    return [metric('line_length_palm_width_ratio',id,'palm_arc_width_v1',arc/den if confirmed and den and den>1 else None,refs+[lookup[i]['id'] for i in (5,17) if i in lookup],origin,'Độ dài đường trong ảnh; reference MCP có thể chưa đủ.'),metric('line_straightness_ratio',id,'palm_chord_arc_v1',chord/arc if confirmed and arc>1 else None,refs,origin,'Đường cần được xác nhận, độ dài phải vượt 1 pixel.'),metric('line_visible_branch_count',id,'palm_branch_count_v1',None,refs,origin,'Graph nhánh chưa được review; không suy từ giao cắt.',unit='count')]

def adapt(points,count,image,origin='automatic'):
    if len(points)!=count:raise Problem('MODEL_MISMATCH',503)
    out=[]
    for i,p in enumerate(points):
        raw={'id':image+'_lm_'+str(i),'point':dict(x=float(p[0]),y=float(p[1])),'origin':origin,'raw_model_score':None}
        validate('Landmark',raw);out.append(raw)
    assert len({p['id'] for p in out})==count
    return out
