"""Local ClamAV INSTREAM adapter. No upload to an external scanning service."""
import socket, struct
from .common import Problem

def scan(raw, socket_path, *, timeout=5):
    if not isinstance(socket_path,str) or not socket_path.startswith('/'):
        raise Problem('POLICY_BLOCKED',403)
    try:
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as client:
            client.settimeout(timeout);client.connect(socket_path)
            client.sendall(b'zINSTREAM\x00')
            for start in range(0,len(raw),65536):
                chunk=raw[start:start+65536]
                client.sendall(struct.pack('!I',len(chunk))+chunk)
            client.sendall(struct.pack('!I',0));response=b''
            while not response.endswith(b'\x00'):
                part=client.recv(256)
                if not part or len(response)+len(part)>1024:
                    raise Problem('POLICY_BLOCKED',403)
                response+=part
            if response!=b'stream: OK\x00':
                raise Problem('POLICY_BLOCKED',403)
    except (OSError,ValueError):
        raise Problem('POLICY_BLOCKED',403)
