# CV blocked gates

T13–T16: real hand-side/palm-back/object-count, blur/glare/lighting/occlusion/pose/ROI and ambiguous creases uncalibrated. T19–T24: real model/semantic map/front pose/index/roll/oblique evidence missing. T25/T26: holdout NME/coverage/creaseF1 NOT MEASURED. T50 real five-photo journey not run. T51 model license/hash evidence absent.

Completed: bounded decode, JPEG/PNG/staticWebP/magic/size/pixels/EXIF/mirror; finite and pixel arithmetic; assisted manual operations and immutable baseline; isolated synthetic compute. Remaining supplier: model rights/evaluation reviewer and dataset owner. Next: provide approved model/data, freeze config and execute locked TEST_PLAN; keep ASSISTED and no real uploads until rights/consent/security gates are fulfilled.
