# Điều kiện từ Owner / hệ thống ngoài

| Dependency | Trạng thái / bên cung cấp | Thao tác tiếp theo |
|---|---|---|
| Provider, region, budget, deploy permission, ChatGPT workspace/admin | Owner xác nhận CHƯA CÓ trong phiên này | Chọn target có retention phù hợp, ngân sách và quyền rõ; supply credential bảo mật; không mua/deploy tự động |
| IdP/OAuth client/login/linking/TLS/DNS | Owner + IdP/admin; chưa cấu hình | Chốt issuer/audience/JWKS/callback/scopes, account link và ACL, chạy cloud auth smoke |
| Storage no backup/versioning/soft-delete and region evidence | Provider/operator; chưa có target | Cung cấp policy live và kiểm purge inventories/deadline/outage |
| Model binaries/licenses/semantic QA | Model rights reviewer/operator; chưa cung cấp | Pin asset version+SHA256+license evidence, verify21/478/hand-side/front semantics trước enable |
| Consented licensed independent real-image holdout | Dataset owner/evaluation reviewer; chưa cung cấp trong phiên này | Duyệt protocol/consent/retention, 60 adults or equivalent rights-cleared data, split20/40, adjudication; không gửi ảnh tới external AI |
| Source rights/edition/locator/snapshot/translation/content reviewer | Owner/appointed reviewer; chưa cung cấp | Hoàn tất queue; chỉ glossary/context được phép; không đánh giá phẩm chất/sức khỏe/tương lai theo ảnh |
| Live malware scanner and resource/network sandbox | Security/operator; chưa nghiệm thu | Cài trong infrastructure được phép; verify signature freshness, no external upload, cgroup and denied network |
| SCR-001 committed slot deletion | Owner/API contract authority; chưa approved | Đánh giá replacement/full-session delete; nếu cần slot delete thì phiên bản mới trước implement |

Thiếu external dependency không được suy thành PASS. Công việc độc lập đã tiếp tục; FINAL_STATUS.json và gate CSV là điểm bàn giao. Không yêu cầu secret values trong chat.
