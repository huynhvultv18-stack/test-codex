# CV validation

P1 CV = BLOCKED; CV MODE = ASSISTED; auto_line_status = not_validated.

Có Palm adapter21 / Face adapter478, đúng count/namespace/slot checks, canonical EXIF/mirror, non-square geometry, front-only ratios, null denominator và manual score=null. Crease Meijering/skeleton chỉ là candidate, không tự confirm. Bản vá chặn kind/hash model input sai và decode chạy process giới hạn. Chỉ exact synthetic fixture hash được upload; mode production bị khóa.

Không có model binary/hash/license đã review, semantic map/handedness/palm-versus-back/pose thật, photometric ROI calibration, real-image holdout hay reviewer. Không chạy precision/recall/NME/F1 trên ảnh người; các trị số đó NOT MEASURED. Missing/unknown/count/wrong-slot tests không được đổi thành CV accuracy. Glare/occlusion/shadow/back-of-hand và model failures giữ blocker, không thêm threshold giả.

Evidence: tests/test_phase3.py, tests/test_journey.py, tests/test_release_security.py; release-regression.xml; MODEL_REGISTER.md và DATASET_REQUIREMENTS.md. UI vẽ tay/confirm được kiểm synthetic trên Chromium thật. ASSISTED chỉ nghĩa cơ chế chỉnh sửa local; không công nhận dịch vụ trên ảnh người thật.
