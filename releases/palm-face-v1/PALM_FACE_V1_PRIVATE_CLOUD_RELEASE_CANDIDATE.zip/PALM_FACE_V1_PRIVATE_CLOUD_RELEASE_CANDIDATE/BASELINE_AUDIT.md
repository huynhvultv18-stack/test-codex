# Baseline audit — 12/10/2026

BASELINE INTEGRITY = PASS. Hai ZIP đầu vào còn nguyên. SHA-256 của cả hai ZIP và yêu cầu đã dán nằm trong BASELINE_CHECKSUMS.sha256. Đã kiểm CRC và toàn bộ 122 checksum Candidate, 18 checksum SPEC LOCK. spec/locked trùng từng byte với bản SPEC LOCK riêng. Repository test-codex không được sửa.

Đã chạy lại baseline: 62 pytest PASS, 0 failed/errors/skips (evidence/baseline-rerun.xml và baseline-pytest.txt). Chromium 154 chạy desktop 1440x1000/mobile 320px với 5 ảnh synthetic, annotation, review, PDF, reload và deletion; không page error (evidence/baseline-rerun-browser.json). MCP SDK Streamable HTTP initialize/list/call/resources được chạy lại (evidence/baseline-rerun-mcp-local.json). Các bằng chứng gốc được giữ trong evidence/baseline-history; không xem chúng là nghiệm thu bản vá mới.

Python 3.12.14, 62 dependency được cài bằng --require-hashes từ lock gốc, pip check đạt. PostgreSQL Docker theo digest khóa, RAM-backed PGDATA, chỉ loopback, đã khởi động và sử dụng thật. Chỉ dữ liệu synthetic có trong ZIP được dùng; không ảnh cá nhân, external AI, paid deployment hay Plugin publication.

Khoảng trống phát hiện: worker chỉ kiểm elapsed time sau compute; decoder chạy trong request/transaction; worker cũ chưa bị chặn theo lease attempt; PNG thiếu IEND chưa bị kiểm rõ; raw bị reject chưa được xóa ngay. Bản làm việc riêng bổ sung sửa đổi và kiểm thử cho các vấn đề này. P0/P1 tổng thể vẫn phụ thuộc cloud/IdP/host, model/holdout, source/human review và SCR-001. BLOCKED_GATE_MATRIX.csv ghi từng T01–T52, requirement, evidence, local result và dependency; test count không đồng nghĩa số gate đã đóng.
