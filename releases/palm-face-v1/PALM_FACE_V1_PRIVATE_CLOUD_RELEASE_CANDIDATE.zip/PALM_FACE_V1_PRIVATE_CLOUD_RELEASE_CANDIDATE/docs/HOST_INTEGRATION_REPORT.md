# Current release

See ../MCP_INTEGRATION_REPORT.md, ../PRIVACY_DELETION_REPORT.md and ../DEPLOYMENT_PLAN.md. Earlier Candidate report is preserved in baseline-history/HOST_INTEGRATION_REPORT.md.
