# Current evidence index

- Baseline: baseline-rerun.xml / baseline-pytest.txt / baseline-rerun-browser.json / baseline-rerun-mcp-local.json; input SHA files and integrity-final.json.
- Final: release-regression.xml and release-pytest.txt —78passed/0failed/errors/skips; all16new cases included. security-initial/security-regression/decode-fence XML are intermediate, not the final count.
- Host local: mcp-local.json; browser.json/ui-desktop.png/ui-mobile.png and release-browser.txt — actual current loopback transport/Chromium, synthetic only.
- PDF: synthetic-report.pdf / release-pdf-text.txt / release-pdf-page-*.png / release-pdf-contact.png —7current pages. Older pdf-page-*.png/contact under baseline-history are historical.
- Performance: performance.json/release-benchmark.txt — current pfsource hashes,100analysis+100PDF, no errors; PERFORMANCE_ACCEPTANCE.md defines limitations. before-final-decode-fence files are historical.
- Dependencies: install-release.txt/install-repeat.txt/pip-check.txt/dependency-parity.json/browser-install.txt/SBOM_RELEASE.json; LICENSE_REGISTER.md.
- Privacy/integrity: secret-scan.json, integrity-final.json, VERSION_FREEZE.json, CHECKSUMS.txt and BASELINE_CHECKSUMS.sha256. Secret check is scoped, not external credential/legal certification.
- Original documents/evidence preserved under docs/baseline-history and evidence/baseline-history. No mocked host screenshot or measured real-person CV acceptance exists.
