# Current release

See ../RUNTIME_SECURITY_REPORT.md, ../PRIVACY_DELETION_REPORT.md and ../DEPLOYMENT_PLAN.md. Earlier Candidate report is preserved in baseline-history/OPERATIONS.md.
