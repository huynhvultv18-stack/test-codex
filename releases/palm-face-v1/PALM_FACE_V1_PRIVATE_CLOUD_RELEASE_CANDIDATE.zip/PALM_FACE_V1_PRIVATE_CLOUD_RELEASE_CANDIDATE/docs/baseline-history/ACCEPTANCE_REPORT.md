# PALM & FACE V1 candidate acceptance

| Required final status | Result |
|---|---|
| PHASE2 | BLOCKED |
| PHASE3 | BLOCKED |
| PHASE4 | BLOCKED |
| PHASE5 | BLOCKED |
| PHASE6 | BLOCKED |
| HOST INTEGRATION | BLOCKED |
| CV MODE | ASSISTED |
| PRODUCTION READY | NO |

These are whole-phase gates. Independent work in all five phases was implemented and tested; they do not imply that local code failed. Owner confirmed no target hosting/IdP/host, licensed CV dataset or source reviewer exists. Pending conditions are not counted as PASS.

## Verified local evidence

62 current pytest cases pass with zero failures/errors/skips: evidence/final-regression.xml. They exercise schema/format/finite input, synthetic decoder/geometry/counts, API ownership/UI consent/replay/revisions, immutable machine/manual data, source/DSL guards, Vietnamese PDF, grant/expiry/purge/deletion fences, concurrency/leases/backpressure, production-start denial and actual local MCP protocol. Earlier XML files are historical. Test count is not52 closed release gates; see TEST_MATRIX.md.

Actual Chromium154 UI passes desktop and320px with zero page errors: five synthetic uploads, consent, analysis, coordinate/manual save/confirm, reload, locally bundled PDF.js preview/page navigation/download, completed deletion receipt. Screenshots are runtime synthetic diagrams, not real photos/mockups. The current sample PDF is7 A4 pages, embedded licensed font, selectable Vietnamese, vector overlays by default and revision/evidence/formula IDs. Every page was rasterized and inspected after pagination/aspect repair.

Fresh Python3.12 virtualenv installation from62 hash-locked wheels/imports was executed. Package lock, wheel checksums, SDK versions/SBOM, Docker digest, font/PDF.js licenses and npm integrity are included. Real MediaPipe files/rights are unavailable: models/REGISTER.json has null hashes/PENDING, not invented asset evidence.

100analysis+100PDF actual local worker jobs were measured. Current timings, p95/median/max, queue exclusion, source hashes, errors and peak process memory: evidence/performance.json. The host exposes5 CPUs, is not the locked4vCPU8GiB reference, and1 active job was measured. Max2 claims is separately tested. Data is synthetic, not participant holdout. Performance/CV production gates stay BLOCKED. Initial512MiB RAM-backed DB OOM was fixed with compressed encryption/2GiB cap/1GiB tmpfs/reduced WAL. Synthetic dev keys exposed by the diagnostic traceback were rotated; raw failing log is omitted, and load-initial-failure.json preserves a redacted diagnosis.

## Unresolved P0/P1 release prerequisites

- P0 deployment: actual IdP/OAuth2.1/PKCE/browser login/account linking; host ACL/TLS; provider/region/budget; storage no-backup/versioning/soft-delete and consent/provider review. Dev IdP is synthetic-only; production startup is disabled.
- P1 CV: official pinned model assets/rights, real semantic map/pose/ROI QC/glare/occlusion/palm-side calibration and licensed/consented independent holdout. auto_line_status=not_validated. No accuracy claim on people.
- P1 content: reviewed source edition/locator/snapshot/rights/translation and appointed human semantic reviewer. Active corpus is empty; Cheiro remains candidate metadata; Lavater/Asian/Vietnamese inactive. No personalized trait/health/fate/beauty rules execute.
- P1 runtime: actual host UI/secret/app-only/capability and authenticated HTTPS fallback; malware/decode/process sandbox; forced timeouts/resource limits; provider/outage/deadline/privacy/load/monitoring acceptance. Local worker checks elapsed timeout before commit; production process termination is not accepted.
- P1 contract: finalized slot-delete has no locked request/route; SCR-001 is proposed, unapproved. Replacement and full-session delete work without changing spec.

No Production promotion, paid provisioning, Plugin installation/publication, photo recruitment/processing or external LLM call occurred. No external credentials were requested. Network domains were saved only as environment draft additions; saving does not apply policy/publish. Existing test-codex repository remains unchanged.

## Owner actions

Review candidate and blocked gates. Before real deployment supply an authorized private target/provider/region/budget/IdP, enable required destinations, appoint rights/content/translation reviewers, authorize the participant protocol and resolve SCR-001 in a new reviewed version. Supply credentials securely through settings, not chat. Re-run affected acceptance and close every P0/P1 gate before Production Ready YES.
