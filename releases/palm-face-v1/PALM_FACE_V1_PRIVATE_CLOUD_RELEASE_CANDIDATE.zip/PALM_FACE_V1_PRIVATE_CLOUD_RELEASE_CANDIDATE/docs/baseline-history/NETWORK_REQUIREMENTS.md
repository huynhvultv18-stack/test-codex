# Network draft persistence
Official document/model/source requests returned proxy CONNECT403. These custom domains were saved to the known-empty custom allowlist, preserving package-manager presets:
- developers.openai.com
- apps.extensions.modelcontextprotocol.io
- py.sdk.modelcontextprotocol.io
- developers.google.com
- storage.googleapis.com
- www.gutenberg.org
- www.loc.gov
Draft saving does not apply runtime networking or publish. Review/save the environment settings and use the product publication flow if those destinations are needed; then retry the affected operations. No model/source download success is claimed. No secret binding is requested because no hosting/IdP service exists yet.
