# Locked T01–T52 coverage (local evidence versus actual acceptance)
A passing pytest case is not a fully closed release gate. XML contains parameterized local test counts; BLOCKED/PARTIAL below remain open. Only synthetic geometry/fixtures and dev identities were used.

| IDs | Local executed coverage | Remaining gate |
|---|---|---|
|T01–T02|Draft2020-12 fixtures, strict fields, format, finite floats, point/count/oblique failures, runtime reference invariants|PASS local; API definitions use unchanged schema|
|T03|UI-only consent, origin/CSRF, false attestations, server timestamps|Real IdP/UI consent deployment BLOCKED|
|T04|Missing five slots rejected, exact five-slot full journey, typed enums and slot replacement|Real-image operation BLOCKED|
|T05|Signed dev JWT issuer/audience/expiry/scope, HTTP challenge|Actual OIDC/OAuth2.1/PKCE/account linking BLOCKED|
|T06|Cross-owner session/image/analysis/annotation/grant objects rejected; kind-confusion routes rejected|Provider/private-host smoke BLOCKED|
|T07–T08|Replay returns same response, changed body409, stale annotations409, serialized revisions|PASS local|
|T09|Absolute24h, ≤5min grants, expired grant, immediate raw removal, receipt retention logic|Provider lifecycle/worker outage acceptance BLOCKED|
|T10–T12|JPEG/PNG/staticWebP, animated PNG/WebP, MIME mismatch, appended payload, >20MiB/>24MP, EXIF6+mirror reprojection/idempotence|Malware/sandbox/decode hard resource bound BLOCKED|
|T13–T15|Synthetic wrong-slot/multiple-object rejection, unknown quality fatal, count21/mirror metadata|Real detector, palm-versus-back, ROI photometry/pose/occlusion calibration BLOCKED|
|T16|Classic ridge/skeleton candidates and unknown topology, no invented score|False-line/unclear detection evaluation BLOCKED|
|T17–T18|Add/replace/delete/label/confirm/reject, preserved machine baseline, manual score null, descriptors refresh|PASS local; manual on real photos remains untested|
|T19–T20|21/478 mismatch and unique/namespace/reference checks; semantic formula fixtures|Real model asset/semantic-map QA BLOCKED|
|T21–T24|Oblique metrics[], pose/semantics-disabled nulls, no hairline/thirds, non-square pixel formulas, mirror/scale, denominator≤1px|Real pose/occlusion/roll evaluation BLOCKED|
|T25–T26|No claimed CV metrics; assisted fallback|BLOCKED: no licensed/consented participant holdout/model assets|
|T27–T30|Draft disabled, finite DSL/expression rejection, exact template/record/snapshot/edition/locator/tradition freeze, synthetic reviewed-card trace|Production source/rights/translation/human semantic review BLOCKED|
|T31–T34|Direct/indirect unsafe template rejection by allowlist, neutral fusion, missing-source separation, current evidence references|Active traditional corpus and human semantic acceptance BLOCKED|
|T35–T37|Unicode/selectable text, embedded licensed font, vector default, consent mismatch, actual hash/pages/bytes, full page raster QA and PDF.js page navigation|PDF cap guards implemented; extreme10page/15MiB and font-failure operational cases not fully executed|
|T38–T40|Actual SDK StreamableHTTP initialize/list/call/resources/output schema and safe projection; only open-workspace fallback|Real host, app-only visibility, secret/CSP/picker/attachment bridge BLOCKED|
|T41–T43|Chromium desktop320px, five files, coordinates/manual save/review, reload terminal state, PDF preview/download/delete; revision conflict and old-report invalidation|Keyboard/zoom/pointer primitives exist; reconnect mid-job and all mobile/pointer variants partial; finalized slot delete needs SCR-001|
|T44|Delete during upload/analysis/PDF, before-commit fences, revoke existing grant|PASS local; real deployment smoke BLOCKED|
|T45–T47|Absolute TTL tombstone/purge, stale orphan directory scan, inventory/failed purge/retry, encrypted files/DB bytes, minimal audit schema|Provider no-backup/versioning/storage region, outage/deadline and metadata alerts BLOCKED|
|T48|Lease crash retries once, terminal failure, max2 claimed jobs,10rps backpressure|Queue cap20 in code; forced process timeout/hard memory bounds/deployed overload remain BLOCKED|
|T49|100 analysis+100 PDF actual local jobs; queue excluded; process peak memory and machine recorded|Reference4vCPU8GiB, max2 parallel measurement and approved real CV data BLOCKED|
|T50|Synthetic five-image API/browser journey through review/export/delete|Approved real evaluation journey BLOCKED|
|T51|Fresh hash-locked wheel install/imports, SDK versions/SBOM, font/PDF.js license, archive/spec hashes|Model/corpus rights/hash assets absent; complete release license gate BLOCKED|
|T52|Inactive corpus, finite approved-template mechanism, no forbidden inference fields, safe MCP projection, no image input to LLM|Production private ACL and human content review BLOCKED|

No mock screenshot is used for host acceptance. No CV accuracy target or scientific palmistry/physiognomy validation is declared PASS. Detailed unresolved P0/P1 prerequisites are in ACCEPTANCE_REPORT.md.
