# SCR-001 — clarification required; frozen spec unchanged
Status: PROPOSED / NOT APPROVED. Candidate does not alter PF-SPEC-1.0.0 or DATA_CONTRACT.json.
MODULE_DESIGN §7 asks for slot deletion, but API_SPEC defines slot replacement, transform and entire-session deletion only. No locked request/route represents deletion of a finalized image slot. A client-side clear of an unsubmitted file is possible; deleting a committed slot cannot be silently invented as an API contract extension.
Owner review should define an explicit slot-delete request with expected session/image revision, invalidation, tombstone of old image and transition to quality_review. This would require a new reviewed API/spec version before implementation. Current UI supports replacement and complete session deletion; committed single-slot deletion remains BLOCKED.
No defaults for slot count, TTL, policy, consent, model inputs or auth are changed. This clarification gate is recorded in Phase 5/6 limitations.
