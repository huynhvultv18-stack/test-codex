# Current release changelog

See ../CHANGELOG_RELEASE.md. Original Candidate changelog is preserved in baseline-history/CHANGELOG.md.
