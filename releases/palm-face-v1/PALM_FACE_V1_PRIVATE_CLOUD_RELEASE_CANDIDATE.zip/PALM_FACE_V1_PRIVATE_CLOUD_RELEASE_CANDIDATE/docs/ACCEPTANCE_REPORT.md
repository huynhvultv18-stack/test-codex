# Current release acceptance

See ../RELEASE_READINESS_REPORT.md, ../FINAL_STATUS.json and ../BLOCKED_GATE_MATRIX.csv. Baseline-only acceptance is preserved in baseline-history/ACCEPTANCE_REPORT.md.
