# Contract compatibility

Locked SPEC/API/DATA_CONTRACT and example fixtures remain byte-identical to the supplied SPEC LOCK, verified initially and again at packaging. Business route names, enum/field/schema, five slots, TTL, consent and policy stay1.0.0. No new committed-slot-delete endpoint, production bypass, model-readable private tools or public grants.

Current regression validates schema/finite floats/references/ownership/revision/EXIF/metric formula/MCP projection. Internal process/lease/decoder/scanner changes preserve API outputs; opaque generated IDs and current source hashes are expected to differ. VERSION_FREEZE marks current source and runtime changes; original freeze/evidence remain recoverable from original ZIP and history. P1 contract release gate remains BLOCKED solely for unresolved SCR-001 policy/API decision; local compatibility checks PASS.
