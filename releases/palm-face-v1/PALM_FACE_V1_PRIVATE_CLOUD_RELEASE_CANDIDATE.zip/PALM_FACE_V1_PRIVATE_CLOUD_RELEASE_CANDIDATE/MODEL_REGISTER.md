# Model register

| Model/algorithm | Version | Checksum/asset | Rights / acceptance |
|---|---|---|---|
| MediaPipe SDK |1.1.0| Hash lock wheel requirements.hashed.lock; fresh installed | SDK metadata in SBOM; not model binary rights |
| Hand Landmarker | Official float16/1 URL in models/REGISTER.json | ABSENT, SHA256=null | PENDING; no model inference or side/palm validation |
| Face Landmarker | Official float16/1 URL in models/REGISTER.json | ABSENT, SHA256=null | PENDING;478 semantic map not approved; no identity embeddings |
| Crease | PF-CREASE-CANDIDATE-1 | Source hash in VERSION_FREEZE.json | Classical ridge candidate, auto_line_status=not_validated |
| Synthetic adapter | SYNTHETIC-FIXTURE-NOT-MODEL | Fixture registry hashes | Diagram mechanics only; no accuracy claim |

Before activation: verify downloaded assets from authoritative authenticated TLS source, retain verified publisher/hash/version/URL/license text and appointed reviewer/date; map semantic indices with overlays; test count/pose/palm-side and fail closed on mismatch. Do not invent hashes from an expected URL, activate rights-pending binaries, or treat SDK license as model license. No new model was downloaded/activated in this run.
