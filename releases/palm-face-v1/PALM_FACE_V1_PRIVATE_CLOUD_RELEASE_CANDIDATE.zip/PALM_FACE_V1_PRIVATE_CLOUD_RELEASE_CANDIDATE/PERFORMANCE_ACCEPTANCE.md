# Performance acceptance — current source

100analysis+100PDF jobs completed through actual PostgreSQL and isolated child workers; errors=0. Queue excluded. Source hashes in evidence/performance.json match every current pf/*.py file. Evidence/release-benchmark.txt preserves runner output and final exit result.

| Kind | Jobs | Median seconds | p95 seconds | Max seconds |
|---|---:|---:|---:|---:|
| Analysis |100|1.967982|2.114771|2.159087|
| PDF |100|0.587895|0.705207|0.827118|

Parent peak RSS=176652KiB; largest completed child peak RSS=209280KiB. These are process peaks, not aggregate concurrent RSS. Host reports5CPUs and cgroup memory.max32GiB, not locked4vCPU8GiB. One active job measured; runtime maintenance executor remains one-at-a-time. Max2claims and actual queue20/21st429 are tested separately. Child AS limit2GiB, CPU/wall limits are real process controls, not a production cgroup acceptance.

Data is synthetic diagrams. Targets p95analysis60s/PDF20s are numerically met for this local fixture/run only; real CV/model/holdout throughput, max2parallel reference-machine load and provider failure/recovery are NOT MEASURED. T49 and deployment performance gate remain BLOCKED. Older performance.json files under baseline-history and performance-before-final-decode-fence.json are historical; do not substitute them for this run.
