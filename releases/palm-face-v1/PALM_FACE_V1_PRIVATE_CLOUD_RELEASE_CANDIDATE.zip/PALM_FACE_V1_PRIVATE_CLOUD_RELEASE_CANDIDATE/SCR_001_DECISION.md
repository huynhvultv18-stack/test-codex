# SCR-001 decision — PROPOSED, NOT APPROVED

P1 CONTRACT = BLOCKED for committed single-slot removal requirement. API_SPEC freezes replacement and whole-session DELETE/revoke, but no committed-slot-delete route/request; MODULE_DESIGN requests slot deletion. No route/schema/new default introduced. Replacement/full-session deletion remain tested compatible alternatives; unsubmitted file clear is client-only.

Replacement fulfills correcting a slot and retires old image/invalidates downstream; it does not fulfill deleting only a committed slot while retaining other four. Whole-session delete fulfills complete removal and invalidates all slots; it does not preserve the other four. This functional difference is not silently waived.

If Owner decides true single-slot deletion is mandatory, approve a new spec/API version defining route, expected session+image revision, owner/UI/CSRF, tombstone/revoke grants, cancel jobs, raw/canonical/normalized/report inventory, return quality_review with fewer than5slots, evidence invalidation and idempotent replay. Add stale/cross-owner/delete-during-job tests and UI behavior; bump contract/schema/version, migration and backward compatibility review. Implementation awaits explicit approval of that version. Until then preserve locked1.0.0 and BLOCKED.
