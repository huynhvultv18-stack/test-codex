# Security acceptance

Local regression và process tests có evidence/release-regression.xml, evidence/security-regression.xml; gate cloud/host vẫn BLOCKED. Không có chứng nhận security/compliance.

| Control | Local evidence | Required production evidence |
|---|---|---|
| Ownership/scope/consent/CSRF/replay/revision | tests T03/T05–T08/T43/T44, PostgreSQL thật | IdP+TLS+owner ACL và hai tenant thật |
| Decoder/process timeout/CPU/RAM | test_release_security real process kill/CPU/64MiB failure; runtime child cap2GiB | Cgroup, no swap, pid/queue caps, no network/filesystem escape và deployed stress |
| Malware scanner | Local Unix INSTREAM adapter; clean/found/error/unavailable protocol test double | Live ClamAV engine/signature hash/date, EICAR+clean PNG/JPEG/WebP, outdated/signature failure and quarantine cases |
| No private data in MCP | SDK initialize/list/call/resource safe fallback | Real ChatGPT host/capabilities/CSP/account linking |
| Deletion/expiry/grants/inventory | Tests T09/T44–T47; raw failure cleanup and no stale lease commit | Provider backup/versioning/soft-delete disabled; outage/deadline/inventory/alerts |
| No personal inference | Active corpus empty; finite schema/exact-template controls | Appointed semantic/translation/rights reviewer; source release and adversarial acceptance |

Mọi evidence có scope local/synthetic; test double scanner không là proof malware protection. Process-limit tests thực sự kill/allocate/spin, không sleep mock thay kiểm timeout. Synthetic labels không chứng minh CV trên người. Sources không active, không tự bổ nhiệm reviewer. Production startup vẫn bị từ chối.
