# Source release register — current verification

| Source | Evidence available | Current release result / next reviewer task |
|---|---|---|
| Cheiro Palmistry for All, Gutenberg20480 | Phase1 source metadata, candidate chapter/printed-page locators | BLOCKED: current edition/rights/snapshot/translation and human semantic verification absent |
| Lavater Physiognomy, LOC24019748 | Candidate catalog metadata, not reviewed book snapshot | BLOCKED: read authoritative edition/locator/rights; do not enable image→traits |
| East Asian/Vietnamese | NOT_SELECTED | BLOCKED: Owner selects rights-cleared scholarly/historical source and reviewer |

Spec source register is immutable and remains under spec/locked. This current register does not mark prior URL metadata as fresh retrieval evidence. No source snapshots or model licenses are invented. Sources may be contradictory; keep tradition_id and citations separate, provide missing source status rather than voting on personal fate.
