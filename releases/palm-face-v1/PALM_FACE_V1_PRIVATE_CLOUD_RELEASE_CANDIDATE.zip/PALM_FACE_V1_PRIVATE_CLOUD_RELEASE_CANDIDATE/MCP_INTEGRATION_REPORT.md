# MCP integration

HOST INTEGRATION = BLOCKED. MCP1.29.0 StreamableHTTP runs locally and is exercised with actual ClientSession initialize/tools-list/call/resources-list and HTTP401 auth challenge. tools/list only pf_open_workspace with readOnly hint/output schema; resource ui://pf/workspace is a plain-text login guide. Projection has no image bytes/base64/mesh/landmarks/grants/bootstrap keys.

Actual evidence: evidence/mcp-local.json and release-regression.xml. Synthetic signed JWT is not production OIDC/OAuth2.1 login/PKCE/linking. No ChatGPT workspace/account integration, app-only visibility, picker, secret channel, CSP bridge or attachment access tested. Owner confirmed no target/provider/IdP/host permissions. No plugin installed/published, no localhost preview URL is offered.

After Owner supplies authorized HTTPS target and IdP, verify real discovery/token/audience/issuer/scopes/TLS+private ACL and account linking, compare live registry with API_SPEC; run synthetic host smoke. Keep fallback if host cannot guarantee app-only/secret separation. Private publication and production remain separate Owner actions after required gates.
