# Privacy and deletion

Local T03/T06/T09/T36/T40/T43–T47 pass: consent action in UI, cross-owner404, grant≤5min/session limit, immediate revoke, tombstone before purge, expiry/orphan inventory, purge failure/retry without extending deadline, encrypted DB/file payload, report invalidation, metadata-only audit and no stale-job resurrection. New raw failure cleanup and process cancellation tests add coverage. evidence/release-regression.xml and browser.json document current synthetic journey ending completed deletion.

Payload image/annotation/report/job/cache lifetime is absolute24h; raw finalize/reject removed immediately, abandoned raw no later than ticket expiry+15min; receipts/audit30days. Downloaded PDFs have their own lifecycle; this service cannot erase a file user independently attached/saved elsewhere. No personal images collected, no outside AI calls, no training.

Local completed receipt proves application inventory cleanup for that synthetic session only. Provider backups/versioning/soft-delete/VM snapshots/swap/region/logs, expiry during provider outage, purge deadlines and metadata-only alerting are NOT VERIFIED. Provider/operator must supply policies and execute outage/delete/expiry acceptance; no claim of forensic erasure or legal certification.
