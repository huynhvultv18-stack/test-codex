# Release hardening changelog

Spec PF-SPEC-1.0.0 / contract1.0.0 / policy1.0.0 giữ byte-identical.

- Bổ sung Linux child supervisor: wall deadline, CPU/AS/core/fd limits, private pipe, no stderr payload logging, kill process group/descendants and cancellation polling.
- Normalize upload outside DB transaction/event loop; limit2decoder requests, recheck session/ticket/revision/raw hash before canonical commit; keep finalize idempotency.
- Runtime analysis/PDF uses child executor; direct unit compute seam stays for deterministic fence tests. Lease attempt/state/expiry fence prevents stale-worker result/failure overwriting retry.
- Reject missing/nonempty PNG IEND; erase rejected raw even on transaction rollback; retain MIME/animated/size/pixel/EXIF/mirror verification.
- Optional local ClamAV Unix INSTREAM refuses found/error/unavailable/malformed responses; no external scanner service. Live signatures/detection remain BLOCKED.
- Reject invalid model kind/hash before model initialization; no new model assets/rights or real accuracy claimed.
- Added actual subprocess/CPU/memory/cancellation/stale lease/deletion-during-decode/replay/queue20 tests; no original test deleted or skipped.
- Benchmark now uses isolated child compute; distinguishes parent peak and child peak memory, excludes queue, records source hashes and synthetic scope.
- Pinned Playwright harness manifest/lock retained outside runtime; package output renamed to requested release ZIP, runtime/keys excluded.
- Preserved baseline evidence/docs and intermediate logs; produced cloud/CV/content/security/MCP/contract reports, owner dependencies, regression evidence, SBOM/license/checksums and gate matrix. No deployment, paid provisioning, source activation, Plugin installation or publication.
