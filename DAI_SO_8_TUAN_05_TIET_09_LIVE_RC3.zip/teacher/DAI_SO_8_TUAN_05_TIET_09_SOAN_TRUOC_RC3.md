# Soạn trước Đại số 8 Tuần 5 Tiết 9

Bài 5 Phép chia đa thức cho đơn thức

Tiết 1 trong 2 tiết — Mục 1 Chia đơn thức cho đơn thức

Bản dành giáo viên, thực hiện bằng candidate 0.5.1-rc.3. Nguồn: PPCT Toán 8 năm học 2026–2027, SGK Toán 8 Kết nối tri thức với cuộc sống, Tập 1, trang 22–24. Mọi phản hồi của HS bên dưới là dự kiến; đáp án chỉ dành GV, mở sau khi HS làm.

## L1 Khóa tiết và chuẩn bị

**Mục tiêu:** HS nhận biết khi nào hai đơn thức chia hết, thực hiện phép chia trong trường hợp chia hết và kiểm thương bằng phép nhân ngược; giải thích được vì sao chỉ xét hệ số hoặc bậc của đơn thức là chưa đủ.

**Kiến thức kế thừa:** Bài 1–4: hệ số, phần biến, số mũ, đơn thức thu gọn, phép nhân đơn thức. SGK trang 7 và 19 cung cấp nền trực tiếp; HĐ1 trang 22 yêu cầu nhớ lại trường hợp một biến.

**Phạm vi:** chỉ Mục 1. Chưa dạy quy tắc chia đa thức nhiều hạng tử cho đơn thức, Ví dụ 2, Luyện tập 2, Vận dụng 2 hoặc bài 1.31–1.32. Tiết 10 mới mở Mục 2 theo PPCT.

**Chuẩn bị:** SGK trang 22–24, bảng/TV, phiếu nhỏ cho HĐ2 và Bài chốt; che quy tắc và đáp án khi giao nhiệm vụ. Đây là tiết hình thành kiến thức mới, tổ chức theo ENGINE_1.

| Phần | Phút dự kiến |
|---|---:|
| L2 Kiểm tra bài cũ và dẫn vào bài | 5 |
| L3 Hình thành kiến thức và áp dụng SGK | 23 |
| L4 Luyện tập và Bài chốt | 10 |
| L5 Củng cố và hướng dẫn | 4 |
| Dự phòng chuyển hoạt động và phản hồi kéo dài | 3 |
| Tổng | 45 |

L1 chuẩn bị ngoài giờ dạy. Không cộng lại thời gian các hoạt động con vào tổng này.

## L2 Kiểm tra bài cũ và dẫn vào bài 5 phút

### Kiểm tra bài cũ 3 phút

GV chiếu lần lượt từng câu; HS trả lời nhanh, nêu một lí do ngắn. Ba câu tự tạo chỉ dùng Bài 1 và phép nhân đã học ở Bài 4.

**Câu 1 — Chọn một đáp án.** Hệ số của đơn thức $-6x^2y^3$ là:

A. $-6$; B. $6$; C. $5$.

**Đáp án GV:** A. Hệ số gồm cả dấu âm; $5$ là tổng số mũ, không phải hệ số.

**Câu 2 — Chọn một đáp án.** Tích $(2xy)(4x)$ bằng:

A. $6x^2y$; B. $8x^2y$; C. $8xy$.

**Đáp án GV:** B, vì $2\cdot4=8$ và $x\cdot x=x^2$. Nếu HS chọn C, yêu cầu chỉ ra hai thừa số chứa $x$ rồi sửa số mũ.

**Câu 3 — Chọn tất cả khẳng định đúng.**

A. $x^2\cdot x^3=x^5$; B. $y\cdot y=y^2$; C. $x^2+x^3=x^5$.

**Đáp án GV:** A và B. Quy tắc cộng số mũ ở đây thuộc phép nhân; $x^2$ và $x^3$ không phải hai đơn thức đồng dạng để cộng thành một hạng tử.

### Dẫn vào bài 2 phút

Dùng đúng bài toán mở đầu SGK trang 22: khối hộp thứ nhất có ba kích thước $x$, $2x$, $3y$; khối thứ hai có diện tích đáy $2xy$ và có cùng thể tích. Cần tìm chiều cao khối thứ hai.

GV cho HS nhìn hình SGK và tính thể tích khối thứ nhất bằng phép nhân đã học:

$$V=x\cdot2x\cdot3y=6x^2y.$$

Hỏi: “Biết thể tích và diện tích đáy, ta cần tìm chiều cao bằng phép tính nào?” HS đề xuất $6x^2y:2xy$. GV giữ bài toán để giải ở Vận dụng 1 sau khi hình thành quy tắc, chưa cho thương hoặc đọc công thức chia.

**Liên kết:** từ tính tích để tìm thể tích sang tìm một thừa số còn thiếu. Còn **40 phút dự kiến**.

## L3 Hình thành kiến thức và áp dụng SGK 23 phút

Thực hiện theo trang 22–23: phần giới thiệu → HĐ1 → HĐ2 → khung kiến thức → Ví dụ 1 → Luyện tập 1 → Vận dụng 1. Checkpoint tự tạo được đặt sau Ví dụ 1.

### Giới thiệu quan hệ chia hết 2 phút

Ở đầu Mục 1, SGK giới thiệu: với hai đa thức $A,B$ và $B\ne0$, $A$ chia hết cho $B$ nếu có đa thức $Q$ sao cho $A=B\cdot Q$. Khi đó viết $A:B=Q$.

HS đọc quan hệ, chỉ ra vai trò của $A$, $B$, $Q$ và giải thích vì sao có thể kiểm thương bằng phép nhân. GV xác nhận đây là phần giới thiệu trực tiếp của SGK, không gán nhãn hoạt động khám phá. Trong tiết này chỉ tìm thương của hai đơn thức.

### HĐ1 Nhớ lại trường hợp một biến 4 phút

**Đề SGK trang 22:**

**a)** Thực hiện phép chia $6x^3:3x^2$.
**b)** Với $a,b\in\mathbb R$, $b\ne0$, $m,n\in\mathbb N$: khi nào $ax^m$ chia hết cho $bx^n$? Nhắc lại cách thực hiện phép chia.

HS cá nhân làm câu a và nêu cách kiểm; trao đổi với bạn về số mũ của thương. GV gọi một HS giải thích:

$$6x^3:3x^2=2x,\qquad (3x^2)(2x)=6x^3.$$

Với $a\ne0$, HS nhắc lại điều kiện $m\ge n$ và thương:

$$ax^m:bx^n=\frac ab x^{m-n}.$$

GV hỏi: “Vì sao phải có $m\ge n$ để thương vẫn là đơn thức?” HS dùng quan hệ số mũ trong phép nhân để giải thích.

**Lưu ý GV về đề gốc:** SGK không loại $a=0$. Khi $a=0$, tử là đơn thức $0$, chia hết cho mọi $bx^n\ne0$, thương bằng $0$ vì $(bx^n)\cdot0=0$. Giữ nguyên điều kiện của đề; điều kiện số mũ nêu trên áp dụng khi $a\ne0$.

**Lỗi dự kiến:** lấy $3-2$ thành $3+2$. GV yêu cầu nhân thương dự kiến với $3x^2$ và đối chiếu số mũ của $x$.

### HĐ2 Tìm điều kiện cho nhiều biến 4 phút

**Đề SGK trang 23:** đoán xem $A$ có chia hết cho $B$ không; nếu chia hết, tìm thương và giải thích:

**a)** $A=6x^3y$, $B=3x^2y$.
**b)** $A=x^2y$, $B=xy^2$.

HS tự làm 90 giây, rồi từng cặp đối chiếu riêng số mũ của $x$ và $y$. Sản phẩm cần thu gồm kết luận, thương nếu có và lí do.

**Kết quả dự kiến:**

**a)** Chia hết, thương $2x$; kiểm $(3x^2y)(2x)=6x^3y$.
**b)** Không chia hết: số mũ của $y$ trong $B$ là $2$, lớn hơn số mũ $1$ trong $A$. Nhân $B$ với một đơn thức không thể làm số mũ của $y$ giảm từ $2$ xuống $1$.

GV hỏi: “Kiểm hệ số có đủ không? Phải so sánh những gì ở từng biến?” Một cặp trình bày; lớp đề xuất tiêu chí từ hai trường hợp. GV chỉ sau các sản phẩm này mới xác nhận và giải thích quy tắc ở nút kế tiếp.

### Chuẩn hóa và chốt ghi vở 3 phút

Với các đơn thức khác $0$, $A$ chia hết cho $B$ khi mỗi biến có trong $B$ đều có trong $A$, với số mũ trong $B$ không lớn hơn số mũ tương ứng trong $A$.

GV giải thích bằng phép nhân: khi $A=BQ$, số mũ của mỗi biến trong $A$ là tổng số mũ ở $B$ và $Q$; ngược lại, nếu các điều kiện đó đạt thì dựng được thương bằng chia hệ số và lấy hiệu số mũ. Không coi hai ví dụ riêng lẻ là chứng minh cho mọi trường hợp.

**HS ghi vở:**

1. Kiểm điều kiện chia hết theo từng biến và số mũ; số chia phải khác đơn thức $0$.
2. Trong trường hợp chia hết: chia hệ số, chia các lũy thừa cùng biến rồi nhân các kết quả.
3. Kiểm lại bằng $B\cdot Q=A$. Nếu số bị chia là $0$, thương bằng $0$ với $B\ne0$.

Không yêu cầu thương của hai hệ số phải là số nguyên. Sau phép chia, biến có số mũ $0$ được thay bằng $1$.

### Ví dụ 1 Giải thích trước khi tính 3 phút

**Đề SGK trang 23:** cho $A=5x^2yz^3$.

**a)** Vì sao $A$ không chia hết cho $B=x^2y^2z^2$?
**b)** Vì sao $A$ chia hết cho $C=-2x^2z^2$? Tìm $A:C$.

HS khoanh biến gây cản trở ở câu a, lập thương câu b rồi đối chiếu theo cặp. GV mời một giải thích ngắn.

**Đáp án GV:** a) $y$ trong $B$ có số mũ $2>1$ trong $A$. b) Các biến $x,z$ trong $C$ đều có số mũ không lớn hơn trong $A$; biến $y$ được giữ lại trong thương:

$$A:C=-\frac52 yz;\qquad (-2x^2z^2)\left(-\frac52 yz\right)=5x^2yz^3.$$

**Lỗi dự kiến:** bỏ $y$ vì $C$ không chứa $y$. GV hỏi: “Nhân thương đó với $C$ có khôi phục được $y$ trong $A$ không?” HS bổ sung biến còn thiếu.

### Checkpoint tự tạo 1 phút

HS trả lời ngắn: $2x^2y:(-2x^2y)$ bằng $-1$ hay $0$? Giải thích bằng nhân ngược.

**Đáp án GV:** $-1$, vì $(-2x^2y)(-1)=2x^2y$. Các biến triệt tiêu khỏi thương không làm thương bằng $0$.

### Luyện tập 1 HS tự xét và tính 3 phút

**Đề SGK trang 23:** phép chia nào không chia hết, vì sao; tìm thương các phép chia còn lại:

**a)** $-15x^2y^2$ chia cho $3x^2y$.
**b)** $6xy$ chia cho $2yz$.
**c)** $4xy^3$ chia cho $6xy^2$.

HS tự làm, đánh dấu bước “xét điều kiện” trước bước “tính thương”; hai bạn kiểm chéo trong 30 giây. GV chọn một lời giải và một lí do không chia hết để chốt.

**Đáp án GV:** a) $-5y$; b) không chia hết vì số chia có biến $z$ mà số bị chia không có; c) $\frac23y$. Kiểm:

$$3x^2y(-5y)=-15x^2y^2;\qquad 6xy^2\left(\frac23y\right)=4xy^3.$$

Nếu HS loại câu c vì $4$ không chia hết cho $6$ trong tập số nguyên, GV nhắc hệ số thương có thể là phân số; chính nhân ngược xác nhận thương.

### Vận dụng 1 Giải bài toán mở đầu 2 phút

HS trở lại hai khối hộp SGK trang 22, viết phép chia, tìm chiều cao và kiểm bằng thể tích:

$$h=6x^2y:2xy=3x;\qquad (2xy)(3x)=6x^2y.$$

Chiều cao khối hộp thứ hai là $3x$. $x,y$ dương do là kích thước của các khối hộp; đây là ý nghĩa tình huống, không thêm điều kiện vào nguyên văn đề SGK.

### Chuẩn bị ở nhà Giao bài 1 phút

Sau bài **1.30a sẽ làm trên lớp ở L4**, về nhà làm **SGK bài 1.30b, trang 24**:

“Tìm đơn thức $N$ sao cho $N:0{,}5xy^2z=-xy$.”

HS viết quan hệ nhân tương ứng, tìm $N$ và kiểm bằng phép chia. Giữ rõ dấu âm, số mũ và hệ số $0{,}5$. Nhiệm vụ chỉ dùng phép nhân đã học và chia đơn thức của tiết này.

**Đáp án dành GV, không chiếu khi giao bài:**

$$N=(0{,}5xy^2z)(-xy)=-0{,}5x^2y^3z.$$

Kiểm hệ số $-0{,}5:0{,}5=-1$, số mũ $x:2-1=1$, $y:3-2=1$, $z:1-1=0$, nên thương đúng $-xy$.

Còn **17 phút dự kiến**, gồm L4, L5 và dự phòng.

## L4 Luyện tập và Bài chốt 10 phút

### Bài 1.30a Tìm số chia chưa biết 7 phút

**Đề SGK trang 24:** tìm đơn thức $M$, biết:

$$\frac73 x^3y^2:M=7xy^2.$$

HS nhận dạng bài tìm số chia, viết $M\cdot7xy^2=\frac73x^3y^2$, tự làm 2 phút rồi trao đổi cách tìm và kiểm thương. GV gọi một HS trình bày; bạn khác kiểm bằng phép nhân.

**Đáp án GV:**

$$M=\frac73x^3y^2:7xy^2=\frac13x^2.$$

$$\left(\frac13x^2\right)(7xy^2)=\frac73x^3y^2.$$

GV chốt: thấy $A:M=Q$ thì dùng $A=M\cdot Q$ để tìm $M$, sau đó kiểm $M\cdot Q=A$. Đây là quan hệ chia hết vừa học, không dùng quy tắc chia đa thức nhiều hạng tử.

**Lỗi dự kiến:** lấy số mũ $x$ là $3$ hoặc giữ $y^2$ trong $M$. GV cho HS nhân biểu thức sai với $7xy^2$, đối chiếu số mũ; HS tự sửa $x^{3-1}=x^2$ và $y^{2-2}=1$.

Phân phối 7 phút: nhận dạng 1; tự làm 2; đối chiếu 1; trình bày, sửa lỗi, kiểm ngược và chốt phương pháp 3. Không cần chuyển sang SBT vì SGK còn đúng bài trọng tâm và vừa ngân sách.

### Bài chốt độc lập Cá nhân 3 phút

**Đề tự tạo, không gợi ý khi HS làm:** cho $A=-8x^3y^2$; xét $B_1=x^2y$ và $B_2=x^2y^3$.

Nam nói: “Chỉ cần bậc của $A$ không nhỏ hơn bậc của $B$ thì $A$ chia hết cho $B$.” Dùng hai trường hợp trên để nhận xét lời nói của Nam. Tìm thương trong trường hợp chia hết và giải thích trường hợp còn lại.

**Đáp án GV:** $A$ có bậc $5$, $B_1$ bậc $3$, $B_2$ bậc $5$. $A$ chia hết cho $B_1$, thương $-8xy$; không chia hết cho $B_2$ vì số mũ của $y$ trong $B_2$ là $3>2$ trong $A$. Lời nói của Nam sai: phải so từng biến, không chỉ tổng số mũ.

GV thu phiếu, dự kiến đọc lỗi về điều kiện hoặc số mũ; chưa ghi nhận tỉ lệ đạt vì chưa có dữ liệu lớp thật. Còn **7 phút dự kiến**, gồm L5 và 3 phút dự phòng.

## L5 Củng cố và hướng dẫn 4 phút

GV cho HS dùng chính lời giải/phiếu vừa làm để nhắc quy trình: **xét điều kiện từng biến → chia hệ số và lũy thừa → nhân ngược để kiểm**. Nhấn mạnh dấu âm, biến còn lại trong thương, số mũ $0$ và việc bậc không thay điều kiện từng biến.

Nếu dữ liệu lớp thật sau này cho thấy nhiều HS chỉ so bậc, GV dùng lại hai trường hợp trong Bài chốt để sửa một lỗi cốt lõi; không giao Bài chốt thứ hai.

Nhắc bài **1.30b trang 24** đã giao ở cuối L3. Chuẩn bị Tiết 10 theo PPCT: **chỉ đọc Mục 2 trang 24**, đánh dấu câu chưa hiểu; chưa yêu cầu giải Ví dụ 2, Luyện tập 2, Vận dụng 2 hoặc bài 1.31–1.32.

**Kết quả Bài chốt:** chưa có dữ liệu thực tế. **Thời lượng:** 45 phút dự kiến, chưa phải số đo lớp thật. Tổng tải được bố trí với một lượt trình bày ngắn ở mỗi hoạt động trọng tâm; 3 phút dự phòng dành cho chuyển hoạt động và phản hồi kéo dài.


## Gói nạp WEB LIVE theo hợp đồng RC3

Giữ nội dung và thứ tự bài soạn đã đối chiếu SGK. PREP_PACKET mới chứa đầy đủ thao tác GV/HS, phương pháp, lỗi, đáp án, chốt và công thức. Đây là nội dung dự kiến, chưa có dữ liệu học sinh hay thời lượng lớp thật.

| Màn hình | Giai đoạn | Phút dự kiến | Phần chốt mở theo lệnh |
|---|---|---:|---|
| GV_P09_K1 | L2 | 1 | Không |
| GV_P09_K2 | L2 | 1 | Không |
| GV_P09_K3 | L2 | 1 | Không |
| SGK5_OPENING | L2 | 2 | Không |
| SGK5_INTRO | L3 | 2 | Không |
| SGK5_HD1A | L3 | 2 | Không |
| SGK5_HD1B | L3 | 2 | Không |
| SGK5_HD2A | L3 | 2 | Không |
| SGK5_HD2B | L3 | 2 | Không |
| SGK5_STANDARD | L3 | 3 | Có |
| SGK5_VD1A | L3 | 1.5 | Không |
| SGK5_VD1B | L3 | 1.5 | Không |
| GV_P09_CHECKPOINT | L3 | 1 | Không |
| SGK5_LT1a | L3 | 1 | Không |
| SGK5_LT1b | L3 | 1 | Không |
| SGK5_LT1c | L3 | 1 | Không |
| SGK5_VDUNG1 | L3 | 2 | Không |
| SGK1.30B_HOMEWORK_ASSIGN | L3 | 1 | Không |
| SGK1.30A | L4 | 7 | Không |
| GV_P09_BAI_CHOT | L4 | 3 | Không |
| GV_P09_RECAP | L5 | 3 | Có |
| GV_P09_NEXT_READING | L5 | 1 | Không |

Lưu ý: câu hỏi giải thích tính phân phối ở Tiết 10 là cách GV tổ chức từ quy tắc SGK, không phải HĐ SGK. Bài về nhà được giao cuối L3, thực hiện sau giờ; không mở đáp án khi giao. Chuẩn bị đọc tiết tiếp theo không làm thay đổi phạm vi tiết hiện tại.
