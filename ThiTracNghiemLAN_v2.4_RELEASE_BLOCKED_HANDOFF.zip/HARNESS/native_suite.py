import json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/production-v24-release-20261008')
TESTS=['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_mathjax.py','kiem_tra_v222.py','kiem_tra_v23.py','kiem_tra_v23_integration.py']
results=[];out=ROOT/'evidence/native';out.mkdir(parents=True,exist_ok=True)
for test in TESTS:
 with tempfile.TemporaryDirectory(prefix='release_native_') as tmp:
  app=Path(tmp)/'app';shutil.copytree(ROOT/'frozen-source/PHAN_MEM',app)
  env=os.environ.copy()
  for key in ['PYTHONPATH','PYTHONSTARTUP','TNLAN_R4_VALID_CLIENT']:env.pop(key,None)
  env['PYTHONDONTWRITEBYTECODE']='1';env['LOCALAPPDATA']=str(Path(tmp)/'localappdata')
  start=time.monotonic();p=subprocess.run([sys.executable,test],cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  (out/(test+'.log')).write_bytes(p.stdout)
  row=dict(script=test,status='PASS' if p.returncode==0 else 'FAIL',exit_code=p.returncode,elapsed_s=round(time.monotonic()-start,3),standalone=True,external_adapter=False)
  results.append(row);print(test,row['status'],flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(int(any(r['status']!='PASS' for r in results)))
