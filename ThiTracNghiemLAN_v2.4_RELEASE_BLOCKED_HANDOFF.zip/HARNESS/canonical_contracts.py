"""Current F011/F012/F006 contract tests; no edits or monkeypatches to product."""
import copy,hashlib,html,json,re,sys,traceback
from io import BytesIO
from pathlib import Path
from flask import template_rendered
from openpyxl import Workbook,load_workbook
from r4_support import runtime,seed,sql,form_answers,token

ROOT=Path('/workspace/production-v24-release-20261008');OUT=ROOT/'evidence/canonical-contracts';OUT.mkdir(parents=True,exist_ok=True)
results=[]
def check(name,fn):
 try:results.append(dict(name=name,status='PASS',detail=fn()));print(name,'PASS',flush=True)
 except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()));print(name,'FAIL',flush=True)
def logical_hash(m):
 c=m.db()
 try:return hashlib.sha256('\n'.join(c.iterdump()).encode()).hexdigest()
 finally:c.close()
def workbook(data):
 wb=load_workbook(BytesIO(data),data_only=False)
 try:return {w.title:[[(cell.value,cell.data_type) for cell in row] for row in w] for w in wb}
 finally:wb.close()
with runtime(ROOT/'frozen-source/PHAN_MEM',OUT) as (m,teacher,root):
 raw=teacher.raw
 def current_nonce(c):return token(c)
 def valid_post(c,path,**kw):
  headers=dict(kw.pop('headers',{}) or {});headers['X-CSRF-Token']=current_nonce(c)
  return c.post(path,headers=headers,**kw)
 def csrf_cases():
  other=m.app.test_client();other_before=current_nonce(other)
  assert other.post('/teacher/login',data={'username':'admin','password':'123456','csrf_token':other_before}).status_code==302
  other_nonce=current_nonce(other);own=current_nonce(raw);assert own!=other_nonce
  sample=raw.get('/teacher/multi/excel?sample=1');assert sample.status_code==200
  wb=Workbook();ws=wb.active;ws.append(['Mã HS','Họ tên','Lớp']);ws.append(['CAN_A','Canonical A','6A']);ws.append(['CAN_B','Canonical B','6A']);stream=BytesIO();wb.save(stream);student_file=stream.getvalue()
  specs=[
   ('/teacher/multi/import',lambda:dict(data={'file':(BytesIO(sample.data),'canonical.xlsx')},content_type='multipart/form-data')),
   ('/teacher/students/import-preview',lambda:dict(data={'file':(BytesIO(student_file),'students.xlsx')},content_type='multipart/form-data')),
   ('/teacher/students/import-confirm',lambda:dict(data={'token':'not-an-operation-token','mode':'skip'})),
   ('/teacher/students/bulk',lambda:dict(data={'action':'move','student_ids':['999999'],'new_class':'7A'})),
   ('/teacher/mixed-exam',lambda:dict(data={'ten':'Canonical nonce','mon':'Tin học','lop':'6A','minutes':'15','SINGLE_NB':'1'})),
   ('/teacher/multi/edit/999999',lambda:dict(data={'question_type':'SINGLE','noi_dung':'test'})),
   ('/api/save-answer',lambda:dict(json={'index':0,'choice':0})),
   ('/exam',lambda:dict(data={'q_0':'0'}))]
  rows=[]
  for path,args in specs:
   for variant,headers in [('missing',{}),('wrong',{'X-CSRF-Token':'wrong'}),('other_session',{'X-CSRF-Token':other_nonce})]:
    before=logical_hash(m);response=raw.post(path,headers=headers,**args());after=logical_hash(m)
    assert response.status_code==403 and before==after,(path,variant,response.status_code)
    rows.append(dict(route=path,variant=variant,status=403,database_unchanged=True,request_reached_business_write=False))
  # Valid multipart transport and full DB effect, not redirect-only smoke.
  response=valid_post(raw,'/teacher/multi/import',data={'file':(BytesIO(sample.data),'canonical.xlsx')},content_type='multipart/form-data')
  assert response.status_code==302
  kinds={r[0] for r in sql(m,'SELECT DISTINCT question_type FROM cau_hoi')};assert kinds=={'SINGLE','MULTI','TF','MATCH','FILL'}
  response=valid_post(raw,'/teacher/students/import-preview',data={'file':(BytesIO(student_file),'students.xlsx')},content_type='multipart/form-data')
  assert response.status_code==200 and '2</b> học sinh hợp lệ' in response.get_data(as_text=True)
  import_token=re.search(r'name="token" value="([^"]+)"',response.get_data(as_text=True));assert import_token
  # Operation token and CSRF are separate contracts; valid CSRF does not waive import token.
  response=valid_post(raw,'/teacher/students/import-confirm',data={'token':import_token.group(1),'mode':'skip'},follow_redirects=True)
  assert response.status_code==200 and sql(m,"SELECT COUNT(*) FROM hoc_sinh WHERE ma_hs IN ('CAN_A','CAN_B')")[0][0]==2
  student_ids=[r[0] for r in sql(m,"SELECT id FROM hoc_sinh WHERE ma_hs IN ('CAN_A','CAN_B')")]
  response=valid_post(raw,'/teacher/students/bulk',data={'student_ids':student_ids,'action':'move','new_class':'6A_CANON'},follow_redirects=True)
  assert response.status_code==200 and sql(m,"SELECT COUNT(*) FROM hoc_sinh WHERE lop='6A_CANON'")[0][0]==2
  # Pre-auth nonce rotates on real login; the stale nonce must fail afterwards.
  before=logical_hash(m);response=other.post('/teacher/student/add',data={'ma_hs':'STALE','ho_ten':'Test','lop':'6A','csrf_token':other_before})
  assert response.status_code==403 and logical_hash(m)==before
  response=other.post('/teacher/student/add',data={'ma_hs':'FORM_VALID','ho_ten':'Test','lop':'6A','csrf_token':other_nonce})
  assert response.status_code==302 and sql(m,"SELECT COUNT(*) FROM hoc_sinh WHERE ma_hs='FORM_VALID'")[0][0]==1
  return dict(negative_cases=rows,negative_count=len(rows),valid_multipart_status=302,imported_five_types=sorted(kinds),valid_preview_status=200,valid_confirm_imported_students=2,valid_bulk_move_students=2,form_transport_valid=True,login_rotation_stale_nonce_status=403,operation_token_distinct_from_csrf=True,false_rejection_count=0)
 check('CF011_native_contract_missing_wrong_other_valid_rotation',csrf_cases)

 def f006_observation():
  records=[]
  # No product clock/DB manipulation: malformed requests must not create an exam.
  for kind in ('SINGLE','MULTI','TF','MATCH','FILL'):
   for level in ('NB','TH','VD','VDC'):seed(m,teacher,'F006_'+kind+level,kind,subject='CAN_F006',level=level)
  def reject(fields,field,value):
   before=[dict(r) for r in sql(m,'SELECT * FROM ky_thi ORDER BY id')]
   response=valid_post(raw,'/teacher/mixed-exam',data=fields)
   assert response.status_code==200 and before==[dict(r) for r in sql(m,'SELECT * FROM ky_thi ORDER BY id')]
   text=response.get_data(as_text=True);messages=[html.unescape(v) for v in re.findall(r'<p class="warn">(.*?)</p>',text,re.S)]
   assert messages and any(field in v for v in messages),(field,messages)
   with raw.session_transaction() as session:remaining=[v for _,v in session.get('_flashes',[])]
   assert remaining==[],'Native template consumes the flashed notice on render'
   records.append(dict(field=field,input=value if len(value)<60 else dict(decimal_digits=len(value),sha256=hashlib.sha256(value.encode()).hexdigest()),status=response.status_code,visible_messages=messages,remaining_session_flashes=[],exam_database_unchanged=True))
  for value in ['abc','',' ','0','-1','181','1.5','1e2','1_0','NaN','9'*5000]:
   reject(dict(ten='invalid time',mon='CAN_F006',minutes=value,SINGLE_NB='1'),'minutes',value)
  for kind in ('SINGLE','MULTI','TF','MATCH','FILL'):
   for level in ('NB','TH','VD','VDC'):
    field=kind+'_'+level
    for value in ['abc','-1','1.5','1e2','1_0','','1 2']:
     fields=dict(ten='invalid quota',mon='CAN_F006',minutes='15');fields[field]=value;reject(fields,field,value)
  assert len(records)==151
  return dict(time_cases=11,count_cases=140,records=records,expected_user_visible_error=True,legacy_session_flash_expectation_wrong_layer=True)
 check('CF006_invalid_time_20_cell_counts_visible_error_no_write',f006_observation)

 def f012_contract_a():
  histories=[]
  for number,marker in enumerate(['=1+1','+test','-test','@test','Tên bình thường']):
   subject='CAN_F012_'+str(number);question_rows=[];original_forms={}
   for kind in ('SINGLE','MULTI','TF','MATCH','FILL'):
    row,f=seed(m,teacher,marker+kind,kind,subject=subject,text=marker,points='4',mode='partial',weights='1,3' if kind in ('TF','MATCH','FILL') else '')
    question_rows.append(row);original_forms[row['id']]=f
   # Canonical Excel marker is present before snapshot creation, not injected afterwards.
   fields=dict(ten=marker,mon=subject,thoi_gian='15',hien_diem='on',**{k+'_NB':'1' for k in ('SINGLE','MULTI','TF','MATCH','FILL')})
   assert valid_post(raw,'/teacher/create-exam',data=fields).status_code==302
   eid=sql(m,'SELECT MAX(id) FROM ky_thi')[0][0];code='HIST_'+str(number)
   assert valid_post(raw,'/teacher/student/add',data={'ma_hs':code,'ho_ten':marker,'lop':'8A'}).status_code==302
   student=m.app.test_client();pre=current_nonce(student)
   assert student.post('/',data={'ma_hs':code,'ky_thi_id':eid,'csrf_token':pre}).location=='/exam';after_login=current_nonce(student);assert pre!=after_login
   with student.session_transaction() as session:aid=session['attempt_id']
   items=json.loads(sql(m,'SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0]);assert len(items)==5
   for q in items:assert q['history']['ma_cau'].startswith(marker) and q['history']['muc_do']=='NB' and q['q']==marker
   values={}
   for i,q in enumerate(items):
    v=q['answer'] if q['type']!='FILL' else [x[0] for x in q['answer']]
    if q['type']=='MULTI':v=v[:1]
    elif q['type'] in ('TF','MATCH','FILL'):v=[v[0],None if q['type']=='MATCH' else '']
    values[i]=v;assert student.post('/api/save-answer',json={'index':i,'choice':v},headers={'X-CSRF-Token':after_login}).status_code==200
   assert student.post('/exam',data={**form_answers(items,values),'csrf_token':after_login}).status_code==302
   frozen_attempt=dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0]);frozen_answers=[dict(r) for r in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=? ORDER BY vi_tri_cau',(aid,))]
   assert frozen_attempt['diem']==4.5
   def report(label):
    context={}
    def receiver(sender,template,context:dict,**kw):
     if template.name=='report.html':captured.update({k:copy.deepcopy(context[k]) for k in ('qstats','levels','avg','highest','lowest','historical_missing','submitted_count')})
    captured={};template_rendered.connect(receiver,m.app)
    try:response=raw.get(f'/teacher/report/{eid}')
    finally:template_rendered.disconnect(receiver,m.app)
    assert response.status_code==200
    text=response.get_data(as_text=True);assert marker in text
    (OUT/f'history_{number}_{label}.html').write_bytes(response.data)
    excel=raw.get(f'/teacher/report/{eid}/export');assert excel.status_code==200;(OUT/f'history_{number}_{label}.xlsx').write_bytes(excel.data)
    sheets=workbook(excel.data)
    assert len(sheets['PhanTichCauHoi'])==6
    for row in sheets['PhanTichCauHoi'][1:]:
     assert row[0][0].startswith(marker) and row[0][1]=='s';assert row[4]==(marker,'s') and row[3]==('NB','s')
     assert all(row[i][1]=='n' for i in (5,6,7))
    assert all(cell[1]!='f' for sheet in sheets.values() for row in sheet for cell in row)
    return dict(report_context=captured,workbook=sheets)
   before=report('before')
   for row in question_rows:
    f={**original_forms[row['id']],'ma_cau':'CURRENT_'+str(row['id']),'mon':'CURRENT_BANK','chu_de':'New topic','muc_do':'VD','noi_dung':'CURRENT_BANK_TEXT','points':'9'}
    assert valid_post(raw,f"/teacher/multi/edit/{row['id']}",data=f).status_code==302
    live=dict(sql(m,'SELECT * FROM cau_hoi WHERE id=?',(row['id'],))[0]);assert live['muc_do']=='VD' and live['noi_dung']=='CURRENT_BANK_TEXT'
   after=report('after');assert before==after
   assert frozen_attempt==dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0])
   assert frozen_answers==[dict(r) for r in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=? ORDER BY vi_tri_cau',(aid,))]
   assert all(q['text']==marker and q['cognitive']=='NB' and q['code'].startswith(marker) for q in after['report_context']['qstats'])
   histories.append(dict(marker=marker,exam_id=eid,attempt_id=aid,types=sorted({q['type'] for q in items}),snapshot_history_saved=True,bank_changed_by_editor=True,report_context_before=before['report_context'],report_context_after=after['report_context'],all_workbook_cells_and_types_unchanged=True,attempt_answers_snapshot_score_byte_unchanged=True,score=4.5,formula_injection_cells=0))
  return dict(contract='A',cases=histories,case_count=5,question_types=5,source='per-attempt snapshot at exam time',bank_current_metadata_never_substituted=True)
 check('CF012_contract_A_five_types_bank_mutation_HTML_Excel',f012_contract_a)

(OUT/'results.json').write_text(json.dumps(dict(results=results,oracle_file='canonical-expectations.json',product_monkeypatch=False,CSRF_disabled=False,fixture_only=True),ensure_ascii=False,indent=2)+'\n')
raise SystemExit(int(any(r['status']!='PASS' for r in results)))
