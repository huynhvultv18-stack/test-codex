"""Independent mathematical oracle; no application/R3 helper is imported."""
import json
import unicodedata
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction

def normalized(value):
    return ' '.join(unicodedata.normalize('NFC', str(value)).casefold().split())

def choice(value):
    if isinstance(value, str):
        try:return json.loads(value)
        except (ValueError,TypeError):return None
    return value

def complete(item, value):
    value=choice(value); kind=item.get('type','SINGLE');answer=item['answer']
    if kind=='SINGLE':return type(value) is int and value==answer
    if not isinstance(value,list):return False
    if kind=='MULTI':return all(type(v) is int for v in value) and set(value)==set(answer)
    if len(value)!=len(answer):return False
    if kind=='FILL':return all(isinstance(v,str) and normalized(v) in [normalized(a) for a in accepted] for v,accepted in zip(value,answer))
    if kind=='MATCH':return all(type(v) is int for v in value) and value==answer
    return value==answer

def earned(item, value):
    rule=item.get('scoring',{});maximum=Fraction(str(rule.get('points',1)))
    value=choice(value);kind=item.get('type','SINGLE');answer=item['answer']
    if rule.get('mode','all')=='all' or kind=='SINGLE':return maximum*int(complete(item,value)),maximum
    if not isinstance(value,list):return Fraction(0),maximum
    if kind=='MULTI':
        if any(type(v) is not int or not 0<=v<len(item['options']) for v in value):return Fraction(0),maximum
        selected=set(value);right=set(answer)
        ratio=max(Fraction(0),Fraction(len(selected & right)-len(selected-right),len(right)))
    else:
        if len(value)!=len(answer):return Fraction(0),maximum
        weights=[Fraction(str(w)) for w in rule.get('weights') or [1]*len(answer)]
        hits=[]
        for v,a in zip(value,answer):
            if kind=='FILL':ok=isinstance(v,str) and normalized(v) in [normalized(x) for x in a]
            elif kind=='MATCH':ok=type(v) is int and v==a
            else:ok=isinstance(v,str) and v==a
            hits.append(int(ok))
        ratio=sum(w*h for w,h in zip(weights,hits))/sum(weights)
    return maximum*ratio,maximum

def score(items, values):
    parts=[earned(item,values.get(i)) for i,item in enumerate(items)]
    denominator=sum(maximum for _,maximum in parts)
    ratio=sum(value for value,_ in parts)*10/denominator if denominator else Fraction(0)
    number=Decimal(ratio.numerator)/Decimal(ratio.denominator)
    return float(number.quantize(Decimal('.01'),rounding=ROUND_HALF_UP))

def correct_value(item):
    answer=item['answer']
    return [values[0] for values in answer] if item['type']=='FILL' else answer

def wrong_value(item, tag='wrong'):
    kind=item['type'];a=item['answer']
    if kind=='SINGLE':return (a+1)%len(item['options'])
    if kind=='MULTI':return [i for i in range(len(item['options'])) if i not in a]
    if kind=='TF':return ['S' if v=='D' else 'D' for v in a]
    if kind=='MATCH':return [(v+1)%len(a) for v in a]
    return [tag+'_'+str(i) for i in range(len(a))]

def partial_value(item, tag='partial'):
    value=correct_value(item);kind=item['type']
    if kind=='SINGLE':return value
    if kind=='MULTI':return value[:1]
    if kind=='TF':return [value[0]]+['S' if v=='D' else 'D' for v in value[1:]]
    if kind=='MATCH':return [value[0]]+[None]*(len(value)-1)
    return ['  '+value[0].upper()+'  ']+[tag]*(len(value)-1)

def answers_for(items, student, phase):
    values={}
    for i,item in enumerate(items):
        selected=(student+i+phase)%3
        values[i]=(correct_value(item) if selected==0 else partial_value(item,f'client{student}_phase{phase}_q{i}') if selected==1 else wrong_value(item,f'client{student}_phase{phase}_q{i}'))
    return values

def submit_form(items, values):
    fields=[]
    for i,item in enumerate(items):
        v=values.get(i);kind=item['type']
        if kind=='SINGLE':fields.append(('q_'+str(i),'' if v is None else str(v)))
        elif kind=='MULTI':fields.extend(('q_'+str(i),str(x)) for x in (v or []))
        else:
            for j in range(len(item['options'])):
                item_value=v[j] if isinstance(v,list) and j<len(v) else None
                fields.append((f'q_{i}_{j}','' if item_value is None else str(item_value)))
    return fields
