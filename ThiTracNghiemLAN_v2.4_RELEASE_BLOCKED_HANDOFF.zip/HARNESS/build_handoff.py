from pathlib import Path
import json, hashlib, shutil, zipfile
from datetime import datetime, timezone, timedelta

ROOT = Path('/workspace/production-v24-release-20261008')
REPORTS = ROOT / 'reports'
E = ROOT / 'evidence'
stamp = datetime.now(timezone(timedelta(hours=7))).isoformat()
sha = lambda data: hashlib.sha256(data).hexdigest()
provenance = json.loads((E/'input-provenance.json').read_text())
SOURCE = Path(provenance['selected_source'])
EXPECTED = 'eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d'
assert sha(SOURCE.read_bytes()) == EXPECTED
manifest = json.loads((E/'input-manifest.json').read_text())['product_files']
actual = {str(p.relative_to(ROOT/'frozen-source')):sha(p.read_bytes()) for p in (ROOT/'frozen-source').rglob('*') if p.is_file()}
assert actual == manifest
for sub in ['native','r4-canonical','canonical-contracts','ui','lan']:
    d=json.loads((E/sub/'results.json').read_text())
    rows=d if isinstance(d,list) else d['results']
    assert rows and all(r['status']=='PASS' for r in rows),sub

status = dict(SOURCE_ZIP_SHA256=EXPECTED,SOURCE_INTEGRITY='PASS',PRODUCT_SOURCE_MUTATED='NO',
 WINDOWS_BUILD='NOT_RUN',EXE_STARTUP='NOT_RUN',LOCALHOST='NOT_RUN (Windows EXE)',LAN_CLIENT='NOT_RUN (Windows EXE)',
 R4_REGRESSION='PASS (Linux source)',UI01_UI28='PASS (Linux Chromium)',CSRF_F011='PASS (Linux source)',
 SNAPSHOT_F012='PASS (Linux source)',FIVE_QUESTION_TYPES='PASS (Linux source/browser)',
 LICENSE_LAPTOP='USER_REPORTED_PASS',PHYSICAL_50_PC_USER_REPORTED='USER_REPORTED_PASS',
 PHYSICAL_50_PC_EVIDENCE='NOT_VERIFIED',DATA_BACKUP_READY='NOT_VERIFIED',ROLLBACK_READY='NOT_VERIFIED',
 CRITICAL_DEFECTS='0_CONFIRMED_IN_REVIEWED_SOURCE_SCOPE; Windows/live unknown',
 HIGH_DEFECTS='0_CONFIRMED_IN_REVIEWED_SOURCE_SCOPE; Windows/live unknown',
 PRODUCTION_RELEASE_CANDIDATE='BLOCKED',LIVE_DEPLOYMENT='NOT_PERFORMED',PRODUCTION_SHA256='N/A_NOT_CREATED',PRODUCTION_STATUS='BLOCKED')
(E/'FINAL_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
def write(name, text):
    (REPORTS/name).write_text(text.strip()+'\n',encoding='utf-8')
fields='\n'.join(f'{k} = {v}' for k,v in status.items())
write('PRODUCTION_V2_4_RELEASE_REPORT.md',f'''
# V2.4 controlled release decision — RELEASE_BLOCKED

Prepared {stamp} (UTC+07:00). PROMOTION = BLOCKED. No Production artifact,
RC2, product patch, EXE or live replacement has been performed.

The three uploaded Windows complete ZIPs are byte-identical. The latest upload
is the selected source of truth, SHA-256 `{EXPECTED}`, 849313 bytes, 82 archive
members. All archive CRCs, payload checksums and 64 product-file manifest rows
were verified before testing, then all product hashes and source ZIP were
rechecked after testing. Source and original archives remain untouched.

## Mandatory blockers

| Gate | Result | Evidence/action required |
|---|---|---|
| Real Windows build and resolved dependency/wheel provenance | NOT_RUN | Linux host; no Windows connection. User explicitly answered CHƯA CÓ. |
| EXE startup/localhost/teacher/student LAN/license/reopen | NOT_RUN | No verified EXE exists; source tests are not EXE acceptance. |
| Active production folder, exact EXE and DB schema | NOT_VERIFIED | Operator must inventory the active machine/version first. |
| Verified private DB/config/license-state backup | NOT_VERIFIED | No actual backup supplied/accessed. Disposable test backup success does not satisfy this gate. |
| Restore/rollback rehearsal for actual installation | NOT_VERIFIED | Written plan only; actual-machine execution evidence absent. |

User-reported physical 50-PC and laptop license PASS are preserved as statements,
not relabeled independently verified. The source request reports those results;
no Windows log/EXE hash/room test evidence was supplied this turn.

## Source review

Read app.py/database setup, multi_routes.py/question_types.py, scoring.py,
snapshot_validation.py, license_core.py, templates/static/MathJax and build scripts.
`EVIDENCE/source-audit.json` records exact function line locations and limits.
CSRF is checked globally for unsafe methods, with real signed-session nonce,
header/form transport and login rotation. Submit and autosave serialize with
BEGIN IMMEDIATE, deadline is rechecked under the write lock and submitted_at
guards commitment. The current R4 question builder is installed by
install_multi_routes; no live-bank backfill replaces Contract A history.
The 5 types and 20 matrix cells, available/requested validation, comma topic,
scoring modes/weights, snapshots, UI navigation/MathJax and report/export pass
the fresh canonical suites. Licensing/MID source remains unchanged; signature,
trial clock/state and same-process identity checks remain in the native/browser
tests. Actual authorized Windows license remains unverified here.

The received four test-only scripts match the approved nonce-only copies, with
76 original functional assertions preserved. Six native scripts execute standalone
from exact received source in batch order, without sitecustomize/transport adapter.
Earlier incompatible raw tests and failures are retained separately under
EVIDENCE/LEGACY_RAW_EVIDENCE and received prior reports; they are not skipped
or silently relabeled as passing. Current received source already contains the
explicitly approved compatibility overlay.

## Packaging and data compatibility observations

Existing build_exe.bat includes templates/static (including offline MathJax),
Waitress hidden import and openpyxl/cryptography collection. Version headings
retain historical v2.3 wording; source is not renamed or bumped. Requirements
are unpinned: a Windows resolved lock/wheel-hash capture is required for release
reproducibility. The batch prefers py -3; a clean VM must have only the intended
Python installed, and the selected interpreter must be recorded. It also opens
Explorer and pauses; operator must capture the final exit code.

Runtime init_db contains existing conditional ALTER TABLE paths and startup writes
including admin role/active normalization. No live DB is opened here. Before any
authorized move, prove the active schema/initialization on an isolated backup copy
and reject a plan requiring automatic migration. These are disclosed compatibility
gates, not changes made by this task. Copying only an EXE cannot prove data safety.

No new HIGH/CRITICAL product defect was confirmed in the reviewed source/tests.
This is bounded evidence, not an exhaustive vulnerability scan or a Windows safety
certification. Unrun EXE and active data/licensing cannot be certified defect-free.

## Final status

```text
{fields}
```

Only a RELEASE_BLOCKED handoff is produced. Its SHA is a handoff SHA, not a
Production SHA. Do not deploy it to the active server. Stop at this decision;
future live deployment still needs a separate explicit authorization and plan.
''')
metrics50=json.loads((E/'lan/metrics-50.json').read_text())
metrics60=json.loads((E/'lan/metrics-60.json').read_text())
write('PRODUCTION_V2_4_TEST_REPORT.md',f'''
# V2.4 release regression evidence

Fresh run: {stamp}. Target: exact received source ZIP `{EXPECTED}`.
Environment: Linux Python 3.12.14, Flask 3.1.3, Waitress 3.0.2, openpyxl 3.1.5,
cryptography 50.0.0, Chromium/Playwright. Exact package versions recorded in
EVIDENCE/linux-environment.json. These versions are not a verified Windows lock.
Private fixture databases/trial state only; no actual user database/license reset,
hardware identity override, monkeypatch of product or relaxed CSRF.

| Suite | Fresh result | Evidence |
|---|---|---|
| Native batch gates in exact order | 6/6 PASS | native/results.json and six raw logs |
| R4 canonical | 7/7 PASS | r4-canonical/results.json |
| F011/F006/F012 current contract | 3/3 PASS | canonical-contracts/results.json |
| Browser groups | 28/28 PASS; no JS errors | ui/results.json and 5 actual screenshots |
| UI01–UI28 | 28/28 PASS | UI01_UI28_TRACEABILITY.json |
| Native HTTP LAN suite | 6/6 PASS | lan/results.json |
| Real Windows EXE and resources | NOT_RUN | No Windows endpoint/verified EXE |
| Actual laptop license | USER_REPORTED_PASS | No independently verified device evidence |
| Physical 50-PC | USER_REPORTED_PASS | No independently verified room logs |
| Actual backup/restore/rollback | NOT_VERIFIED | Fixture restore checks are separate |

Native scripts: kiem_tra_v22.py, kiem_tra_v221.py, kiem_tra_mathjax.py,
kiem_tra_v222.py, kiem_tra_v23.py, kiem_tra_v23_integration.py. Every process
returned 0, standalone, no adapter; full original assertions are retained.

Coverage includes teacher/student login, nonce rotation and all unsafe-route
negatives, all 5 question types, ALL/PARTIAL/weights/max-score compatibility,
malformed snapshots/scoring and restore rejection, 20 matrix cells/comma topic,
availability rejection, offline MathJax, real acknowledged autosave/offline failure,
question switch/flags/reload/resume, deadline and late POST, atomic double/race
submit, independent regrading, snapshot Contract A under real bank edits,
monitor/report/Excel import/export and historical legacy-unknown behavior.
R4 scoring equivalence compares 344 cases to the locked prior oracle. F011 tests
include 175 raw route negatives plus 24 missing/wrong/other-session cases and
login rotation; legitimate multipart/form/JSON requests remain accepted.

50-client scopes: {metrics50['request_count']} requests; unexpected failures
{metrics50['failed_count']}; HTTP 500 {metrics50['HTTP_500_count']};
{metrics50['planned_timeouts']} intentionally induced short-read timeout for retry.
60-client headroom: {metrics60['request_count']} requests; failures
{metrics60['failed_count']}; HTTP 500 {metrics60['HTTP_500_count']}.
All stored answer/score comparisons, race winner, deadline invariants and isolation
PASS. Requests, resource samples and comparisons are preserved, not fabricated.
This is source/HTTP simulation on Linux, not a physical Windows-room result.

All five required screenshots are fresh Linux Chromium outputs at 1366x768 or
1920x1080. Before/after product hashes equal for all 64 files. Original legacy
raw failures are retained with their original FAIL classification; received older
reports are historical and not rewritten. No canonical failure was skipped.
''')
(REPORTS/'PRODUCTION_V2_4_FILE_MANIFEST_SHA256.txt').write_text(
    f'{EXPECTED}  SOURCE/ThiTracNghiemLAN_v2.4_UI_RC1_WINDOWS_BUILD_COMPLETE.zip\n'+
    ''.join(f'{manifest[n]}  {n}\n' for n in sorted(manifest)))

write('PRODUCTION_V2_4_WINDOWS_BUILD_REPORT.md',r'''
# Windows build and EXE acceptance — NOT_RUN

WINDOWS_BUILD = NOT_RUN
EXE_STARTUP = NOT_RUN
PROMOTION = BLOCKED
No cross-compiled/Linux/Wine binary is substituted for Windows. No EXE exists in
this handoff. The source ZIP and packaged data folders remain unchanged.

## Reproducible operator procedure (requires real clean Windows)

Do not execute in the active installation. Use a fresh disposable Windows x64 VM,
only the chosen Python 3.12.6 x64 installed. Record Windows version, architecture,
Python installer source/SHA, `py -0p`, `py -3 --version`, and pip version. The
existing batch chooses `py -3`; a virtualenv alone cannot guarantee that choice.
Do not set a Machine ID override or install customer activation secrets on a VM.

1. Verify the supplied source ZIP SHA is exactly:
   eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d
   Use Get-FileHash -Algorithm SHA256 and compare. Extract into a new clean folder.
   Compare the 64 product-file hashes with the source manifest before running.
2. Resolve the reference toolchain versions below in the clean Windows environment.
   They are copied from the user's earlier Windows screenshot, not certified by
   this Linux run. If unavailable/incompatible, stop; do not silently change them.
   Python 3.12.6; pip 24.2; Flask 3.1.3; openpyxl 3.1.5; waitress 3.0.2;
   cryptography 50.0.2; PyInstaller 6.22.3. The source requirements.txt stays intact.
   Example (clean build VM only):

   py -3 -m pip install pip==24.2
   py -3 -m pip install Flask==3.1.3 openpyxl==3.1.5 waitress==3.0.2 cryptography==50.0.2 PyInstaller==6.22.3
   py -3 -m pip check
   py -3 -m pip freeze --all > WINDOWS_RESOLVED_LOCK.txt
   py -3 -m pip download --only-binary=:all: -r WINDOWS_RESOLVED_LOCK.txt -d wheelhouse

   Preserve all exact transitive versions and SHA256 of every downloaded wheel,
   Python installer, lock and pip version. Download/install must keep TLS/package
   verification enabled. Resolve errors rather than removing validation. Freeze
   the Windows wheelhouse before building. The first resolution is NOT yet a
   reproducibility PASS: repeat on another clean Windows environment with the
   same interpreter and verified wheel bytes before claiming repeatability.
   To repeat, first verify every saved wheel SHA, then install offline:

   py -3 -m pip install --no-index --find-links wheelhouse -r WINDOWS_RESOLVED_LOCK.txt
   py -3 -m pip check

3. Run all six native tests directly from PHAN_MEM in exact build order:

   py -3 kiem_tra_v22.py
   py -3 kiem_tra_v221.py
   py -3 kiem_tra_mathjax.py
   py -3 kiem_tra_v222.py
   py -3 kiem_tra_v23.py
   py -3 kiem_tra_v23_integration.py

   Record each command's exit code/stdout/stderr; stop at any failure. No adapter,
   sitecustomize, CSRF disable/exemption, assertion edits or skips. Four approved
   test files are already present in this source, not a manual overlay step.
4. In a CMD session, set PIP_NO_INDEX=1, PIP_FIND_LINKS to the verified wheelhouse
   and PIP_CONSTRAINT to the absolute WINDOWS_RESOLVED_LOCK.txt path. These are
   local build-session settings, not application configuration. Run the unchanged
   build_exe.bat from PHAN_MEM and capture full output plus exit status. Its six
   gates run again; existing PyInstaller mechanism embeds templates/static,
   Waitress, openpyxl and cryptography and prepares external resource copies.
   Do not bypass the batch if its gate fails. The batch pauses and opens Explorer;
   operator must continue/capture the final exit code explicitly.
5. Inventory dist recursively and SHA256 every file. Prove the EXE exists and is
   nonzero. Compare external templates/static against the source manifest; verify
   all ui-v24 CSS/JS and static/vendor/mathjax/tex-svg.js. Inspect PyInstaller log,
   import warnings and executable architecture on Windows. Stop for any missing
   runtime resource/dependency. Exclude fixture DB, WAL/SHM, imports/exports,
   logs, .session_secret, license_trial.json and user LOCALAPPDATA state from the
   clean distributable. Do not run the EXE in the distribution-master directory;
   use a separate testing copy so generated private state is not distributed.
6. Inspect the built EXE in a separate controlled test deployment: launch,
   /health and localhost:5000, teacher login, real LAN student login, all five
   question types and MathJax, autosave/reload/resume, deadline/submit/race,
   CSRF negatives, history/Excel/monitor. Verify the EXE's own static asset hashes.
   Source Flask test-client results cannot satisfy this step. Run on the actual
   authorized laptop under its intended Windows user to check paid license/MID;
   never copy a license from another machine, reset trial or alter the identifier.
   Record close/reopen continuity and reboot continuity if possible. Redact
   activation keys/passwords/cookies; keep private data out of shareable evidence.
7. Only after EXE, active backup/restore and rollback gates PASS may a new frozen
   Production payload be produced. Prepare a future runtime payload from the
   verified dist, not CONG_CU_CAP_MA or source issuer tooling/private keys. Match
   the SHA manifest and source provenance; live deployment is a separate action.

No step above was executed on Windows this turn. The lock/wheelhouse and EXE
manifest are NOT yet available. A written procedure is not Windows acceptance.
''')

write('PRODUCTION_V2_4_BACKUP_ROLLBACK_PLAN.md',r'''
# Actual installation backup and rollback — NOT_VERIFIED

DATA_BACKUP_READY = NOT_VERIFIED
ROLLBACK_READY = NOT_VERIFIED
This is a plan only. Native test backup/restore success concerns disposable fixture
data. No active installation, user DB or actual license state was accessed.

1. Before proposing replacement, operator records the exact active folder, EXE
   SHA, external template/static hashes, Windows account, server port/IP, current
   R4/working Windows release and controlled maintenance window. Preserve old
   EXE/source versions and folders. No deletion or in-place replacement.
2. On the original authorized machine, record legitimate license status and MID
   privately via existing UI; do not publish activation codes or change identity.
   Private state includes DATA_DIR/thi_trac_nghiem.db (cai_dat config/license rows),
   DATA_DIR/.session_secret, DATA_DIR/license_trial.json, external uploads/resources
   and %LOCALAPPDATA%/ThiTracNghiemLAN/<current-MID>.json for the actual Windows
   account. Do not read actual secret values into shareable logs. Preserve ACLs
   and secure/encrypted storage; never put a real backup in GitHub/handoff.
3. Obtain a consistent DB snapshot through native authenticated backup/SQLite backup
   API. With SQLite WAL, copying a live main .db alone is unsafe. If a filesystem
   copy is planned, schedule a controlled server stop and confirm no writers;
   preserve the complete data state and journal artifacts consistently. Do not
   manually delete WAL/SHM or run an unreviewed checkpoint against production.
   Preserve matching config/uploads/licensing files from the same maintenance state.
4. Hash original backup/copy privately, verify readable SQLite snapshot using
   read-only integrity_check, inventory schema/table counts/settings presence,
   attempts/snapshots/answers and scores, and ensure uploaded image references exist.
   Do not log password hashes, activation values or student PII publicly. Confirm
   hashes after transfer/storage. Retain the unmodified verified backup.
5. Rehearse restore into another isolated folder on the same authorized hardware
   and intended Windows account, with a controlled non-conflicting port and no
   active room session. Never overwrite the live DB. Existing init_db performs
   conditional schema upgrades and startup writes; compare before/after schema and
   relevant state on the disposable copy. Do not launch a new build against the
   live DB or permit automatic migration. If a schema change is required, stop and
   seek an explicit separately scoped decision. Trial state in the user profile
   is machine/account-wide: do not spoof, erase or reset it for a rehearsal.
6. Verify restored question bank, student/exam/history counts, historical report
   and independently regraded scores, config/port and legitimate licensing. Test
   close/reopen continuity. Record signed operator result and SHA provenance.
7. Rollback means retaining/rerunning the previously verified working executable
   with the matching private state on the same authorized hardware/account. Use
   a verified backup only under a separately approved maintenance plan. Preserve
   the failed new folder for diagnosis; no deleting old versions. Define rollback
   triggers (EXE failure, data discrepancy, licensing/MID change, missing resources,
   unplanned schema change or exam failure) and rollback owner/time limit.

Until actual backup readability and rehearsal logs exist, promotion remains
BLOCKED. Documentation, simulated restore and user-reported room PASS do not
substitute for verified safety of the active installation.
''')
write('PRODUCTION_V2_4_HANDOFF_CHECKLIST.md',f'''
# Release gate checklist — RELEASE_BLOCKED

- [x] Exact source SHA256 `{EXPECTED}` and archive/member manifests verified.
- [x] All 64 source files unchanged; no patch/RC2/source version bump.
- [x] Fresh Linux six native gates, R4 canonical, F011/F012 and 5 types PASS.
- [x] UI01–UI28/browser/screenshots PASS on Linux Chromium.
- [x] Linux HTTP 50/60 simulations PASS; raw evidence retained.
- [x] Prior incompatible legacy failures kept as evidence.
- [x] User-reported laptop/physical 50-PC PASS recorded separately.
- [x] Source/packaging audit and exact function/hash provenance recorded.
- [x] Windows build and private backup/rollback instructions prepared.
- [ ] Real Windows dependency lock/wheel SHA and reproducibility verified.
- [ ] Actual EXE build hash, resource manifest, startup/localhost/teacher/LAN verified.
- [ ] Authorized laptop EXE license/MID and close/reopen (reboot if available) verified.
- [ ] Active installation/version/schema identified.
- [ ] Actual DB/config/license state backup read/integrity/hash verified privately.
- [ ] Actual isolated restore/rollback rehearsal verified; no migration required.
- [ ] All mandatory gates PASS and Production payload/manifest created.
- [ ] Separate live-deployment authorization/maintenance plan obtained (future only).

PRODUCTION_RELEASE_CANDIDATE = BLOCKED
LIVE_DEPLOYMENT = NOT_PERFORMED
PRODUCTION_STATUS = BLOCKED
PRODUCTION_SHA256 = N/A_NOT_CREATED

Use the SOURCE copy only for provenance and an isolated Windows build. The
RELEASE_BLOCKED handoff is not approved for live installation. Its contents include
six required reports, fresh source-level evidence, synthetic test artifacts,
prior evidence labeled as historical, external test harness and the byte-identical
source ZIP. No real database, passwords, activation keys or actual trial state is
included. Legacy public source/bootstrap/test fixture constants are preserved,
not actual customer credentials. No issuing private key was found in the supplied
ZIP. A future runtime payload must exclude issuer tooling and private keys.
''')

artifacts=ROOT/'artifacts';artifacts.mkdir(exist_ok=False)
out=artifacts/'ThiTracNghiemLAN_v2.4_RELEASE_BLOCKED_HANDOFF.zip'
payload={}
for p in REPORTS.iterdir():payload['REPORTS/'+p.name]=p.read_bytes()
payload['SOURCE/'+SOURCE.name]=SOURCE.read_bytes()
for p in E.rglob('*'):
    if p.is_file():
        assert p.suffix.lower() not in {'.db','.sqlite','.sqlite3','.pyc'}
        payload['EVIDENCE/'+str(p.relative_to(E))]=p.read_bytes()
for p in (ROOT/'harness').glob('*.py'):
    payload['HARNESS/'+p.name]=p.read_bytes()
payload['SHA256SUMS.txt']=''.join(f'{sha(payload[n])}  {n}\n' for n in sorted(payload)).encode()
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n in sorted(payload):z.writestr(n,payload[n])
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        digest,n=line.split('  ',1);assert sha(z.read(n))==digest
    assert sha(z.read('SOURCE/'+SOURCE.name))==EXPECTED
assert sha(SOURCE.read_bytes())==EXPECTED
record=dict(PACKAGE_TYPE='RELEASE_BLOCKED_HANDOFF',PROMOTION='BLOCKED',SOURCE_ZIP_SHA256=EXPECTED,
 PRODUCT_SOURCE_MUTATED=False,file=out.name,bytes=out.stat().st_size,members=len(payload),
 sha256=sha(out.read_bytes()),ZIP_CRC='PASS',member_checksums='PASS',PRODUCTION_SHA256='N/A_NOT_CREATED')
(artifacts/'RELEASE_BLOCKED_PACKAGE_VALIDATION.json').write_text(json.dumps(record,indent=2)+'\n')
(artifacts/'SHA256SUMS_V2_4_RELEASE_BLOCKED.txt').write_text(f'{record["sha256"]}  {out.name}\n')
for p in REPORTS.iterdir():shutil.copyfile(p,artifacts/p.name)
print(json.dumps(record,indent=2))
