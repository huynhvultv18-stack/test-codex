# Release gate checklist — RELEASE_BLOCKED

- [x] Exact source SHA256 `eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d` and archive/member manifests verified.
- [x] All 64 source files unchanged; no patch/RC2/source version bump.
- [x] Fresh Linux six native gates, R4 canonical, F011/F012 and 5 types PASS.
- [x] UI01–UI28/browser/screenshots PASS on Linux Chromium.
- [x] Linux HTTP 50/60 simulations PASS; raw evidence retained.
- [x] Prior incompatible legacy failures kept as evidence.
- [x] User-reported laptop/physical 50-PC PASS recorded separately.
- [x] Source/packaging audit and exact function/hash provenance recorded.
- [x] Windows build and private backup/rollback instructions prepared.
- [ ] Real Windows dependency lock/wheel SHA and reproducibility verified.
- [ ] Actual EXE build hash, resource manifest, startup/localhost/teacher/LAN verified.
- [ ] Authorized laptop EXE license/MID and close/reopen (reboot if available) verified.
- [ ] Active installation/version/schema identified.
- [ ] Actual DB/config/license state backup read/integrity/hash verified privately.
- [ ] Actual isolated restore/rollback rehearsal verified; no migration required.
- [ ] All mandatory gates PASS and Production payload/manifest created.
- [ ] Separate live-deployment authorization/maintenance plan obtained (future only).

PRODUCTION_RELEASE_CANDIDATE = BLOCKED
LIVE_DEPLOYMENT = NOT_PERFORMED
PRODUCTION_STATUS = BLOCKED
PRODUCTION_SHA256 = N/A_NOT_CREATED

Use the SOURCE copy only for provenance and an isolated Windows build. The
RELEASE_BLOCKED handoff is not approved for live installation. Its contents include
six required reports, fresh source-level evidence, synthetic test artifacts,
prior evidence labeled as historical, external test harness and the byte-identical
source ZIP. No real database, passwords, activation keys or actual trial state is
included. Legacy public source/bootstrap/test fixture constants are preserved,
not actual customer credentials. No issuing private key was found in the supplied
ZIP. A future runtime payload must exclude issuer tooling and private keys.
