# V2.4 release regression evidence

Fresh run: 2026-10-08T12:05:24.735234+07:00. Target: exact received source ZIP `eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d`.
Environment: Linux Python 3.12.14, Flask 3.1.3, Waitress 3.0.2, openpyxl 3.1.5,
cryptography 50.0.0, Chromium/Playwright. Exact package versions recorded in
EVIDENCE/linux-environment.json. These versions are not a verified Windows lock.
Private fixture databases/trial state only; no actual user database/license reset,
hardware identity override, monkeypatch of product or relaxed CSRF.

| Suite | Fresh result | Evidence |
|---|---|---|
| Native batch gates in exact order | 6/6 PASS | native/results.json and six raw logs |
| R4 canonical | 7/7 PASS | r4-canonical/results.json |
| F011/F006/F012 current contract | 3/3 PASS | canonical-contracts/results.json |
| Browser groups | 28/28 PASS; no JS errors | ui/results.json and 5 actual screenshots |
| UI01–UI28 | 28/28 PASS | UI01_UI28_TRACEABILITY.json |
| Native HTTP LAN suite | 6/6 PASS | lan/results.json |
| Real Windows EXE and resources | NOT_RUN | No Windows endpoint/verified EXE |
| Actual laptop license | USER_REPORTED_PASS | No independently verified device evidence |
| Physical 50-PC | USER_REPORTED_PASS | No independently verified room logs |
| Actual backup/restore/rollback | NOT_VERIFIED | Fixture restore checks are separate |

Native scripts: kiem_tra_v22.py, kiem_tra_v221.py, kiem_tra_mathjax.py,
kiem_tra_v222.py, kiem_tra_v23.py, kiem_tra_v23_integration.py. Every process
returned 0, standalone, no adapter; full original assertions are retained.

Coverage includes teacher/student login, nonce rotation and all unsafe-route
negatives, all 5 question types, ALL/PARTIAL/weights/max-score compatibility,
malformed snapshots/scoring and restore rejection, 20 matrix cells/comma topic,
availability rejection, offline MathJax, real acknowledged autosave/offline failure,
question switch/flags/reload/resume, deadline and late POST, atomic double/race
submit, independent regrading, snapshot Contract A under real bank edits,
monitor/report/Excel import/export and historical legacy-unknown behavior.
R4 scoring equivalence compares 344 cases to the locked prior oracle. F011 tests
include 175 raw route negatives plus 24 missing/wrong/other-session cases and
login rotation; legitimate multipart/form/JSON requests remain accepted.

50-client scopes: 8476 requests; unexpected failures
0; HTTP 500 0;
1 intentionally induced short-read timeout for retry.
60-client headroom: 2760 requests; failures
0; HTTP 500 0.
All stored answer/score comparisons, race winner, deadline invariants and isolation
PASS. Requests, resource samples and comparisons are preserved, not fabricated.
This is source/HTTP simulation on Linux, not a physical Windows-room result.

All five required screenshots are fresh Linux Chromium outputs at 1366x768 or
1920x1080. Before/after product hashes equal for all 64 files. Original legacy
raw failures are retained with their original FAIL classification; received older
reports are historical and not rewritten. No canonical failure was skipped.
