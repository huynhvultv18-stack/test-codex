# Actual installation backup and rollback — NOT_VERIFIED

DATA_BACKUP_READY = NOT_VERIFIED
ROLLBACK_READY = NOT_VERIFIED
This is a plan only. Native test backup/restore success concerns disposable fixture
data. No active installation, user DB or actual license state was accessed.

1. Before proposing replacement, operator records the exact active folder, EXE
   SHA, external template/static hashes, Windows account, server port/IP, current
   R4/working Windows release and controlled maintenance window. Preserve old
   EXE/source versions and folders. No deletion or in-place replacement.
2. On the original authorized machine, record legitimate license status and MID
   privately via existing UI; do not publish activation codes or change identity.
   Private state includes DATA_DIR/thi_trac_nghiem.db (cai_dat config/license rows),
   DATA_DIR/.session_secret, DATA_DIR/license_trial.json, external uploads/resources
   and %LOCALAPPDATA%/ThiTracNghiemLAN/<current-MID>.json for the actual Windows
   account. Do not read actual secret values into shareable logs. Preserve ACLs
   and secure/encrypted storage; never put a real backup in GitHub/handoff.
3. Obtain a consistent DB snapshot through native authenticated backup/SQLite backup
   API. With SQLite WAL, copying a live main .db alone is unsafe. If a filesystem
   copy is planned, schedule a controlled server stop and confirm no writers;
   preserve the complete data state and journal artifacts consistently. Do not
   manually delete WAL/SHM or run an unreviewed checkpoint against production.
   Preserve matching config/uploads/licensing files from the same maintenance state.
4. Hash original backup/copy privately, verify readable SQLite snapshot using
   read-only integrity_check, inventory schema/table counts/settings presence,
   attempts/snapshots/answers and scores, and ensure uploaded image references exist.
   Do not log password hashes, activation values or student PII publicly. Confirm
   hashes after transfer/storage. Retain the unmodified verified backup.
5. Rehearse restore into another isolated folder on the same authorized hardware
   and intended Windows account, with a controlled non-conflicting port and no
   active room session. Never overwrite the live DB. Existing init_db performs
   conditional schema upgrades and startup writes; compare before/after schema and
   relevant state on the disposable copy. Do not launch a new build against the
   live DB or permit automatic migration. If a schema change is required, stop and
   seek an explicit separately scoped decision. Trial state in the user profile
   is machine/account-wide: do not spoof, erase or reset it for a rehearsal.
6. Verify restored question bank, student/exam/history counts, historical report
   and independently regraded scores, config/port and legitimate licensing. Test
   close/reopen continuity. Record signed operator result and SHA provenance.
7. Rollback means retaining/rerunning the previously verified working executable
   with the matching private state on the same authorized hardware/account. Use
   a verified backup only under a separately approved maintenance plan. Preserve
   the failed new folder for diagnosis; no deleting old versions. Define rollback
   triggers (EXE failure, data discrepancy, licensing/MID change, missing resources,
   unplanned schema change or exam failure) and rollback owner/time limit.

Until actual backup readability and rehearsal logs exist, promotion remains
BLOCKED. Documentation, simulated restore and user-reported room PASS do not
substitute for verified safety of the active installation.
