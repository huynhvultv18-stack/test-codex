# V2.4 controlled release decision — RELEASE_BLOCKED

Prepared 2026-10-08T12:05:24.735234+07:00 (UTC+07:00). PROMOTION = BLOCKED. No Production artifact,
RC2, product patch, EXE or live replacement has been performed.

The three uploaded Windows complete ZIPs are byte-identical. The latest upload
is the selected source of truth, SHA-256 `eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d`, 849313 bytes, 82 archive
members. All archive CRCs, payload checksums and 64 product-file manifest rows
were verified before testing, then all product hashes and source ZIP were
rechecked after testing. Source and original archives remain untouched.

## Mandatory blockers

| Gate | Result | Evidence/action required |
|---|---|---|
| Real Windows build and resolved dependency/wheel provenance | NOT_RUN | Linux host; no Windows connection. User explicitly answered CHƯA CÓ. |
| EXE startup/localhost/teacher/student LAN/license/reopen | NOT_RUN | No verified EXE exists; source tests are not EXE acceptance. |
| Active production folder, exact EXE and DB schema | NOT_VERIFIED | Operator must inventory the active machine/version first. |
| Verified private DB/config/license-state backup | NOT_VERIFIED | No actual backup supplied/accessed. Disposable test backup success does not satisfy this gate. |
| Restore/rollback rehearsal for actual installation | NOT_VERIFIED | Written plan only; actual-machine execution evidence absent. |

User-reported physical 50-PC and laptop license PASS are preserved as statements,
not relabeled independently verified. The source request reports those results;
no Windows log/EXE hash/room test evidence was supplied this turn.

## Source review

Read app.py/database setup, multi_routes.py/question_types.py, scoring.py,
snapshot_validation.py, license_core.py, templates/static/MathJax and build scripts.
`EVIDENCE/source-audit.json` records exact function line locations and limits.
CSRF is checked globally for unsafe methods, with real signed-session nonce,
header/form transport and login rotation. Submit and autosave serialize with
BEGIN IMMEDIATE, deadline is rechecked under the write lock and submitted_at
guards commitment. The current R4 question builder is installed by
install_multi_routes; no live-bank backfill replaces Contract A history.
The 5 types and 20 matrix cells, available/requested validation, comma topic,
scoring modes/weights, snapshots, UI navigation/MathJax and report/export pass
the fresh canonical suites. Licensing/MID source remains unchanged; signature,
trial clock/state and same-process identity checks remain in the native/browser
tests. Actual authorized Windows license remains unverified here.

The received four test-only scripts match the approved nonce-only copies, with
76 original functional assertions preserved. Six native scripts execute standalone
from exact received source in batch order, without sitecustomize/transport adapter.
Earlier incompatible raw tests and failures are retained separately under
EVIDENCE/LEGACY_RAW_EVIDENCE and received prior reports; they are not skipped
or silently relabeled as passing. Current received source already contains the
explicitly approved compatibility overlay.

## Packaging and data compatibility observations

Existing build_exe.bat includes templates/static (including offline MathJax),
Waitress hidden import and openpyxl/cryptography collection. Version headings
retain historical v2.3 wording; source is not renamed or bumped. Requirements
are unpinned: a Windows resolved lock/wheel-hash capture is required for release
reproducibility. The batch prefers py -3; a clean VM must have only the intended
Python installed, and the selected interpreter must be recorded. It also opens
Explorer and pauses; operator must capture the final exit code.

Runtime init_db contains existing conditional ALTER TABLE paths and startup writes
including admin role/active normalization. No live DB is opened here. Before any
authorized move, prove the active schema/initialization on an isolated backup copy
and reject a plan requiring automatic migration. These are disclosed compatibility
gates, not changes made by this task. Copying only an EXE cannot prove data safety.

No new HIGH/CRITICAL product defect was confirmed in the reviewed source/tests.
This is bounded evidence, not an exhaustive vulnerability scan or a Windows safety
certification. Unrun EXE and active data/licensing cannot be certified defect-free.

## Final status

```text
SOURCE_ZIP_SHA256 = eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d
SOURCE_INTEGRITY = PASS
PRODUCT_SOURCE_MUTATED = NO
WINDOWS_BUILD = NOT_RUN
EXE_STARTUP = NOT_RUN
LOCALHOST = NOT_RUN (Windows EXE)
LAN_CLIENT = NOT_RUN (Windows EXE)
R4_REGRESSION = PASS (Linux source)
UI01_UI28 = PASS (Linux Chromium)
CSRF_F011 = PASS (Linux source)
SNAPSHOT_F012 = PASS (Linux source)
FIVE_QUESTION_TYPES = PASS (Linux source/browser)
LICENSE_LAPTOP = USER_REPORTED_PASS
PHYSICAL_50_PC_USER_REPORTED = USER_REPORTED_PASS
PHYSICAL_50_PC_EVIDENCE = NOT_VERIFIED
DATA_BACKUP_READY = NOT_VERIFIED
ROLLBACK_READY = NOT_VERIFIED
CRITICAL_DEFECTS = 0_CONFIRMED_IN_REVIEWED_SOURCE_SCOPE; Windows/live unknown
HIGH_DEFECTS = 0_CONFIRMED_IN_REVIEWED_SOURCE_SCOPE; Windows/live unknown
PRODUCTION_RELEASE_CANDIDATE = BLOCKED
LIVE_DEPLOYMENT = NOT_PERFORMED
PRODUCTION_SHA256 = N/A_NOT_CREATED
PRODUCTION_STATUS = BLOCKED
```

Only a RELEASE_BLOCKED handoff is produced. Its SHA is a handoff SHA, not a
Production SHA. Do not deploy it to the active server. Stop at this decision;
future live deployment still needs a separate explicit authorization and plan.
