# Windows build and EXE acceptance — NOT_RUN

WINDOWS_BUILD = NOT_RUN
EXE_STARTUP = NOT_RUN
PROMOTION = BLOCKED
No cross-compiled/Linux/Wine binary is substituted for Windows. No EXE exists in
this handoff. The source ZIP and packaged data folders remain unchanged.

## Reproducible operator procedure (requires real clean Windows)

Do not execute in the active installation. Use a fresh disposable Windows x64 VM,
only the chosen Python 3.12.6 x64 installed. Record Windows version, architecture,
Python installer source/SHA, `py -0p`, `py -3 --version`, and pip version. The
existing batch chooses `py -3`; a virtualenv alone cannot guarantee that choice.
Do not set a Machine ID override or install customer activation secrets on a VM.

1. Verify the supplied source ZIP SHA is exactly:
   eaf277e0f65fde4268c5ff33effc0f5a9fad7f8165e3d4aa577db18e14f03b8d
   Use Get-FileHash -Algorithm SHA256 and compare. Extract into a new clean folder.
   Compare the 64 product-file hashes with the source manifest before running.
2. Resolve the reference toolchain versions below in the clean Windows environment.
   They are copied from the user's earlier Windows screenshot, not certified by
   this Linux run. If unavailable/incompatible, stop; do not silently change them.
   Python 3.12.6; pip 24.2; Flask 3.1.3; openpyxl 3.1.5; waitress 3.0.2;
   cryptography 50.0.2; PyInstaller 6.22.3. The source requirements.txt stays intact.
   Example (clean build VM only):

   py -3 -m pip install pip==24.2
   py -3 -m pip install Flask==3.1.3 openpyxl==3.1.5 waitress==3.0.2 cryptography==50.0.2 PyInstaller==6.22.3
   py -3 -m pip check
   py -3 -m pip freeze --all > WINDOWS_RESOLVED_LOCK.txt
   py -3 -m pip download --only-binary=:all: -r WINDOWS_RESOLVED_LOCK.txt -d wheelhouse

   Preserve all exact transitive versions and SHA256 of every downloaded wheel,
   Python installer, lock and pip version. Download/install must keep TLS/package
   verification enabled. Resolve errors rather than removing validation. Freeze
   the Windows wheelhouse before building. The first resolution is NOT yet a
   reproducibility PASS: repeat on another clean Windows environment with the
   same interpreter and verified wheel bytes before claiming repeatability.
   To repeat, first verify every saved wheel SHA, then install offline:

   py -3 -m pip install --no-index --find-links wheelhouse -r WINDOWS_RESOLVED_LOCK.txt
   py -3 -m pip check

3. Run all six native tests directly from PHAN_MEM in exact build order:

   py -3 kiem_tra_v22.py
   py -3 kiem_tra_v221.py
   py -3 kiem_tra_mathjax.py
   py -3 kiem_tra_v222.py
   py -3 kiem_tra_v23.py
   py -3 kiem_tra_v23_integration.py

   Record each command's exit code/stdout/stderr; stop at any failure. No adapter,
   sitecustomize, CSRF disable/exemption, assertion edits or skips. Four approved
   test files are already present in this source, not a manual overlay step.
4. In a CMD session, set PIP_NO_INDEX=1, PIP_FIND_LINKS to the verified wheelhouse
   and PIP_CONSTRAINT to the absolute WINDOWS_RESOLVED_LOCK.txt path. These are
   local build-session settings, not application configuration. Run the unchanged
   build_exe.bat from PHAN_MEM and capture full output plus exit status. Its six
   gates run again; existing PyInstaller mechanism embeds templates/static,
   Waitress, openpyxl and cryptography and prepares external resource copies.
   Do not bypass the batch if its gate fails. The batch pauses and opens Explorer;
   operator must continue/capture the final exit code explicitly.
5. Inventory dist recursively and SHA256 every file. Prove the EXE exists and is
   nonzero. Compare external templates/static against the source manifest; verify
   all ui-v24 CSS/JS and static/vendor/mathjax/tex-svg.js. Inspect PyInstaller log,
   import warnings and executable architecture on Windows. Stop for any missing
   runtime resource/dependency. Exclude fixture DB, WAL/SHM, imports/exports,
   logs, .session_secret, license_trial.json and user LOCALAPPDATA state from the
   clean distributable. Do not run the EXE in the distribution-master directory;
   use a separate testing copy so generated private state is not distributed.
6. Inspect the built EXE in a separate controlled test deployment: launch,
   /health and localhost:5000, teacher login, real LAN student login, all five
   question types and MathJax, autosave/reload/resume, deadline/submit/race,
   CSRF negatives, history/Excel/monitor. Verify the EXE's own static asset hashes.
   Source Flask test-client results cannot satisfy this step. Run on the actual
   authorized laptop under its intended Windows user to check paid license/MID;
   never copy a license from another machine, reset trial or alter the identifier.
   Record close/reopen continuity and reboot continuity if possible. Redact
   activation keys/passwords/cookies; keep private data out of shareable evidence.
7. Only after EXE, active backup/restore and rollback gates PASS may a new frozen
   Production payload be produced. Prepare a future runtime payload from the
   verified dist, not CONG_CU_CAP_MA or source issuer tooling/private keys. Match
   the SHA manifest and source provenance; live deployment is a separate action.

No step above was executed on Windows this turn. The lock/wheelhouse and EXE
manifest are NOT yet available. A written procedure is not Windows acceptance.
